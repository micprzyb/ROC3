# Preservation-first execution checklist

Use this checklist together with `LLM_AGENT_PROMPT_ELASTICITY_PRESERVATION_FIRST_V3.md`. The prompt is authoritative; this file is an operational review aid.

## A. Before any repository edit

- [ ] Resolve the repository root, raw-data location or dataset identifier, current configuration, prior artifact roots, and approved security boundary.
- [ ] Create a unique, empty upgrade root that does not overlap prior runs, raw data, model registries, caches, or Optuna storage.
- [ ] Confirm that no active process is writing to artifacts that will be inspected.
- [ ] Confirm sufficient disk space for a code/configuration snapshot and new artifacts.
- [ ] Record Git branch, commit, status, staged changes, unstaged changes, untracked files, submodules, and remotes.
- [ ] Save binary patches for tracked and staged changes.
- [ ] Inventory untracked source/configuration files without automatically adding them to Git.
- [ ] Create a code/configuration-only snapshot that excludes raw data, secrets, caches, and prior bulk artifacts.
- [ ] Generate source hashes and write restore instructions.
- [ ] Do not use `git reset --hard`, `git clean`, destructive checkout, recursive deletion, or in-place database migration.

## B. Preserve the current real-data adaptation

- [ ] Locate the actual current data loader and canonical prepared-data layer.
- [ ] Document input sources, joins, keys, expected cardinalities, and duplicate handling.
- [ ] Document eligibility rules and every exclusion reason.
- [ ] Document purchase definition and attribution window.
- [ ] Document arm mapping, price ordering, and propensity columns.
- [ ] Document assigned, intended, displayed, and realized price multipliers.
- [ ] Document customer/household cluster and chronology definitions.
- [ ] Document all pre-treatment features and the evidence for feature timing.
- [ ] Document missing-value handling, category vocabularies, dtypes, feature order, and fitted preprocessors.
- [ ] Document existing buyer-only, pairwise, all-quote, and contribution views.
- [ ] Document cache keys and invalidation rules.
- [ ] Create a canonical dataset fingerprint without copying raw data.
- [ ] Freeze quote, buyer, arm, cluster, and exclusion counts.
- [ ] Freeze feature-name/order hashes, category vocabularies, and preprocessing output dimensions.
- [ ] Freeze fold and holdout definitions and mark any previously inspected holdout as contaminated.
- [ ] Make new model-specific views downstream derivatives of the preserved canonical layer.
- [ ] Ensure every derived or replicated row retains original quote and fold lineage.

## C. Preserve prior experiments and artifacts

- [ ] Catalog all prior model artifacts, calibrators, OOF predictions, holdout predictions, reports, and model cards.
- [ ] Catalog all Optuna databases, study names, objectives, fold versions, data fingerprints, and best parameters.
- [ ] Never reuse a study name for a changed objective or changed data/fold version.
- [ ] Preserve failed and pruned Optuna trials.
- [ ] Use compatible prior best parameters only as warm-start trials in a new study.
- [ ] Do not load and save over an old serialized model.
- [ ] Record the package environment required by each important legacy model.
- [ ] Capture legacy prediction fingerprints on a secure golden cohort.
- [ ] Preserve negative findings and dead ends; do not delete them because the new design supersedes them.

## D. Freeze the pre-upgrade baseline

- [ ] Run the existing tests exactly as currently documented.
- [ ] Record pre-existing failures before attempting fixes.
- [ ] Run the current experiment/data audit when safe.
- [ ] Index existing OOF and holdout predictions instead of blindly reproducing them.
- [ ] Capture baseline metrics, resolved configuration, seeds, environment, and commands.
- [ ] Create data-parity and behavior-contract artifacts.
- [ ] Test the restore procedure in a separate temporary location before broad implementation.

## E. Design the migration

- [ ] Create `MIGRATION_MAP.md` based on capabilities, not old filenames.
- [ ] Mark each capability as preserve, wrap, extend, replace, or add.
- [ ] Give every replacement a parity test and rollback method.
- [ ] Create `CHANGESET_PLAN.md` in dependency order.
- [ ] Keep old public APIs through adapters where practical.
- [ ] Version prediction schemas and data contracts.
- [ ] Add feature flags; keep new models off by default.
- [ ] Preserve production and baseline registry aliases.
- [ ] Make the first comparison data-frozen: same rows, labels, arms, propensities, features, preprocessing, and folds.

## F. Integrate the new models non-destructively

- [ ] Scalar common-elasticity model consumes the preserved buyer view.
- [ ] Exact two-gap model consumes the same canonical rows and propensities.
- [ ] Pairwise models use versioned downstream `H/C` and `L/C` views.
- [ ] Common-plus-residual boosters use cross-fitted common margins.
- [ ] Neural shared-component model uses exact joint buyer loss.
- [ ] Cumulative model uses replicated rows in a new cache namespace.
- [ ] Random Forest receives only cross-fitted shared features.
- [ ] Built-in multiclass and vector-leaf models are challengers, not replacements of the exact model.
- [ ] Every model outputs a common versioned `(log_rr_high, log_rr_low)` evaluation record.
- [ ] No old model, prediction table, cache, fold, or study is overwritten.

## G. Validate and compare

- [ ] All upstream scores, calibrators, ensembles, and residual margins are generated out of fold.
- [ ] Existing valid folds are reused for like-for-like comparison.
- [ ] New folds, when necessary, receive a new version and do not replace old folds.
- [ ] Joint buyer NLL, `H/C` NLL, and `L/C` NLL are reported.
- [ ] Calibration slopes/intercepts and grouped randomized risk-ratio calibration are reported.
- [ ] Transfer ablations isolate whether `L` data improve `H/C` prediction.
- [ ] Policy value uses randomized evaluation and cluster-bootstrap uncertainty.
- [ ] The chronological holdout is accessed only after the protocol is frozen.
- [ ] Data or feature changes are evaluated separately from model changes.

## H. Handover and rollback

- [ ] Write a changelog mapping old artifacts to new successors.
- [ ] Write a regression report distinguishing pre-existing and introduced differences.
- [ ] Verify that raw data and prior artifacts remain unchanged.
- [ ] Restore the pre-upgrade code/configuration state in a temporary location.
- [ ] Verify hashes and legacy prediction fingerprints.
- [ ] Write `ROLLBACK_TEST_REPORT.md`.
- [ ] Do not promote a new model automatically.
- [ ] Leave a clear, reversible model-registry promotion procedure.
