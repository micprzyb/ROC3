# New model integration checklist

## Preservation gate

- [ ] Current source and uncommitted work are snapshotted.
- [ ] Real-data adapter is mapped and fingerprinted.
- [ ] Existing folds and holdouts are preserved.
- [ ] Existing Optuna studies are catalogued.
- [ ] Existing models, preprocessors, calibrators, and predictions are preserved.
- [ ] Baseline predictions and metrics are reproduced.
- [ ] Rollback procedure is documented.

## Reference mapping

- [ ] v0.6.0 tests pass in isolation.
- [ ] `REFERENCE_CODE_MAPPING.md` is complete.
- [ ] Host equivalents are retained when correct.
- [ ] New modules use adapters rather than raw-data reloads.
- [ ] Old public imports and artifact loaders remain functional.

## Shared two-slope model

- [ ] Exact buyer categorical loss is used.
- [ ] Common and deviation surfaces are explicit.
- [ ] Deviation and asymmetry penalties are tuned out of fold.
- [ ] Scalar and unrestricted two-gap anchors are included.
- [ ] Gradient tests pass.

## Common plus residual boosting

- [ ] Common predictions used for residual training are inner OOF.
- [ ] H/C and L/C residual studies are separate.
- [ ] Residual models are more strongly regularized than stand-alone pairwise models.
- [ ] Residual shrinkage is tuned out of fold.
- [ ] XGBoost base margins are supplied consistently.
- [ ] LightGBM common margins are explicitly restored at prediction.
- [ ] Component artifact lineage is recorded.

## All-threshold and hybrid models

- [ ] Replication begins from the canonical buyer table.
- [ ] Original IDs, clusters, timestamps, arms, propensities, and folds are retained.
- [ ] Threshold targets are H=(1,1), C=(0,1), L=(0,0).
- [ ] Cumulative probabilities are coherent.
- [ ] Joint posterior and log risk ratios are reconstructed correctly.
- [ ] Ordinal weight and threshold weights are tuned out of fold.
- [ ] Joint categorical NLL is reported even when cumulative loss is trained.

## Transfer evidence

- [ ] Separate pairwise baseline is included.
- [ ] All-arms common model is compared with common model excluding L.
- [ ] Outer-fold H/C NLL is the primary L-to-H transfer metric.
- [ ] H/C grouped randomized calibration is reported.
- [ ] Pooling, residual-shrinkage, and ordinal-weight paths are reported.
- [ ] L-feature permutation diagnostic is run inside training folds.
- [ ] Forward-time confirmation is complete.

## Promotion gate

- [ ] New models remain shadow artifacts until approval.
- [ ] Existing registry entries were not overwritten.
- [ ] Serialization and reload tests pass.
- [ ] Prediction schema is versioned.
- [ ] Policy evaluation uses out-of-fold or holdout predictions.
- [ ] Clustered uncertainty is reported.
- [ ] Rollback rehearsal succeeds.
