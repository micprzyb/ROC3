# Real-data adapter preservation template

Complete this document before changing the data pipeline or integrating new model-specific data views. Store sensitive identifiers and row-level diagnostics only inside the approved security boundary.

## 1. Dataset identity

| Field | Value |
|---|---|
| Dataset or registry identifier | |
| Physical path or source system | |
| Approved security boundary | |
| Data owner | |
| Extraction or snapshot timestamp | |
| Dataset fingerprint method | |
| Dataset fingerprint | |
| Current data-contract version | |
| Current resolved configuration hash | |

## 2. Raw sources and joins

| Source | Purpose | Join key | Expected cardinality | Duplicate rule | Current implementation |
|---|---|---|---|---|---|
| | | | | | |

Document any temporal joins, as-of joins, late-arriving data, or source-specific exclusions.

## 3. Population flow

| Stage | Input rows | Output rows | Unique quotes | Unique clusters | Buyers | H | C | L | Exclusion reason or transformation |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Raw received records | | | | | | | | | |
| Deduplicated quotes | | | | | | | | | |
| Eligible randomized quotes | | | | | | | | | |
| Outcome-complete quotes | | | | | | | | | |
| Canonical model population | | | | | | | | | |
| Buyer view | | | | | | | | | |

List every exclusion rule separately and identify whether it is applied before or after randomization and outcome observation.

## 4. Outcome definition

| Item | Current behavior |
|---|---|
| Purchase column | |
| Purchase attribution window | |
| Cancellation treatment | |
| Multiple purchases or quote revisions | |
| Missing outcome rule | |
| Outcome timestamp | |
| Evidence the definition is unchanged | |

## 5. Treatment and propensity definition

| Item | Current behavior |
|---|---|
| Arm column | |
| Raw arm values | |
| Canonical mapping to H/C/L | |
| Price ordering check | |
| `pi_H` source | |
| `pi_C` source | |
| `pi_L` source | |
| Propensity normalization tolerance | |
| Randomization block variables | |
| Assigned multiplier | |
| Intended multiplier | |
| Displayed multiplier | |
| Realized multiplier | |
| Primary intention-to-treat variable | |

## 6. Customer and time lineage

| Item | Current behavior |
|---|---|
| Quote identifier | |
| Customer/household cluster | |
| Shopping-episode definition | |
| Chronology timestamp | |
| Multiple-quote handling | |
| First/last quote sensitivity views | |

## 7. Feature manifest and timing

| Feature or feature group | Source | Dtype | Missing-value rule | Category rule | Available before treatment? | Evidence | Current transformation |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Record the final feature order, feature-name hash, category vocabulary hashes, and fitted-preprocessor artifact identifiers.

## 8. Existing canonical and derived views

| View | Purpose | Filter | Row key | Required columns | Cache path/key | Producer | Consumers |
|---|---|---|---|---|---|---|---|
| All eligible quotes | | | | | | | |
| Buyers | | | | | | | |
| H/C buyers | | | | | | | |
| L/C buyers | | | | | | | |
| Cumulative replicated rows | | | | | | | |
| Contribution/policy view | | | | | | | |

New views must be added as versioned downstream derivatives. Do not replace a current view in place.

## 9. Fold and holdout registry

| Split artifact | Version | Creation code | Cluster-disjoint? | Chronological? | Previously inspected? | Hash/fingerprint | Status |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

If a previous holdout has been used for tuning or repeated decision-making, mark it contaminated rather than deleting it.

## 10. Baseline parity values

Record at least:

- eligible quote count;
- buyer count by arm;
- conversion rate by arm;
- sum and quantiles of each propensity column;
- missingness by feature;
- price-dose quantiles;
- cluster-count distribution;
- fold counts and secure membership hashes;
- exclusion counts by reason;
- transformed feature dimension and feature-name hash.

Reference the machine-readable `DATA_PARITY_BASELINE.json`.

## 11. Approved changes

| Change ID | Proposed change | Reason | Model requirement or bug fix | Affected rows/columns | Data-contract version | Parity impact | Approval/evidence | Rollback |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

A new architecture alone is not an approved reason to change population, label, propensity, feature timing, or fold semantics.

## 12. Derived-view lineage tests

- [ ] Every buyer row maps to one canonical quote.
- [ ] Every pairwise row maps to one canonical buyer.
- [ ] Every cumulative replicated row maps to one canonical buyer and one threshold.
- [ ] Every row retains cluster, time, propensity, and fold lineage.
- [ ] No derived view changes the canonical table.
- [ ] New caches use a new namespace keyed by dataset and configuration fingerprints.
- [ ] Rebuilding a new view does not delete or overwrite an old cache.
