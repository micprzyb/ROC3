# Migration map

Complete this file before modifying the current repository.

| Required capability | Current repository location | Current interface | Current status | Bundled reference | Action: preserve/wrap/extend/replace/add | Compatibility layer | Parity test | New artifact version | Rollback path |
|---|---|---|---|---|---|---|---|---|---|
| Canonical real quote table |  |  |  | Data contract |  |  |  |  |  |
| Buyer table |  |  |  | schema.py |  |  |  |  |  |
| Logged propensities |  |  |  | core.py |  |  |  |  |  |
| Fold registry |  |  |  | splits.py |  |  |  |  |  |
| Global scalar model |  |  |  | scalar.py |  |  |  |  |  |
| Pairwise H/C |  |  |  | pairwise.py |  |  |  |  |  |
| Pairwise L/C |  |  |  | pairwise.py |  |  |  |  |  |
| Exact two-gap |  |  |  | two_gap.py |  |  |  |  |  |
| Shared two-slope |  |  |  | shared.py |  |  |  |  |  |
| All-threshold model |  |  |  | ordinal.py |  |  |  |  |  |
| Common plus residual |  |  |  | residual.py |  |  |  |  |  |
| Calibration |  |  |  | calibration.py |  |  |  |  |  |
| OOF prediction schema |  |  |  | API contract |  |  |  |  |  |
| Optuna storage |  |  |  | optuna_spaces.py |  |  |  |  |  |
| Policy evaluation |  |  |  | policy.py |  |  |  |  |  |
