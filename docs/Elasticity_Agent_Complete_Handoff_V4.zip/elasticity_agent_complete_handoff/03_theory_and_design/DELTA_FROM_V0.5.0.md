# Delta from Python reference v0.5.0 to v0.6.0

Version 0.5.0 remains included byte-for-byte under the legacy directory.  The
v0.6.0 source is an additive reference extension.

## New statistical capabilities

### 1. Common component plus side-specific deviations

New module: `elasticity_only/shared.py`.

It learns

```text
beta_H(x) = softplus(f0(x) + fH(x))
beta_L(x) = softplus(f0(x) + fL(x))
```

from the exact joint buyer likelihood.  All arms update `f0`; the side heads
permit asymmetry.  `deviation_l2` controls the sharing continuum.

### 2. Proper cumulative and hybrid losses

New module: `elasticity_only/ordinal.py`.

It introduces two cumulative probabilities for ordered arms and supplies:

- all-threshold targets;
- cumulative log score;
- ranked probability score;
- categorical plus cumulative hybrid score;
- coherent projection and class-probability reconstruction;
- analytic two-gap cumulative gradients.

### 3. All-threshold tree wrappers

`ordinal.py` adds:

- `IPWAllThresholdClassifier` for generic sklearn/Random Forest;
- `LGBAllThresholdClassifier` with explicit row-level initial margins;
- `XGBAllThresholdClassifier` with row-level base margins.

### 4. Common scalar plus residual pairwise boosting

New module: `elasticity_only/residual.py`.

It adds:

- leakage-free common-model cross-fitting;
- H/C and L/C XGBoost residual learners;
- H/C and L/C LightGBM residual learners;
- residual shrinkage;
- coherent prediction-time composition.

### 5. Optional neural shared trunk

New module: `elasticity_only/torch_shared.py`.

This is optional and does not alter core dependencies.

### 6. Preservation and capability support

New modules:

- `preservation.py`;
- `capabilities.py`.

## New Optuna controls

- common coefficient regularization;
- deviation regularization;
- asymmetry shrinkage;
- ordinal auxiliary weight;
- cumulative threshold-weight ratio;
- high and low residual shrinkage;
- conservative residual-booster spaces;
- all-threshold booster spaces.

## New tests

Version 0.6.0 has 51 passing tests, up from the 34 tests reported in the v0.5
tutorial release.  New tests cover shared gradients, cumulative gradients,
all-threshold reconstruction, residual cross-fitting, native boosting wrappers,
and non-destructive writes.

## Important non-change

The correction remains in force: low-arm data are not automatically additional
information about the H/C risk ratio.  Transfer requires an explicit sharing
assumption or a proper ordered score.  Arbitrary class weights are not a valid
substitute.
