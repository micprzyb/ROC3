# Model API and prediction contract

The host repository may use different classes or frameworks.  Preserve its
interfaces where practical, but every model should be adaptable to this common
semantic contract.

## Required training inputs

For buyer-only elasticity fitting:

```text
X                 pre-treatment model features
arm               H, C, or L assignment
pi                n x 3 logged assignment propensities, ordered H,C,L
z                 n x 3 log-price doses, ordered H,C,L
sample_weight     optional prespecified analysis weight
cluster_id        used by splitting and uncertainty, not as a feature
quote_timestamp   used by chronology, not automatically as a feature
```

`z` should normally be centered at control or be convertible to centered
log-price distances.  The primary causal treatment remains randomized arm
assignment.  Realized dose requires separate compliance analysis when it is
post-randomization.

## Required prediction output

Every model must produce, directly or through an adapter:

```text
log_rr_HC(x) = log[q_H(x) / q_C(x)]
log_rr_LC(x) = log[q_L(x) / q_C(x)].
```

Use one row per original quote.  A recommended prediction table is:

```text
quote_id
customer_id_or_cluster_hash
timestamp
fold_version
outer_fold
model_artifact_id
prediction_origin          # OOF, chronological_holdout, or production_shadow
log_rr_HC
log_rr_LC
projection_applied_H
projection_applied_L
```

Additional diagnostic columns may be included, but these semantic fields must
not be renamed without a versioned schema adapter.

## Coherent buyer posterior

Given logged propensities,

```text
r = softmax(log(pi) + [log_rr_HC, 0, log_rr_LC]).
```

This is the common object used for joint buyer log loss.

## Monotonicity

Economically monotone demand requires

```text
log_rr_HC <= 0
log_rr_LC >= 0.
```

Prefer parameterizations that guarantee this.  When projection is used, retain
both raw and projected outputs and record projection frequency and magnitude.

## Prediction methods

A compatible estimator should expose either:

```python
predict_log_rr(X, *, z=...) -> (high, low)
```

or an adapter that creates this output.

Optional methods:

```python
predict_buyer_posterior(X, *, pi=..., z=...)
predict_side_elasticities(X)
predict_cumulative(X, *, pi=...)
```

## Fit methods

A reference semantic signature is:

```python
fit(X, arm, *, pi, z, sample_weight=None, ...)
```

Framework-specific evaluation sets and base margins are allowed.  Logged
propensities and row-level price doses must not be silently inferred from model
features when they are available as explicit experiment metadata.

## Artifact requirements

Every model artifact must record:

- data fingerprint;
- feature manifest hash and feature order;
- fold registry version;
- objective version;
- propensity source;
- price-dose definition;
- package versions;
- Optuna study and trial;
- calibration artifact;
- prediction-schema version;
- known limitations and promotion status.
