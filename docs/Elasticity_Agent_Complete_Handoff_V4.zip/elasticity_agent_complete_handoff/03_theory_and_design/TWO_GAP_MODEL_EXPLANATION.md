# Two-gap Bayes-flip models for randomized insurance price tests

This note is a focused companion to the full tutorial. It derives the two-gap model from the identified three-arm relative risks, explains every parameter and assumption used by the model, shows how both gap functions are learned from buyer-arm labels, and distinguishes exact joint fitting from pairwise composite implementations.

## 1. Experimental objects and notation

Consider an eligible insurance quote with pre-treatment customer and vehicle information denoted by

\[
X=x.
\]

The price test randomly assigns one of three arms:

\[
T\in\{H,C,L\},
\]

where:

- \(H\) is the high-price arm;
- \(C\) is the control-price arm;
- \(L\) is the low-price arm.

The purchase indicator is

\[
Y=\begin{cases}
1,&\text{the customer buys the quoted policy},\\
0,&\text{the customer does not buy it}.
\end{cases}
\]

The logged randomization probability for arm \(t\) is

\[
\pi_t(x)=P(T=t\mid X=x).
\]

The arm-specific conversion risk is

\[
q_t(x)=P(Y=1\mid T=t,X=x).
\]

The buyer-arm probability is

\[
r_t(x)=P(T=t\mid Y=1,X=x).
\]

The two risk ratios to control are

\[
RR_{HC}(x)=\frac{q_H(x)}{q_C(x)},
\qquad
RR_{LC}(x)=\frac{q_L(x)}{q_C(x)}.
\]

These risk ratios, rather than absolute conversion, are the primary relative-demand targets.

## 2. Identification assumptions

The causal interpretation requires the following assumptions.

### 2.1 Eligibility is defined before assignment

The analyzed population must be the set of quotes that were eligible before the random arm was drawn. Post-treatment filtering can destroy the randomized comparison.

### 2.2 Consistency

The observed purchase outcome under the assigned arm equals the potential outcome for that arm. The arm must correspond to a well-defined intervention. A nominal price multiplier that also changes coverage, service, payment terms, or underwriting treatment is not a pure price intervention.

### 2.3 Conditional randomization

Given the variables used by the randomization mechanism,

\[
T\perp \{Y(H),Y(C),Y(L)\}\mid X.
\]

When assignment probabilities vary by block, time, channel, or quota, the row-level logged propensities must be used.

### 2.4 Positivity

Every arm being evaluated must have positive assignment probability in every customer region where a prediction or policy decision is made:

\[
\pi_t(x)>0.
\]

### 2.5 Correct outcome measurement

Purchase must be measured over the same complete attribution window for all arms.

### 2.6 Pre-treatment features only

Every feature used to model heterogeneity must be available before the experimental price is displayed. The randomized arm, displayed experimental premium, and customer actions after price display are not predictors.

## 3. Bayes-flip identification

Bayes' rule gives

\[
r_t(x)
=
\frac{\pi_t(x)q_t(x)}
{\sum_{j\in\{H,C,L\}}\pi_j(x)q_j(x)}.
\]

Divide the expression for arm \(t\) by the expression for control:

\[
\frac{r_t(x)}{r_C(x)}
=
\frac{\pi_t(x)q_t(x)}{\pi_C(x)q_C(x)}.
\]

Therefore,

\[
\boxed{
RR_{tC}(x)
=
\frac{q_t(x)}{q_C(x)}
=
\frac{r_t(x)/\pi_t(x)}{r_C(x)/\pi_C(x)}.
}
\]

This is exact. It does not use a rare-conversion approximation.

For fixed \(10\%/80\%/10\%\) assignment,

\[
RR_{HC}(x)=\frac{8r_H(x)}{r_C(x)},
\qquad
RR_{LC}(x)=\frac{8r_L(x)}{r_C(x)}.
\]

## 4. Why three prices imply two relative-response degrees of freedom

At a fixed \(x\), the three positive conversion risks are

\[
(q_H,q_C,q_L).
\]

Buyer-only data do not identify their common scale. Multiplying all three by the same admissible positive number leaves \(r_t(x)\) unchanged.

Choose control as the reference and divide by \(q_C\):

\[
\left(
\frac{q_H}{q_C},
1,
\frac{q_L}{q_C}
\right)
=
(RR_{HC},1,RR_{LC}).
\]

Exactly two independent relative quantities remain. Therefore, an unrestricted relative-demand model for three tested prices needs two functions of \(x\), not one and not three.

## 5. Direct two-gap parameterization

Under economically monotone demand,

\[
q_H(x)\le q_C(x)\le q_L(x).
\]

Equivalently,

\[
RR_{HC}(x)\le1,
\qquad
RR_{LC}(x)\ge1.
\]

Define the high-price gap

\[
\boxed{
u(x)=\log\frac{q_C(x)}{q_H(x)}=-\log RR_{HC}(x)\ge0
}
\]

and the low-price gap

\[
\boxed{
v(x)=\log\frac{q_L(x)}{q_C(x)}=\log RR_{LC}(x)\ge0.
}
\]

Then

\[
RR_{HC}(x)=e^{-u(x)},
\qquad
RR_{LC}(x)=e^{v(x)}.
\]

The exponentials here do not assume a power-law demand curve. They simply map additive log-risk gaps back to positive multiplicative risk ratios.

The direct-gap model makes no assumption that the high and low effects lie on one continuous demand curve. It estimates the two finite experimental contrasts subject only to monotonicity and the chosen feature/regularization structure.

## 6. Exact buyer posterior under two gaps

For quote \(i\), write

\[
u_i=u(X_i),
\qquad
v_i=v(X_i).
\]

The relative risks are

\[
q_{i,H}=q_{i,C}e^{-u_i},
\qquad
q_{i,L}=q_{i,C}e^{v_i}.
\]

Substitute these expressions into Bayes' rule. The unknown \(q_{i,C}\) cancels:

\[
r_{i,H}
=
\frac{\pi_{i,H}e^{-u_i}}{D_i},
\]

\[
r_{i,C}
=
\frac{\pi_{i,C}}{D_i},
\]

\[
r_{i,L}
=
\frac{\pi_{i,L}e^{v_i}}{D_i},
\]

where

\[
D_i
=
\pi_{i,H}e^{-u_i}
+
\pi_{i,C}
+
\pi_{i,L}e^{v_i}.
\]

In vector notation,

\[
\boxed{
r_i
=
\operatorname{softmax}
\left(
\log\pi_i+[-u_i,0,v_i]
\right).
}
\]

Here \(\log\pi_i\) means componentwise logarithms of the three assignment probabilities.

## 7. Exact likelihood and loss

Among buyers, the observed response is the randomized arm \(T_i\). Conditional on \(Y_i=1\) and \(X_i\), it has a categorical distribution:

\[
T_i\mid Y_i=1,X_i
\sim
\operatorname{Categorical}(r_{i,H},r_{i,C},r_{i,L}).
\]

The exact row negative log-likelihood is

\[
\boxed{
\ell_i(u_i,v_i)
=-\log r_{i,T_i}.
}
\]

Expanded,

\[
\ell_i(u_i,v_i)
=
\log D_i
+
\mathbf1\{T_i=H\}u_i
-
\mathbf1\{T_i=L\}v_i
-
\log\pi_{i,T_i}.
\]

The final propensity term is known. The unknown functions \(u(x)\) and \(v(x)\) are learned by minimizing mean buyer negative log-likelihood plus regularization.

There is no observed customer-level gap or elasticity target. The model learns from how customer features predict deviations of the buyer-arm distribution from the randomized assignment prior.

## 8. Exact derivatives

Let

\[
I_{i,H}=\mathbf1\{T_i=H\},
\qquad
I_{i,L}=\mathbf1\{T_i=L\}.
\]

The direct-gap gradients are

\[
\boxed{
\frac{\partial\ell_i}{\partial u_i}
=I_{i,H}-r_{i,H}
}
\]

and

\[
\boxed{
\frac{\partial\ell_i}{\partial v_i}
=r_{i,L}-I_{i,L}.
}
\]

Interpretation:

- A high-price buyer is evidence for a smaller high gap, because purchase at the higher price suggests less sensitivity.
- A low-price buyer is evidence for a larger low gap, because extra low-price buyers suggest stronger sensitivity.
- A control buyer affects both gaps through the common normalization.

The exact Hessian with respect to \((u_i,v_i)\) is

\[
\boxed{
H_i=
\begin{bmatrix}
r_{i,H}(1-r_{i,H}) & r_{i,H}r_{i,L}\\
r_{i,H}r_{i,L} & r_{i,L}(1-r_{i,L})
\end{bmatrix}.
}
\]

Its determinant is

\[
\det(H_i)=r_{i,H}r_{i,C}r_{i,L}\ge0.
\]

The diagonal entries are nonnegative, so \(H_i\) is positive semidefinite. The loss is convex in the direct gaps.

The off-diagonal element

\[
r_{i,H}r_{i,L}
\]

is generally nonzero. The two gaps are statistically coupled. This is why an exact joint two-gap optimizer is not identical to fitting two unrelated binary classifiers.

## 9. Learning heterogeneous gap functions

Choose two unrestricted raw score functions

\[
f_H(x)\in\mathbb R,
\qquad
f_L(x)\in\mathbb R.
\]

Enforce nonnegative gaps with the softplus function

\[
\operatorname{softplus}(a)=\log(1+e^a).
\]

Set

\[
u(x)=\operatorname{softplus}(f_H(x)),
\]

\[
v(x)=\operatorname{softplus}(f_L(x)).
\]

The derivative of softplus is the logistic sigmoid

\[
\sigma(a)=\frac{1}{1+e^{-a}}.
\]

Therefore, the raw-score gradients are

\[
\frac{\partial\ell_i}{\partial f_H(X_i)}
=
(I_{i,H}-r_{i,H})\sigma(f_H(X_i)),
\]

\[
\frac{\partial\ell_i}{\partial f_L(X_i)}
=
(r_{i,L}-I_{i,L})\sigma(f_L(X_i)).
\]

### 9.1 Penalized linear or spline model

Let \(\phi(x)\) be a fold-locally transformed feature vector. Define

\[
f_H(x)=a_H+\phi(x)^\top b_H,
\]

\[
f_L(x)=a_L+\phi(x)^\top b_L.
\]

A basic objective is

\[
\frac{1}{N_B}\sum_{i:Y_i=1}\ell_i
+
\frac{\lambda_H}{2}\lVert b_H\rVert_2^2
+
\frac{\lambda_L}{2}\lVert b_L\rVert_2^2.
\]

This objective can be optimized with L-BFGS-B using analytic gradients. Splines, one-hot features, and carefully predeclared interactions can be included in \(\phi(x)\).

### 9.2 Global model

The global two-gap anchor assumes constant \(u\) and \(v\) for all buyers:

\[
(\widehat u,\widehat v)
=
\arg\min_{u,v\ge0}
\sum_{i:Y_i=1}\ell_i(u,v).
\]

The objective is convex. Fit this before heterogeneous models and use it as an initialization and benchmark.

## 10. Direct gaps versus side-specific slopes

If all quotes receive essentially the same multipliers, direct gaps are transparent finite-contrast parameters.

When actual log-price distances vary by row, define

\[
d_{i,H}=z_{i,H}-z_{i,C}>0,
\]

\[
d_{i,L}=z_{i,C}-z_{i,L}>0,
\]

where

\[
z_{i,t}=\log\frac{P_{i,t}}{P_{i,C}}.
\]

Learn two nonnegative side-specific log-elasticity magnitudes

\[
\beta_H(x)\ge0,
\qquad
\beta_L(x)\ge0,
\]

and set

\[
u_i=\beta_H(X_i)d_{i,H},
\]

\[
v_i=\beta_L(X_i)d_{i,L}.
\]

This separates response magnitude from experimental dose. It is appropriate only when the row-level dose is correctly defined and its variation is part of the intended randomized intervention or a properly handled compliance analysis.

## 11. Relation to the scalar constant-log-elasticity model

The scalar model assumes one common nonnegative slope

\[
\beta_H(x)=\beta_L(x)=\beta(x).
\]

Then

\[
u(x)=\beta(x)d_H,
\qquad
v(x)=\beta(x)d_L.
\]

Equivalently,

\[
\frac{u(x)}{d_H}
=
\frac{v(x)}{d_L}.
\]

The scalar model is therefore a one-dimensional restriction inside the two-gap model. It has lower variance because both side arms estimate one function, but it is biased when high-side and low-side responses differ systematically.

The two-gap model removes that equality and estimates the two side responses separately. It pays for flexibility with higher variance, particularly because the high-price buyer count can be small.

## 12. Partial pooling toward the scalar restriction

A useful intermediate model adds the asymmetry penalty

\[
\frac{\lambda_{\mathrm{asym}}}{2N_B}
\sum_{i:Y_i=1}
\left[
\beta_H(X_i)-\beta_L(X_i)
\right]^2.
\]

Interpretation:

- \(\lambda_{\mathrm{asym}}=0\): independent side-specific response surfaces;
- moderate \(\lambda_{\mathrm{asym}}\): partial pooling;
- very large \(\lambda_{\mathrm{asym}}\): near-scalar common slope.

Tune this parameter logarithmically with nested cross-validation. It is often more important than small adjustments to tree depth or learning rate.

## 13. Pairwise models and exact joint fitting

For high versus control buyers,

\[
\operatorname{logit}
P(T=H\mid T\in\{H,C\},Y=1,X=x)
=
\log\frac{\pi_H(x)}{\pi_C(x)}-u(x).
\]

For low versus control buyers,

\[
\operatorname{logit}
P(T=L\mid T\in\{L,C\},Y=1,X=x)
=
\log\frac{\pi_L(x)}{\pi_C(x)}+v(x).
\]

These identities allow mature binary implementations in LightGBM and XGBoost using propensity offsets. Random Forest and ordinary scikit-learn classifiers can use inverse-propensity weighting with careful calibration.

After fitting, reconstruct the joint posterior:

\[
r(x)=\operatorname{softmax}(\log\pi(x)+[-u(x),0,v(x)]).
\]

Pairwise fitting is a composite-likelihood approach. It estimates the same two risk-ratio functions, but it does not exactly maximize the coupled three-arm likelihood because control buyers enter both binary objectives.

Use the exact reconstructed categorical buyer NLL to compare pairwise and joint candidates on common validation folds.

## 14. LightGBM and XGBoost limitation for an exact joint two-output objective

The exact direct-gap Hessian contains a nonzero cross-output block. Typical custom-objective interfaces for tree boosting expect one curvature per output rather than a full per-row \(2\times2\) block.

Consequently:

- pairwise binary LightGBM/XGBoost is the primary tree implementation;
- an exact joint linear/spline model can retain the complete Hessian through a general optimizer;
- a joint two-output tree objective that keeps only the diagonal Fisher terms is an approximation and must be labeled as such;
- exact joint categorical NLL remains the validation criterion.

## 15. Elasticity conversion

For a high-side gap \(u(x)\),

\[
RR_{HC}(x)=e^{-u(x)}.
\]

For a low-side gap \(v(x)\),

\[
RR_{LC}(x)=e^{v(x)}.
\]

The side-specific log-change elasticity magnitudes are

\[
\beta_H^{\log}(x)
=
\frac{u(x)}{\log(P_H/P_C)},
\]

\[
\beta_L^{\log}(x)
=
\frac{v(x)}{-\log(P_L/P_C)}.
\]

The standard finite signed elasticities are

\[
\varepsilon_{HC}^{\mathrm{rel}}(x)
=
\frac{e^{-u(x)}-1}{P_H/P_C-1},
\]

\[
\varepsilon_{LC}^{\mathrm{rel}}(x)
=
\frac{e^{v(x)}-1}{P_L/P_C-1}.
\]

Always report the price ratio, reference direction, sign convention, and elasticity convention. The risk ratios are the primary estimands and should be retained even when elasticity is the business reporting unit.

## 16. What two-gap asymmetry means

If

\[
\beta_H(x)\ne\beta_L(x),
\]

then one common constant-log-elasticity slope does not describe both finite experimental contrasts at that \(x\).

This does not automatically prove that every individual has a continuously curved demand curve. Marginal asymmetry may also arise from:

- finite-interval averaging;
- mixtures of customers with different latent sensitivities;
- omitted effect modifiers;
- measurement error in competitive position;
- different operational compliance on the two sides.

Interpret the two gaps first as finite experimental responses. Stronger structural claims require more price levels or stronger assumptions.

## 17. Optuna priorities

For an exact linear/spline two-gap model, tune:

- common coefficient L2 penalty, approximately \(10^{-5}\) to \(10^2\);
- asymmetry penalty, approximately \(10^{-4}\) to \(10^4\);
- direct-gap versus side-slope parameterization;
- spline complexity;
- small predeclared interaction sets;
- shared versus limited side-specific features.

For pairwise LightGBM/XGBoost, tune each contrast separately, but evaluate the reconstructed joint posterior. Prioritize:

- strong leaf-size controls;
- shallow trees;
- learning rate and early-stopping iteration;
- row and feature subsampling;
- L1/L2 regularization;
- calibration and shrinkage parameters.

Do not tune class balancing. Do not optimize AUC or VUS as the primary target. Optimize out-of-fold conditional log loss.

## 18. Required validation

A two-gap model should be promoted only when it improves over the scalar anchor on the following dimensions:

1. joint buyer categorical NLL;
2. H/C and L/C pairwise NLL;
3. side-specific calibration intercepts and slopes;
4. randomized grouped H/C and L/C risk-ratio calibration;
5. forward-time stability;
6. customer-group-disjoint repeated-fold stability;
7. randomized contribution-policy value;
8. uncertainty of the incremental value;
9. boundary and shrinkage diagnostics.

If the unrestricted two-gap model does not earn its second surface, use a scalar or partially pooled model.

## 19. Business decision

Let \(g_t(x)\) be expected contribution conditional on purchase under arm \(t\). Expected contribution is

\[
V_t(x)=g_t(x)q_t(x).
\]

Since

\[
q_t(x)=q_C(x)RR_{tC}(x),
\]

we have

\[
V_t(x)=q_C(x)g_t(x)RR_{tC}(x).
\]

The positive factor \(q_C(x)\) is common across arms, so the best tested arm is

\[
\boxed{
d^*(x)
=
\arg\max_{t\in\{H,C,L\}}
g_t(x)RR_{tC}(x),
}
\]

with \(RR_{CC}(x)=1\).

Thus the two-gap model directly supplies the relative-demand quantities needed for the tested-price decision, while an absolute base-conversion model remains optional for forecasting or doubly robust variance reduction.

## 20. Honest evidential boundary

The equations identify and parameterize relative demand under the randomized experiment. They do not establish that a heterogeneous two-gap model is empirically superior for a particular insurer. That conclusion must come from real quote-level experimental data, nested out-of-fold validation, calibrated risk ratios, temporal holdouts, and randomized policy-value estimates.
