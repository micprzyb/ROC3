# Tree multi-output and pairwise implementation note

## Default multiclass LightGBM and XGBoost

A three-class softmax model predicts three raw margins.  Only two contrasts are
independent, but generic libraries commonly keep one margin per class.

Default multiclass LightGBM and default `one_output_per_tree` XGBoost generally
construct one scalar-output tree per class per boosting iteration.  Their class
trees share:

- the same data;
- the joint softmax probability calculation;
- the categorical loss;
- coupled first-order residuals;
- the boosting schedule and broad hyperparameters.

They normally do not share:

- split variables;
- thresholds;
- topology;
- leaf membership;
- scalar leaf values.

Thus they share the loss more than two independently fitted binary models, but
less than a neural network with a shared trunk.

## Vector-leaf XGBoost

When supported, `multi_output_tree` can share one tree partition and store a
vector update in each leaf.  This is a useful challenger when high- and low-side
responses use similar partitions.  It can be restrictive when the two sides
need different features or depths.  Runtime capability and serialization tests
are mandatory.

## Exact two-gap curvature

For direct gaps `u` and `v`, the exact row Hessian contains a nonzero
cross-output element.  Generic custom-objective tree APIs usually consume
scalar or diagonal curvature.  A diagonal-Hessian joint booster is therefore
an approximation and must be labeled as such.

## Pairwise models

Pairwise H/C and L/C models have exact binary propensity-offset likelihoods.
They permit independent hyperparameters and calibration.  They do not share
features automatically.

## Recommended tree compromise

Fit an all-arm common scalar model and then side-specific residual pairwise
boosters around cross-fitted common margins.  This gives:

- real all-arm transfer through the common component;
- contrast-specific flexibility;
- separate regularization and calibration;
- coherent final risk ratios.

The residual correction must be trained from out-of-fold common predictions.
