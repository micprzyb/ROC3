# Shared-information research note

## Question

Should an L-arm buyer receive a larger gradient than a C-arm buyer when
learning the H/C response?

## Unrestricted two-gap answer

Define

```text
u(x) = -log RR_HC(x) >= 0
v(x) =  log RR_LC(x) >= 0.
```

The buyer posterior is

```text
r(x) = softmax(log(pi) + [-u(x), 0, v(x)]).
```

For categorical negative log-likelihood,

```text
d loss / d u = 1{T=H} - r_H.
```

Therefore a C buyer and an L buyer have the same direct gradient on `u`.
This is not a tree-library defect.  The H/C risk ratio depends on the H/C buyer
odds after propensity correction; the L mass can change through `v` without
changing that ratio.

At a fixed covariate value, conditioning on H/C retains the efficient
information for `u` when `v` is unrestricted.  Discarding L from that
conditional likelihood is nuisance elimination, not necessarily information
waste.

## Why arbitrary larger L weights are invalid

An H-versus-rest weighted binary loss with L weight larger than C estimates a
weighted artificial posterior.  Its optimum is not `r_H`, `r_H/r_C`, or
`RR_HC`.  It cannot be interpreted as a calibrated high/control elasticity
model without modeling the missing C/L composition separately.

## When L can inform H

L observations can improve H predictions through an explicit assumption:

1. one common scalar elasticity controls both sides;
2. a common representation plus side-specific deviations;
3. partial pooling of high- and low-side slopes;
4. a common scalar tree model plus residual pairwise boosters;
5. a proper cumulative/all-threshold score;
6. a cross-fitted common-sensitivity feature supplied to contrast-specific
   models.

The transfer assumption must be tested out of fold.

## Common-plus-deviation model

Use

```text
beta_H(x) = softplus(f0(x) + fH(x))
beta_L(x) = softplus(f0(x) + fL(x)).
```

All arms update `f0`; the side heads absorb asymmetry.  Penalizing the deviation
heads controls the bias-variance trade-off.

## All-threshold model

Order arms H, C, L and learn

```text
F1 = P(T=H | buyer,X)
F2 = P(T in {H,C} | buyer,X).
```

Targets are:

```text
H -> (1,1)
C -> (0,1)
L -> (0,0).
```

An L buyer supplies two directionally consistent threshold labels.  The
cumulative log score is proper when `0 <= F1 <= F2 <= 1`.  It changes gradient
emphasis without changing the population class-probability target.

## Primary real-data test

To claim that L helped H, compare models on untouched outer-fold H/C
conditional log loss and grouped H/C randomized calibration.  Also run:

- common model trained with all arms versus without L;
- pooling-strength path;
- residual-shrinkage path;
- cumulative-weight path;
- within-block L-feature permutation diagnostic;
- forward-time confirmation.

A lower total three-class loss caused only by better L predictions is not
evidence that H improved.
