# Integration guide for an evolved real-data repository

This guide tells an agent how to use the supplied Python files without losing
its earlier work.  It is subordinate to the preservation-first V4 prompt.

## 1. Do not begin with a source copy

The reference package is not a patch that should be applied blindly.  The host
repository may already contain:

- real-data SQL and joins;
- corrected arm mappings;
- outcome-window logic;
- fold registries;
- feature manifests;
- tuned models;
- calibrated predictions;
- production wrappers;
- framework-specific abstractions;
- bug fixes not present in the reference.

The first deliverable is a capability map, not a merge.

## 2. Freeze the current baseline

Before integration, preserve and fingerprint:

1. source and uncommitted work;
2. canonical quote table semantics;
3. buyer and pairwise row counts;
4. feature order and category vocabularies;
5. fold memberships;
6. existing OOF and holdout predictions;
7. Optuna studies and best trials;
8. serialized preprocessors, models, and calibrators;
9. reports and negative findings.

Run the current baseline through its existing entry point.  Save predictions
and metrics under a new preservation root.  Do not rerun data preparation with
new defaults and call that the baseline.

## 3. Verify the supplied package in isolation

From an isolated copy:

```bash
cd 03_reference_implementation_v0.6.0
python -m compileall -q elasticity_only examples tests
pytest -q
```

Do not modify the host environment or lockfiles merely to reproduce the bundle
unless explicitly approved.  Record any version-dependent failures.

## 4. Map foundational capabilities first

Before new models, verify that the host has semantically equivalent functions
for:

- arm normalization H/C/L;
- row-level propensity validation;
- row-level price dose validation;
- buyer posterior reconstruction from log risk ratios;
- pairwise propensity-offset loss;
- scalar buyer likelihood;
- exact two-gap likelihood;
- grouped and joint evaluation metrics;
- customer-disjoint folds;
- chronological holdout;
- model artifact metadata.

Prefer host code when it is already correct and tested.  Importing a new model
on top of a mismatched arm order or propensity convention is unsafe.

## 5. Integrate one new capability at a time

### 5.1 Shared two-slope model

Reference:

```text
elasticity_only/shared.py
SklearnSharedTwoSlopeFlipRegressor
```

Integration steps:

1. adapt the host fold-local transformed matrix to the estimator or port its
   objective into the host estimator base class;
2. preserve the host scalar and two-gap APIs;
3. expose `predict_log_rr_HC` and `predict_log_rr_LC` through the common
   prediction contract;
4. add Optuna controls for common, deviation, and asymmetry penalties;
5. add finite-difference gradient tests;
6. compare against scalar and unrestricted two-gap anchors on identical folds.

Do not infer model superiority from convergence or training loss.

### 5.2 All-threshold model

Reference:

```text
elasticity_only/ordinal.py
```

Integration steps:

1. replicate only the preserved canonical buyer table;
2. retain original quote ID, cluster, timestamp, fold, arm, and propensities on
   both threshold rows;
3. use threshold targets H=(1,1), C=(0,1), L=(0,0);
4. use row-level cumulative propensity base margins for LightGBM/XGBoost;
5. for generic sklearn/RF, use the IPW normalized-demand formulation or a host
   implementation with equivalent semantics;
6. enforce or project `F1 <= F2`;
7. reconstruct `r_H=F1`, `r_C=F2-F1`, `r_L=1-F2`;
8. convert to log risk ratios with logged propensities;
9. evaluate both cumulative and joint categorical loss.

Treat replication as a model view, not a new source dataset.  Never write it
back into the canonical quote table.

### 5.3 Common plus residual boosters

Reference:

```text
elasticity_only/residual.py
```

Integration steps:

1. select a common scalar estimator already supported by the host;
2. inside each residual-training outer fold, generate inner OOF common
   predictions for every training row;
3. train H/C residual booster with base margin
   `log(pi_H/pi_C) + common_log_rr_HC`;
4. train L/C residual booster with base margin
   `log(pi_L/pi_C) + common_log_rr_LC`;
5. tune residual models more conservatively than stand-alone pairwise models;
6. tune residual shrinkage on OOF predictions;
7. refit common and residual components on the complete outer-training data
   using the frozen procedure;
8. predict the outer validation fold without leakage;
9. record common and residual artifact lineage separately.

For XGBoost, supply `base_margin` at training, validation, and prediction.  For
LightGBM, explicitly add the saved common margin to predicted residual raw
scores; do not assume `init_score` is serialized into ordinary predictions.

### 5.4 Shared neural model

Reference:

```text
elasticity_only/torch_shared.py
```

Only integrate when the host already supports PyTorch or an equivalent neural
framework.  Reuse its dataset, trainer, checkpoint, and monitoring
infrastructure.  Port the mathematical heads and losses rather than introducing
a second unrelated training framework.

## 6. Preserve old interfaces

When the host has established model classes, add adapters such as:

```text
ReferenceSharedTwoSlopeAdapter
AllThresholdPredictionAdapter
CommonResidualPredictionAdapter
LegacyPredictionSchemaAdapter
```

Avoid changing every downstream consumer.  The common semantic output is two
log risk ratios.  Old artifacts should remain loadable through their original
class or a compatibility import path.

## 7. Preserve old Optuna work

Do not resume an old study after changing:

- model family;
- objective;
- fold version;
- data fingerprint;
- calibration procedure;
- search-space parameter semantics.

Create new study names containing an objective version, for example:

```text
shared_two_slope__buyer_cat_nll_v1
all_threshold_lgb__cum_offset_v1
common_residual_h__pair_nll_v1
```

Old best parameters can be enqueued as starting trials only when their meanings
are compatible.  Keep prior trial history intact.

## 8. Data-frozen comparisons

For the first comparison, hold fixed:

- eligibility population;
- purchase outcome;
- arm mapping;
- row-level propensities;
- feature list and preprocessing;
- fold membership;
- chronological holdout;
- contribution definitions.

New feature engineering must be a separate ablation.  Do not combine a model
upgrade and a data-definition change in one headline comparison.

## 9. Required ablations

To evaluate cross-arm sharing, run:

1. separate pairwise baseline;
2. common scalar model;
3. exact unrestricted two-gap model;
4. shared common-plus-deviation model;
5. common model trained with all arms versus without L;
6. pooling path over deviation/asymmetry penalties;
7. common plus residual path over residual shrinkage;
8. all-threshold cumulative model;
9. hybrid-loss path over ordinal weight;
10. L-feature permutation diagnostic inside training folds;
11. forward-time confirmation.

Use outer-fold H/C NLL as the primary transfer test for whether L helped H.

## 10. Promotion and rollback

New models remain shadow candidates.  Promotion requires:

- baseline parity;
- positive held-out evidence;
- calibration;
- stable forward-time behavior;
- policy-value evidence;
- artifact lineage;
- model load/save tests;
- a successful rollback rehearsal.

Promotion must be a registry/configuration action, not file replacement.  The
rollback should restore the old registry pointer or feature flag without
rebuilding data.
