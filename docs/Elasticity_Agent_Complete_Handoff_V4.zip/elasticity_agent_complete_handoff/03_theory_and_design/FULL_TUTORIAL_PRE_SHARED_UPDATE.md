---
title: "Elasticity-Only Modeling for Randomized Motor-Insurance Price Tests"
subtitle: "A coherent tutorial on Bayes-flip identification, scalar and two-gap models, machine learning, Optuna tuning, calibration, and real-data validation"
author: "Research tutorial - revised two-gap edition"
date: "August 2026"
lang: en-US
---

<!-- STATIC_CONTENTS_START -->
# Contents {.unnumbered}

**Part I - Business target, data, and notation**

- [The business decision](#the-business-decision)
- [Observation-level notation](#observation-level-notation)
- [Experimental assumptions](#experimental-assumptions)

**Part II - Identification and elasticity**

- [The Bayes-flip identity](#the-bayes-flip-identity)
- [Elasticity conventions](#elasticity-conventions)
- [Price choice from relative demand](#price-choice-from-relative-demand)

**Part III - The model hierarchy**

- [Why three prices imply two relative-response degrees of freedom](#why-three-prices-imply-two-relative-response-degrees-of-freedom)
- [Global anchor models](#global-anchor-models)
- [The scalar constant-log-elasticity model](#the-scalar-constant-log-elasticity-model)
- [The two-gap model](#the-two-gap-model)
- [Pairwise models](#pairwise-models)
- [Choosing between scalar, two-gap, and pairwise formulations](#choosing-between-scalar-two-gap-and-pairwise-formulations)

**Part IV - Learning the models in Python**

- [Common learning concepts](#common-learning-concepts)
- [Data preparation and feature processing](#data-preparation-and-feature-processing)
- [Fitting the global anchors](#fitting-the-global-anchors)
- [Exact scikit-learn-compatible scalar and two-gap models](#exact-scikit-learn-compatible-scalar-and-two-gap-models)
- [Pairwise penalized logistic regression](#pairwise-penalized-logistic-regression)
- [Pairwise LightGBM](#pairwise-lightgbm)
- [Pairwise XGBoost](#pairwise-xgboost)
- [Random Forest approaches](#random-forest-approaches)
- [Joint multiclass and geometric models](#joint-multiclass-and-geometric-models)
- [Calibration and shrinkage](#calibration-and-shrinkage)
- [Constrained ensembles](#constrained-ensembles)

**Part V - Real-data validation and model selection**

- [Required real-data contract](#required-real-data-contract)
- [Experiment audit before modeling](#experiment-audit-before-modeling)
- [Validation architecture](#validation-architecture)
- [Primary probability metrics](#primary-probability-metrics)
- [Calibration of relative effects](#calibration-of-relative-effects)
- [Randomized grouped risk-ratio calibration](#randomized-grouped-risk-ratio-calibration)
- [Uncertainty estimation](#uncertainty-estimation)
- [Business-policy evaluation](#business-policy-evaluation)
- [Comparing scalar and two-gap models](#comparing-scalar-and-two-gap-models)
- [Optuna hyperparameter optimization](#optuna-hyperparameter-optimization)
- [Hyperparameter ranges](#hyperparameter-ranges)
- [Optuna trial procedure](#optuna-trial-procedure)
- [Model inspection](#model-inspection)
- [Failure modes and dead ends](#failure-modes-and-dead-ends)
- [Model-selection gates](#model-selection-gates)
- [Recommended end-to-end sequence](#recommended-end-to-end-sequence)
- [Production monitoring](#production-monitoring)

**Part VI - Implementation blueprint and reference**

- [Core Python calculations](#core-python-calculations)
- [Custom two-gap linear estimator](#custom-two-gap-linear-estimator)
- [Pairwise LightGBM implementation pattern](#pairwise-lightgbm-implementation-pattern)
- [Pairwise XGBoost implementation pattern](#pairwise-xgboost-implementation-pattern)
- [Scalar XGBoost objective pattern](#scalar-xgboost-objective-pattern)
- [Optuna objective skeleton](#optuna-objective-skeleton)
- [Detailed instruction for an LLM modeling agent](#detailed-instruction-for-an-llm-modeling-agent)
- [Notation glossary](#notation-glossary)
- [Assumption checklist](#assumption-checklist)
- [Derivation summary](#derivation-summary)
- [References and software documentation](#references-and-software-documentation)
- [Closing perspective](#closing-perspective)

<!-- STATIC_CONTENTS_END -->

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```
# How to read this tutorial {.unnumbered}

This tutorial develops one problem from first principles: how to learn where a motor insurer can raise or lower a randomized quote price when the main business quantity is **relative price response**, not absolute conversion.

The presentation follows the dependency structure of the problem. A symbol is introduced before it is used. An assumption is stated before a result that depends on it. An algorithm is described only after its statistical target and loss have been derived.

The central model hierarchy is:

1. **No-effect model:** price does not change conversion.
2. **Two-gap model:** the high/control and low/control conversion risk ratios are estimated separately under monotone demand.
3. **Scalar model:** one elasticity function links both side arms through a chosen response curve, such as a constant-log-elasticity power law.
4. **Pairwise models:** two exact binary buyer models estimate the same two risk ratios separately and are convenient for standard tree libraries.

The two-gap model is not introduced as an ad hoc extension. With three tested prices and control used as the reference, there are exactly two independent relative risks. The two-gap model is therefore the saturated monotone model at the tested points. The scalar model is a one-dimensional restriction inside it.

The tutorial is intended for real randomized quote-level data. It contains no synthetic insurance leaderboard and makes no claim that a particular algorithm is best before it is evaluated on the insurer's experiment.

> **Practical conclusion in advance.** Use the global two-gap and global scalar models as structural anchors. Use calibrated pairwise LightGBM and XGBoost as the primary flexible tree implementations. Fit an exact joint two-gap linear or spline model when interpretability and coherent coupling matter. Treat Random Forest as a strongly smoothed robustness benchmark. Select personalization only when it improves held-out buyer likelihood, randomized risk-ratio calibration, temporal stability, and contribution value.

![Map of the elasticity-only modeling problem](figures/problem_map.png){width=96%}

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# Part I - Business target, data, and notation {.unnumbered}

# The business decision

## The product and the observed choice

The product is motor insurance. Insurance ownership may be legally mandatory, but accepting one particular insurer's quote is not. A customer can reject the quote and buy elsewhere, delay the decision, request a revised quote, change channel, or abandon the process.

The experimental outcome is therefore **own-quote conversion**: whether the customer accepts the displayed quote from this insurer within a prespecified outcome window.

## The tested price actions

Each eligible quote is assigned to one of three experimental price arms:

- the **high arm**, denoted by the letter \(H\), usually close to a 10% increase;
- the **control arm**, denoted by the letter \(C\), which uses the ordinary quote;
- the **low arm**, denoted by the letter \(L\), usually close to a 10% decrease.

The business wants to decide, for a future quote, which of these tested actions is most attractive. The immediate purpose is not to forecast the absolute number of policies sold. It is to find customer and quote contexts in which relative demand is sufficiently insensitive or sensitive to justify an adjustment.

## Contribution conditional on purchase

For a customer and quote context, let \(g_t\) denote the insurer's contribution **conditional on a sale** under arm \(t\). The symbol \(t\) is a generic arm label taking one of the values \(H\), \(C\), or \(L\).

The quantity \(g_t\) can include:

- displayed premium;
- expected claim cost;
- commissions, taxes, reinsurance, and capital charges;
- payment-processing and acquisition costs incurred only when a policy is sold;
- a carefully defined renewal or lifetime-value component, when that horizon is genuinely part of the pricing decision.

The contribution definition must be fixed before models are compared. Changing it after inspecting results converts evaluation into an unrecorded search over business objectives.

# Observation-level notation

This chapter defines the notation used throughout the tutorial.

## Quote index and pre-treatment features

A quote opportunity is indexed by

\[
i\in\{1,\ldots,N\},
\]

where \(N\) is the number of eligible randomized quote rows in the analysis population.

The vector

\[
X_i
\]

contains information available before the randomized price is displayed. It can include customer, driver, vehicle, coverage, tariff, channel, market, and time variables. A feature observed after the price is shown is not part of \(X_i\), because it may be affected by treatment and create leakage.

The lower-case letter \(x\) denotes a particular possible value of the feature vector. Thus, an expression such as \(q_H(x)\) describes a quantity for customers whose pre-treatment context equals \(x\).

## Randomized arm

The assigned price arm is

\[
T_i\in\{H,C,L\}.
\]

The probability that quote \(i\) is assigned to arm \(t\) is

\[
\pi_{i,t}=P(T_i=t\mid X_i, B_i),
\]

where \(B_i\) denotes any randomization-block information used by the experimental system, such as date, quota, channel, or experiment cell. The vector

\[
\pi_i=(\pi_{i,H},\pi_{i,C},\pi_{i,L})
\]

is called the **assignment-propensity vector** or **logging-probability vector**.

For a fixed 10%/80%/10% design,

\[
\pi_{i,H}=0.1,\qquad
\pi_{i,C}=0.8,\qquad
\pi_{i,L}=0.1
\]

for every eligible quote. Real systems can vary these probabilities by row, so the logged values should be used whenever they exist.

## Purchase outcome

The conversion outcome is

\[
Y_i=
\begin{cases}
1, & \text{if quote }i\text{ is purchased within the outcome window},\\
0, & \text{otherwise.}
\end{cases}
\]

A row with \(Y_i=1\) is called a **buyer row**. The number of buyer rows is denoted by

\[
N_B=\sum_{i=1}^N Y_i.
\]

## Displayed prices, price multipliers, and log-price doses

Let

\[
P_{i,t}>0
\]

be the price that quote \(i\) would display under arm \(t\). The arm-specific price multiplier relative to control is

\[
m_{i,t}=\frac{P_{i,t}}{P_{i,C}}.
\]

By definition,

\[
m_{i,C}=1.
\]

For exact nominal arms,

\[
m_{i,H}=1.10,\qquad m_{i,C}=1,
\qquad m_{i,L}=0.90.
\]

The corresponding log-price dose is

\[
z_{i,t}=\log m_{i,t}=\log\frac{P_{i,t}}{P_{i,C}}.
\]

Therefore,

\[
z_{i,C}=0,
\]

while \(z_{i,H}>0\) and \(z_{i,L}<0\). The log-dose representation is convenient because percentage price changes compose additively on the log scale.

## Arm-specific conversion risk

For an arm \(t\) and context \(x\), define

\[
q_t(x)=P(Y=1\mid T=t,X=x).
\]

The word **risk** here means a probability. It does not refer to expected insurance claims.

The three quantities \(q_H(x)\), \(q_C(x)\), and \(q_L(x)\) are the arm-specific conversion risks.

## Buyer-arm probability

Among buyers with context \(x\), define

\[
r_t(x)=P(T=t\mid Y=1,X=x).
\]

The vector

\[
r(x)=(r_H(x),r_C(x),r_L(x))
\]

is the **buyer-arm distribution**. It is the prediction target in the Bayes-flip formulation.

## Risk ratios

Control is used as the reference arm. The high-versus-control and low-versus-control conversion risk ratios are

\[
RR_{HC}(x)=\frac{q_H(x)}{q_C(x)},
\qquad
RR_{LC}(x)=\frac{q_L(x)}{q_C(x)}.
\]

The notation \(RR_{HC}\) means "risk in \(H\) divided by risk in \(C\)." Likewise, \(RR_{LC}\) means "risk in \(L\) divided by risk in \(C\)." We set

\[
RR_{CC}(x)=1.
\]

## Expected contribution and price rule

The expected contribution per quote under arm \(t\) is

\[
V_t(x)=q_t(x)g_t(x).
\]

The selected arm is denoted by

\[
d(x)\in\{H,C,L\}.
\]

The symbol \(d^*(x)\) will denote the arm that maximizes the stated expected-contribution objective.

# Experimental assumptions

Every causal interpretation in this tutorial relies on the following assumptions. They must be audited rather than treated as background conventions.

## Eligibility and analysis population

The analysis population must be the set of quotes that were genuinely eligible for randomization. Excluding rows after observing treatment or purchase can destroy the randomized comparison.

The inclusion rule, outcome window, duplicate-quote rule, and treatment of incomplete transactions must be defined before model selection.

## Consistency

For each quote, imagine three potential purchase outcomes:

\[
Y_i(H),\qquad Y_i(C),\qquad Y_i(L).
\]

The potential outcome \(Y_i(t)\) is the purchase outcome that would occur if quote \(i\) were assigned to arm \(t\).

The **consistency assumption** states that the observed outcome equals the potential outcome under the assigned arm:

\[
Y_i=Y_i(T_i).
\]

Consistency requires the arm to represent a well-defined intervention. If "high arm" sometimes changes payment frequency, coverage, or underwriting treatment in addition to price, then the effect is not a pure price effect.

## Randomization

Conditional on the information used by the experiment, assignment must be independent of the potential outcomes:

\[
T_i\perp\{Y_i(H),Y_i(C),Y_i(L)\}\mid X_i,B_i.
\]

The symbol \(\perp\) means statistical independence.

Randomization protects the comparison from confounding by unmeasured tariff error, competitor position, and customer intent, provided those quantities did not influence assignment beyond the logged block information.

## Positivity

Every arm that is to be compared must have positive assignment probability:

\[
\pi_{i,t}>0.
\]

If a segment was never assigned to the high arm, the high-price effect is not identified in that segment without extrapolation.

## No harmful interference

One quote's assigned price should not materially change another quote's purchase outcome in a way that is ignored by the analysis. This is especially relevant when one customer, household, broker, or device can receive several quotes.

Repeated customers should be kept in one validation fold. The experiment audit should identify customers who saw multiple arms, because their later behavior may depend on earlier exposure.

## Correctly logged propensities

The probabilities \(\pi_{i,t}\) used in the model must correspond to the actual assignment mechanism. Nominal 10%/80%/10% values are not sufficient when quotas, experiment pauses, or channel-specific rules changed the realized logging probabilities.

## Intention to treat and realized dose

The primary causal treatment is normally the randomized arm. This is called the **intention-to-treat** estimand.

Rounding, minimum premiums, instalment rules, or underwriting mechanics can make the realized multiplier \(m_{i,t}\) differ from the nominal value. The row-level realized dose can be used in a dose-aware structural model, but the randomized assignment should remain the causal instrument unless a separate compliance analysis is justified.

# Part II - Identification and elasticity {.unnumbered}

# The Bayes-flip identity

## Derivation

Bayes' rule gives, for any arm \(t\),

\[
P(T=t\mid Y=1,X=x)
=
\frac{P(T=t\mid X=x)P(Y=1\mid T=t,X=x)}
{P(Y=1\mid X=x)}.
\]

Using the notation already defined,

\[
r_t(x)
=
\frac{\pi_t(x)q_t(x)}
{\sum_{j\in\{H,C,L\}}\pi_j(x)q_j(x)}.
\]

The index \(j\) is a temporary summation index over the three arms.

Divide the expression for arm \(t\) by the expression for control:

\[
\frac{r_t(x)}{r_C(x)}
=
\frac{\pi_t(x)q_t(x)}{\pi_C(x)q_C(x)}.
\]

Rearranging gives the exact identity

\[
\boxed{
RR_{tC}(x)
=
\frac{q_t(x)}{q_C(x)}
=
\frac{r_t(x)/\pi_t(x)}
{r_C(x)/\pi_C(x)}.
}
\]

No rare-event approximation is used. The identity follows from randomization and Bayes' rule.

![Bayes-flip identification of relative conversion risk](figures/bayes_flip.png){width=96%}

## Fixed 10%/80%/10% design

When

\[
\pi_H=0.1,\qquad \pi_C=0.8,\qquad \pi_L=0.1,
\]

we obtain

\[
RR_{HC}(x)=\frac{8r_H(x)}{r_C(x)},
\]

and

\[
RR_{LC}(x)=\frac{8r_L(x)}{r_C(x)}.
\]

## Monotone demand

The economically usual monotonicity condition is

\[
q_H(x)\le q_C(x)\le q_L(x).
\]

In risk-ratio form,

\[
RR_{HC}(x)\le1,
\qquad
RR_{LC}(x)\ge1.
\]

Using the Bayes-flip identity, the general propensity-adjusted condition is

\[
\boxed{
\frac{r_H(x)}{\pi_H(x)}
\le
\frac{r_C(x)}{\pi_C(x)}
\le
\frac{r_L(x)}{\pi_L(x)}.
}
\]

Under fixed 10%/80%/10% assignment, this becomes

\[
\boxed{
r_H(x)\le \frac{r_C(x)}{8}\le r_L(x).
}
\]

Weak inequalities are appropriate. Equality represents no response on that side.

## What buyer-only data identify

The buyer-arm distribution identifies relative conversion risks. It does not identify the absolute conversion scale.

To see this, multiply all three conversion probabilities by the same positive factor \(a(x)\), small enough to keep them below one:

\[
q'_t(x)=a(x)q_t(x).
\]

The factor cancels from the buyer posterior, so \(r_t(x)\) is unchanged. Therefore, buyer-only data cannot determine \(q_C(x)\) or absolute sales volume without additional information.

That limitation is acceptable when the immediate decision among tested prices depends only on relative demand and per-sale contribution.

# Elasticity conventions

The Bayes-flip model directly identifies risk ratios. An elasticity is a deterministic summary of a risk ratio and a price ratio. Different elasticity conventions answer slightly different questions.

## Standard finite relative-change elasticity

For a reference price \(P_0\), alternative price \(P_1\), reference conversion \(q_0\), and alternative conversion \(q_1\), define

\[
m=\frac{P_1}{P_0},
\qquad
R=\frac{q_1}{q_0}.
\]

The standard finite relative-change elasticity is

\[
\varepsilon^{\mathrm{rel}}_{0\to1}
=
\frac{(q_1-q_0)/q_0}{(P_1-P_0)/P_0}
=
\boxed{\frac{R-1}{m-1}}.
\]

It is directional because the initial values appear in the denominators.

For a 10% high arm,

\[
\varepsilon^{\mathrm{rel}}_{HC}(x)
=
\frac{RR_{HC}(x)-1}{0.10}.
\]

For a 10% low arm,

\[
\varepsilon^{\mathrm{rel}}_{LC}(x)
=
\frac{RR_{LC}(x)-1}{-0.10}.
\]

Under decreasing demand, both signed elasticities are nonpositive.

## Point elasticity

If conversion is represented by a differentiable function \(q(p,x)\) of price \(p\), point elasticity is

\[
\varepsilon(p,x)
=
\frac{p}{q(p,x)}
\frac{\partial q(p,x)}{\partial p}.
\]

By the chain rule,

\[
\boxed{
\varepsilon(p,x)
=
\frac{\partial\log q(p,x)}{\partial\log p}.
}
\]

This logarithmic derivative is exactly the ordinary point elasticity.

## Log-change finite elasticity

For two tested points, define

\[
\varepsilon^{\log}_{0,1}
=
\frac{\log q_1-\log q_0}{\log P_1-\log P_0}
=
\boxed{\frac{\log R}{\log m}}.
\]

This is the secant slope in the \((\log p,\log q)\) plane. It is symmetric under reversing the two endpoints and equals the average point elasticity over the interval when averaging uniformly in log price.

## Midpoint arc elasticity

A symmetric arithmetic alternative is

\[
\varepsilon^{\mathrm{mid}}_{0,1}
=
\frac{(q_1-q_0)/[(q_1+q_0)/2]}
{(P_1-P_0)/[(P_1+P_0)/2]}.
\]

In terms of \(R\) and \(m\),

\[
\varepsilon^{\mathrm{mid}}
=
\frac{R-1}{R+1}
\frac{m+1}{m-1}.
\]

## Exact conversion between finite conventions

The standard and log-change definitions use the same information. Their exact relationship is

\[
\varepsilon^{\log}
=
\frac{\log[1+\varepsilon^{\mathrm{rel}}(m-1)]}{\log m},
\]

and

\[
\varepsilon^{\mathrm{rel}}
=
\frac{m^{\varepsilon^{\log}}-1}{m-1}.
\]

The primary model should usually estimate \(R\) or \(\log R\). Reporting conventions can then be applied after prediction without changing the likelihood.

# Price choice from relative demand

## Cancellation of the base conversion factor

Recall that

\[
V_t(x)=q_t(x)g_t(x).
\]

Because

\[
q_t(x)=q_C(x)RR_{tC}(x),
\]

we have

\[
V_t(x)=q_C(x)RR_{tC}(x)g_t(x).
\]

For a fixed context \(x\), the positive factor \(q_C(x)\) is common to every tested arm. Therefore,

\[
\boxed{
d^*(x)=\arg\max_{t\in\{H,C,L\}}g_t(x)RR_{tC}(x).
}
\]

![Relative demand and contribution determine the tested-price choice](figures/business_decision.png){width=95%}

## Relative contribution scores

Control can be used as a benchmark. Define

\[
S_H(x)
=
\log\frac{g_H(x)}{g_C(x)}
+
\log RR_{HC}(x),
\]

and

\[
S_L(x)
=
\log\frac{g_L(x)}{g_C(x)}
+
\log RR_{LC}(x).
\]

A positive \(S_H(x)\) means that high price is predicted to have larger expected contribution than control. A positive \(S_L(x)\) has the analogous interpretation for the low price.

## When absolute conversion returns to the problem

The cancellation no longer solves the full business problem when the objective contains terms that are not multiplied by purchase probability, or when portfolio constraints depend on absolute volume. Examples include quote-level operational costs, sales-capacity limits, market-share constraints, and absolute fairness constraints.

In those cases, a base-conversion model can be added as a secondary component. It is not required to define or train the elasticity-only buyer model.

# Part III - The model hierarchy {.unnumbered}

# Why three prices imply two relative-response degrees of freedom

At a fixed context \(x\), the three conversion risks are

\[
q_H(x),\qquad q_C(x),\qquad q_L(x).
\]

Buyer conditioning removes their common scale. After choosing control as the reference, the remaining relative information is exactly

\[
RR_{HC}(x),\qquad RR_{LC}(x).
\]

There are therefore two independent relative-response degrees of freedom.

A model that estimates these two risk ratios without an additional equality restriction is called a **two-gap model** in this tutorial. A model that forces both ratios to be generated by one elasticity function is called a **scalar model**.

# Global anchor models

## No-effect model

The no-effect hypothesis is

\[
q_H(x)=q_C(x)=q_L(x).
\]

It implies

\[
RR_{HC}(x)=RR_{LC}(x)=1
\]

and

\[
r_t(x)=\pi_t(x).
\]

The no-effect buyer cross-entropy is the first benchmark. Any price-response model must improve on it out of fold before its heterogeneity is interpreted.

## Global two-gap model

The global two-gap model assumes that the two relative risks are constant across contexts but not necessarily related to one another:

\[
RR_{HC}(x)=RR_{HC},
\qquad
RR_{LC}(x)=RR_{LC}.
\]

It estimates one portfolio high-side response and one portfolio low-side response.

## Global scalar model

The global scalar model assumes one portfolio elasticity magnitude \(\beta\) and a chosen structural response curve that determines both risk ratios. Under the constant-log-elasticity power law,

\[
RR_{tC}=\exp(-\beta z_t).
\]

The global scalar model has lower variance than the global two-gap model when its equality restriction is approximately correct.

# The scalar constant-log-elasticity model

## Structural assumption

Let

\[
q(p,x)=P(Y=1\mid \text{displayed price}=p,X=x)
\]

be a positive conversion curve as a function of price.

Define the nonnegative magnitude of point elasticity by

\[
\beta(p,x)
=-\frac{\partial\log q(p,x)}{\partial\log p}.
\]

The scalar constant-log-elasticity model assumes that, for a fixed context \(x\), this magnitude is approximately constant over the tested price interval:

\[
\beta(p,x)=\beta(x)\ge0.
\]

Integrating the differential equation from control price to arm price gives

\[
\log RR_{tC}(x)=-\beta(x)z_t(x),
\]

or

\[
\boxed{
RR_{tC}(x)=\exp[-\beta(x)z_t(x)]
=m_t(x)^{-\beta(x)}.
}
\]

The power law is therefore the exact solution of the constant-point-elasticity assumption. It can also be viewed as a first-order log-price approximation to a smooth demand curve around control.

## Testable restriction

For fixed nominal prices, the scalar model requires

\[
-\frac{\log RR_{HC}(x)}{\log1.10}
=
-\frac{\log RR_{LC}(x)}{\log0.90}
=
\beta(x).
\]

This equality is not implied by Bayes' rule. It is a model restriction that must be tested against the two-gap alternative.

## Buyer-arm probabilities under a candidate elasticity

For buyer \(i\), let

\[
\beta_i=\beta(X_i).
\]

The buyer-arm probability implied by a candidate \(\beta_i\) is

\[
\boxed{
r_{i,t}(\beta_i)
=
\frac{\pi_{i,t}\exp(-\beta_i z_{i,t})}
{\sum_j\pi_{i,j}\exp(-\beta_i z_{i,j})}.
}
\]

The unknown control conversion risk cancels.

## Scalar buyer loss

The observed response for buyer \(i\) is the arm label \(T_i\). The categorical negative log-likelihood is

\[
\ell_i^{\mathrm{scalar}}(\beta_i)
=-\log r_{i,T_i}(\beta_i).
\]

Expanding it gives

\[
\ell_i^{\mathrm{scalar}}(\beta_i)
=
\beta_i z_{i,T_i}
+
\log\sum_j\pi_{i,j}\exp(-\beta_i z_{i,j})
-
\log\pi_{i,T_i}.
\]

The model does not regress on an observed elasticity label. It chooses a shared function \(x\mapsto\beta(x)\) that makes the observed randomized arms of buyers probable.

## Scalar derivatives

Define the model-implied mean log-price dose

\[
\mu_i=\sum_t r_{i,t}z_{i,t}.
\]

Then

\[
\frac{\partial\ell_i^{\mathrm{scalar}}}{\partial\beta_i}
=z_{i,T_i}-\mu_i,
\]

and

\[
\frac{\partial^2\ell_i^{\mathrm{scalar}}}{\partial\beta_i^2}
=
\operatorname{Var}_{r_i}(z_i)\ge0.
\]

The scalar loss is convex in the direct elasticity parameter \(\beta_i\).

![Learning a heterogeneous scalar elasticity function from buyer arm labels](figures/scalar_power_learning.png){width=96%}

# The two-gap model

## Why a two-gap model is the natural unrestricted model at three prices

The scalar model forces two risk ratios to lie on a one-dimensional curve. The experiment itself identifies two ratios. To retain both degrees of freedom, define the nonnegative **high-price gap**

\[
\boxed{
u(x)=\log\frac{q_C(x)}{q_H(x)}=-\log RR_{HC}(x)\ge0,
}
\]

and the nonnegative **low-price gap**

\[
\boxed{
v(x)=\log\frac{q_L(x)}{q_C(x)}=\log RR_{LC}(x)\ge0.
}
\]

The symbol \(u\) is used for the loss of conversion caused by the high price. The symbol \(v\) is used for the conversion gain associated with the low price.

The corresponding risk ratios are

\[
RR_{HC}(x)=e^{-u(x)},
\qquad
RR_{LC}(x)=e^{v(x)}.
\]

Every strictly positive monotone pair of risk ratios can be represented by exactly one pair \((u,v)\). Thus, the two-gap form is an exact reparameterization of the monotone model at the three tested points.

It makes no assumption about a continuous demand curve between or beyond those points.

## Relation to the scalar model

For a constant-log-elasticity scalar model,

\[
u(x)=\beta(x)z_H(x),
\]

and

\[
v(x)=\beta(x)[-z_L(x)].
\]

Therefore, the scalar model is the line

\[
\frac{u(x)}{z_H(x)}
=
\frac{v(x)}{-z_L(x)}
=
\beta(x)
\]

inside the two-dimensional two-gap space.

![The scalar model is a one-dimensional restriction inside the two-gap space](figures/two_gap_model_nesting.png){width=94%}

## Buyer-arm probabilities under two gaps

Substitute

\[
q_H(x)=q_C(x)e^{-u(x)},
\qquad
q_L(x)=q_C(x)e^{v(x)}
\]

into the Bayes-flip identity. The common factor \(q_C(x)\) cancels, giving

\[
\boxed{
r_H(x)
=
\frac{\pi_H(x)e^{-u(x)}}
{D(x)},
}
\]

\[
\boxed{
r_C(x)
=
\frac{\pi_C(x)}{D(x)},
}
\]

and

\[
\boxed{
r_L(x)
=
\frac{\pi_L(x)e^{v(x)}}{D(x)},
}
\]

where the normalizing quantity is

\[
D(x)
=
\pi_H(x)e^{-u(x)}
+
\pi_C(x)
+
\pi_L(x)e^{v(x)}.
\]

Equivalently,

\[
\boxed{
r(x)
=
\operatorname{softmax}
\left(
\log\pi(x)+[-u(x),0,v(x)]
\right).
}
\]

The function \(\operatorname{softmax}\) converts a vector of real-valued logits \(a=(a_H,a_C,a_L)\) into probabilities:

\[
\operatorname{softmax}(a)_t
=
\frac{e^{a_t}}{e^{a_H}+e^{a_C}+e^{a_L}}.
\]

![Exact learning path for the heterogeneous two-gap model](figures/two_gap_learning.png){width=98%}

## Exact two-gap buyer loss

For buyer \(i\), write

\[
u_i=u(X_i),
\qquad
v_i=v(X_i).
\]

The row loss is categorical cross-entropy:

\[
\ell_i^{\mathrm{gap}}(u_i,v_i)
=-\log r_{i,T_i}.
\]

Using indicator notation, let \(\mathbf{1}\{A\}\) equal one when statement \(A\) is true and zero otherwise. The expanded loss is

\[
\boxed{
\ell_i^{\mathrm{gap}}
=
\log D_i
+
\mathbf{1}\{T_i=H\}u_i
-
\mathbf{1}\{T_i=L\}v_i
-
\log\pi_{i,T_i}.
}
\]

The term \(-\log\pi_{i,T_i}\) is known from the experiment. It does not affect the optimum but should be retained when reporting the full predictive log loss.

## Gradients with respect to the direct gaps

Let

\[
r_{i,H},\qquad r_{i,C},\qquad r_{i,L}
\]

be the three buyer-arm probabilities produced by the current \((u_i,v_i)\).

The high-gap gradient is

\[
\boxed{
\frac{\partial\ell_i^{\mathrm{gap}}}{\partial u_i}
=
\mathbf{1}\{T_i=H\}-r_{i,H}.
}
\]

The low-gap gradient is

\[
\boxed{
\frac{\partial\ell_i^{\mathrm{gap}}}{\partial v_i}
=
r_{i,L}-\mathbf{1}\{T_i=L\}.
}
\]

These signs have direct interpretations:

- a high-arm buyer tends to reduce the fitted high gap, because buying at the high price is evidence of weaker high-side sensitivity;
- a low-arm buyer tends to increase the fitted low gap, because an excess of low-arm buyers is evidence of stronger low-side response;
- control buyers affect both gaps through the common normalization.

## Hessian and convexity

The exact Hessian with respect to the direct gap vector \((u_i,v_i)\) is

\[
\boxed{
H_i^{(u,v)}
=
\begin{pmatrix}
r_{i,H}(1-r_{i,H}) & r_{i,H}r_{i,L}\\
r_{i,H}r_{i,L} & r_{i,L}(1-r_{i,L})
\end{pmatrix}.
}
\]

This matrix is positive semidefinite, meaning that $a^\top H_i^{(u,v)}a\ge0$ for every two-dimensional vector $a$. Its determinant is

\[
r_{i,H}r_{i,L}r_{i,C}\ge0.
\]

Therefore, the row loss is jointly convex in the direct gaps.

The nonzero off-diagonal term \(r_{i,H}r_{i,L}\) means the two targets are statistically coupled. Increasing one gap changes the normalization and therefore changes all three buyer-arm probabilities.

## Learning heterogeneous gaps

Choose two real-valued functions

\[
f_H(x)\in\mathbb{R},
\qquad
f_L(x)\in\mathbb{R}.
\]

The functions can be linear predictors, splines, boosted trees, or another supervised-learning model.

To enforce nonnegative gaps, use the softplus transformation

\[
\operatorname{softplus}(a)=\log(1+e^a).
\]

Define

\[
\boxed{
u(x)=\operatorname{softplus}[f_H(x)],
}
\]

and

\[
\boxed{
v(x)=\operatorname{softplus}[f_L(x)].
}
\]

Let \(\theta\) denote all trainable parameters in \(f_H\) and \(f_L\). The generic penalized objective is

\[
\boxed{
J(\theta)
=
\frac{1}{\sum_{i:Y_i=1}w_i}
\sum_{i:Y_i=1}w_i
\ell_i^{\mathrm{gap}}
+
\lambda\Omega(\theta).
}
\]

The optional weight \(w_i\ge0\) is fixed before fitting. The function \(\Omega(\theta)\) penalizes complexity, and \(\lambda\ge0\) controls the amount of shrinkage.

## Raw-score gradients

Let

\[
s_H(x)=\sigma[f_H(x)],
\qquad
s_L(x)=\sigma[f_L(x)],
\]

where

\[
\sigma(a)=\frac{1}{1+e^{-a}}
\]

is the logistic sigmoid. The sigmoid is the derivative of softplus.

The gradients with respect to the raw scores are

\[
\boxed{
\frac{\partial\ell_i^{\mathrm{gap}}}{\partial f_H(X_i)}
=
[\mathbf{1}\{T_i=H\}-r_{i,H}]s_H(X_i),
}
\]

and

\[
\boxed{
\frac{\partial\ell_i^{\mathrm{gap}}}{\partial f_L(X_i)}
=
[r_{i,L}-\mathbf{1}\{T_i=L\}]s_L(X_i).
}
\]

These are the gradients used by the exact linear implementation and by any custom differentiable learner.

## Fisher curvature and tree-library limitation

After the softplus transformation, the exact raw-score Hessian contains terms involving the second derivative of softplus. Those terms can make an individual observed-row Hessian indefinite even though the loss is convex in the direct gaps.

The **Fisher curvature** is the conditional expectation of the observed Hessian under the model. A positive Fisher or Gauss-Newton curvature is

\[
H_i^{F}
=
J_i^{\top}H_i^{(u,v)}J_i,
\]

where

\[
J_i=
\begin{pmatrix}
s_H(X_i)&0\\
0&s_L(X_i)
\end{pmatrix}.
\]

Its off-diagonal element is

\[
r_{i,H}r_{i,L}s_H(X_i)s_L(X_i).
\]

Standard custom-objective interfaces in tree libraries commonly expect one Hessian value per output and do not accept the exact cross-output Hessian. This is why the exact joint two-gap model is straightforward with a general optimizer but less natural in LightGBM or XGBoost. A diagonal Fisher approximation can be used, but it discards the cross-gap curvature.

## Gap model versus side-specific slope model

When the high and low multipliers are fixed, predicting \(u(x)\) and \(v(x)\) directly is sufficient.

When realized doses vary materially by row, it is usually better to define positive side-specific log-elasticity magnitudes

\[
\beta_H(x)\ge0,
\qquad
\beta_L(x)\ge0,
\]

and set

\[
\boxed{
u_i=\beta_H(X_i)[z_{i,H}-z_{i,C}],
}
\]

\[
\boxed{
v_i=\beta_L(X_i)[z_{i,C}-z_{i,L}].
}
\]

Because \(z_{i,C}=0\), the two positive dose distances are \(z_{i,H}\) and \(-z_{i,L}\).

This **two-slope parameterization** is still a two-gap model at each row, but it separates response magnitude from the actual price distance.

## Standard finite elasticities from two gaps

For the high arm,

\[
RR_{HC}(x)=e^{-u(x)}.
\]

Therefore, the standard finite signed elasticity is

\[
\boxed{
\varepsilon_{HC}^{\mathrm{rel}}(x)
=
\frac{e^{-u(x)}-1}{m_H(x)-1}.
}
\]

For the low arm,

\[
RR_{LC}(x)=e^{v(x)},
\]

so

\[
\boxed{
\varepsilon_{LC}^{\mathrm{rel}}(x)
=
\frac{e^{v(x)}-1}{m_L(x)-1}.
}
\]

The denominator of the low-side formula is negative, so the signed elasticity is negative under monotone demand.

The side-specific log-change elasticities are

\[
\boxed{
\varepsilon_{HC}^{\log}(x)
=-\frac{u(x)}{\log m_H(x)},
}
\]

and

\[
\boxed{
\varepsilon_{LC}^{\log}(x)
=\frac{v(x)}{\log m_L(x)}.
}
\]

Because \(\log m_L(x)<0\), the second quantity is also negative.

## Shrinkage toward the scalar restriction

The two-gap model has more variance than the scalar model. A principled compromise is to shrink the side-specific log-elasticity magnitudes toward one another.

Define

\[
b_H(x)=\frac{u(x)}{z_H(x)},
\qquad
b_L(x)=\frac{v(x)}{-z_L(x)}.
\]

Both are nonnegative magnitudes. Add the penalty

\[
\boxed{
\Omega_{\mathrm{asym}}
=
\frac{1}{N_B}
\sum_{i:Y_i=1}
[b_H(X_i)-b_L(X_i)]^2.
}
\]

A tuning parameter \(\lambda_{\mathrm{asym}}\) controls how strongly the model is pulled toward a common scalar elasticity:

- \(\lambda_{\mathrm{asym}}=0\) gives a freely asymmetric two-gap model;
- a moderate value allows asymmetry only when supported by data;
- a very large value approaches the scalar restriction.

This continuous bridge is preferable to treating the scalar and two-gap models as unrelated competitors.

## What asymmetry does and does not mean

A difference between \(b_H(x)\) and \(b_L(x)\) is evidence that the two tested finite responses are not described well by one common log-log slope. It is not, by itself, proof of a particular continuous curvature function.

Only three price points are observed. Infinitely many demand curves can pass through them.

Furthermore, marginal asymmetry can arise even if each latent customer has constant elasticity. If unobserved customers have different baseline conversion and different elasticities, averaging their risks can create a nonlinear marginal log-risk curve. The two-gap model then captures a valid marginal finite response, not necessarily individual-level curvature.

# Pairwise models

## High versus control

Restrict attention to buyers whose observed arm is either \(H\) or \(C\). Define the binary label

\[
A_{HC,i}
=
\begin{cases}
1,&T_i=H,\\
0,&T_i=C.
\end{cases}
\]

For a probability $p\in(0,1)$, define its **logit** by

\[
\operatorname{logit}(p)=\log\frac{p}{1-p}.
\]

Then

\[
P(A_{HC}=1\mid Y=1,T\in\{H,C\},X=x)
=
\frac{\pi_H(x)q_H(x)}
{\pi_H(x)q_H(x)+\pi_C(x)q_C(x)}.
\]

Taking logits gives

\[
\boxed{
\operatorname{logit}P(A_{HC}=1\mid\cdots)
=
\log\frac{\pi_H(x)}{\pi_C(x)}
+
\log RR_{HC}(x).
}
\]

The first term is a known offset. The unknown function is the high/control log risk ratio.

## Low versus control

For buyers in \(L\) or \(C\), define

\[
A_{LC,i}
=
\begin{cases}
1,&T_i=L,\\
0,&T_i=C.
\end{cases}
\]

Then

\[
\boxed{
\operatorname{logit}P(A_{LC}=1\mid\cdots)
=
\log\frac{\pi_L(x)}{\pi_C(x)}
+
\log RR_{LC}(x).
}
\]

## Relation to the two-gap model

The exact joint two-gap likelihood uses all three arms in one categorical normalization. The pairwise approach fits two exact binary conditional likelihoods:

\[
\log RR_{HC}(x)=-u(x),
\qquad
\log RR_{LC}(x)=v(x).
\]

Under correct specification, both approaches target the same risk-ratio functions. They are not numerically identical estimators:

- the joint likelihood couples the two gaps through one normalization;
- the pairwise approach uses control buyers in both binary fits;
- the product of the two pairwise likelihoods is a composite likelihood, not the original categorical likelihood;
- pairwise models are much easier to implement with standard binary tree libraries and row-level offsets.

![Joint two-gap likelihood and pairwise composite likelihood](figures/joint_vs_pairwise.png){width=96%}

## Coherent reconstruction

Suppose the high/control pairwise model predicts

\[
a(x)=P(H\mid T\in\{H,C\},Y=1,X=x).
\]

The corresponding odds are

\[
\frac{a(x)}{1-a(x)}
=
\frac{\pi_H(x)q_H(x)}{\pi_C(x)q_C(x)}
=
\frac{\pi_H(x)}{\pi_C(x)}RR_{HC}(x).
\]

Therefore,

\[
\boxed{
RR_{HC}(x)
=
\frac{\pi_C(x)}{\pi_H(x)}
\frac{a(x)}{1-a(x)}.
}
\]

Similarly, if

\[
b(x)=P(L\mid T\in\{L,C\},Y=1,X=x),
\]

then

\[
\boxed{
RR_{LC}(x)
=
\frac{\pi_C(x)}{\pi_L(x)}
\frac{b(x)}{1-b(x)}.
}
\]

The original, unweighted pairwise odds also equal the full buyer-posterior ratios

\[
A_r(x)=\frac{r_H(x)}{r_C(x)}=\frac{a(x)}{1-a(x)},
\]

and

\[
B_r(x)=\frac{r_L(x)}{r_C(x)}=\frac{b(x)}{1-b(x)}.
\]

Consequently, the coherent three-class buyer posterior is

\[
r_C(x)=\frac{1}{1+A_r(x)+B_r(x)},
\]

\[
r_H(x)=A_r(x)r_C(x),
\qquad
r_L(x)=B_r(x)r_C(x).
\]

This reconstruction is different from fitting two one-versus-rest classifiers, whose probabilities need not be mutually compatible.

# Choosing between scalar, two-gap, and pairwise formulations

The model families answer different questions.

| Formulation | Unknown response functions | Main assumption | Main advantage | Main risk |
|---|---:|---|---|---|
| Scalar power law | one \(\beta(x)\) | one common log-log slope | low variance, automatic monotonicity | bias under asymmetric response |
| Joint two-gap | \(u(x),v(x)\) | monotonicity only at tested points | exact saturated three-price model | higher variance, harder tree objective |
| Two pairwise models | \(\log RR_{HC}(x),\log RR_{LC}(x)\) | separate binary specifications | standard LightGBM/XGBoost tooling | composite rather than joint likelihood |
| Unrestricted multiclass classifier | two effective logits | no structural risk-ratio parameterization | easy generic benchmark | poor calibration and incoherent monotonicity without correction |

The global scalar model should be the minimum-complexity anchor. The global two-gap model tests whether the two sides disagree at portfolio level. Flexible pairwise and joint two-gap models test whether that response varies with context.

# Part IV - Learning the models in Python {.unnumbered}

# Common learning concepts

## Parameters and hyperparameters

A **parameter** is learned directly by minimizing a training loss. Examples are a logistic-regression coefficient and a tree leaf value.

A **hyperparameter** controls the learning procedure but is not estimated by the inner optimizer. Examples are tree depth, learning rate, minimum leaf size, and the strength of a regularization penalty. Hyperparameters are selected using validation data inside a nested resampling design.

## Loss, likelihood, and cross-entropy

A **likelihood** assigns a probability to the observed data under a candidate model. The **negative log-likelihood** is the negative logarithm of that probability.

For a categorical outcome with predicted probabilities \(p_H,p_C,p_L\) and observed class \(T\), the categorical cross-entropy is

\[
-\log p_T.
\]

Thus, categorical cross-entropy and categorical negative log-likelihood are the same row-level quantity.

For a binary label \(A\in\{0,1\}\) with predicted probability \(p\), binary cross-entropy is

\[
-A\log p-(1-A)\log(1-p).
\]

Cross-entropy is a **proper probability loss**: in expectation, it is minimized by the true conditional probabilities. This is why it is more suitable for risk-ratio estimation than accuracy, the area under a receiver-operating-characteristic curve, or a multiclass ranking volume.

## Gradient and Hessian

A **gradient** is the vector of first derivatives of a loss with respect to model outputs or parameters. A **Hessian** is the matrix of second derivatives. Gradient boosting uses gradients to determine the direction of improvement and Hessian information to scale local updates.

## Raw scores and links

Many machine-learning algorithms first predict an unrestricted real number called a **raw score**, **margin**, or **linear predictor**.

A **link function** transforms the raw score into a constrained quantity. Examples used in this tutorial are:

- logistic sigmoid, which maps a raw score to a probability;
- softplus, which maps a raw score to a positive gap or elasticity magnitude;
- softmax, which maps several logits to a categorical probability vector.

## Offset

An **offset** is a known additive term in a linear predictor. It is not learned.

In a pairwise buyer model, the propensity log odds

\[
\log\frac{\pi_t(x)}{\pi_C(x)}
\]

are a known offset. The learner estimates only \(\log RR_{tC}(x)\).

## Regularization

**Regularization** penalizes model complexity to reduce variance and prevent the learner from fitting random fluctuations in side-arm buyer counts.

Examples include:

- an L2 penalty on coefficients or leaf values;
- an L1 penalty that can set coefficients to zero;
- large minimum leaf sizes;
- shallow trees;
- feature and row subsampling;
- shrinkage of the two side-specific elasticities toward one another;
- calibration-slope shrinkage toward a global response.

# Data preparation and feature processing

## Buyer rows for response-shape learning

The scalar, joint two-gap, and pairwise response-shape models are fitted on rows with

\[
Y_i=1.
\]

The complete eligible quote table is still needed for experiment auditing and randomized policy evaluation. Restricting the modeling table to buyers does not justify discarding nonbuyers from the source data.

## Feature eligibility

A feature can be used only when it was available before the randomized price was displayed and could not have been caused by the displayed arm.

Potentially useful elasticity modifiers include:

- base premium before the experimental multiplier;
- expected claim cost and technical margin components;
- tariff version and tariff uncertainty diagnostics;
- premium band and vehicle-value band;
- channel, device, and new-business or renewal status;
- competitor rank or competitor-price gap when lawfully available before treatment;
- quote time, market period, and geography;
- previous-insurer and prior-premium information when available before treatment.

Variables such as post-price page views, negotiation behavior, later quote revisions, or payment-choice changes can be mediators and must not be used as ordinary pre-treatment predictors.

## Fold-local preprocessing

Every transformation that learns from data must be fitted inside the training portion of a validation fold. Examples include:

- imputation values;
- category-frequency thresholds;
- one-hot-encoding categories;
- scaling means and variances;
- spline knots;
- interaction selection;
- target or impact encodings.

Applying a transformation to the full dataset before cross-validation leaks information from validation rows into training.

## Missing values

Missingness can itself be informative, but it must be handled consistently.

For linear models, use fold-local imputation and optional missing-indicator columns. For LightGBM and XGBoost, native missing-value routing is often appropriate, but the meaning and stability of missingness should still be audited. For Random Forest, use an explicit preprocessing pipeline supported by the installed scikit-learn version.

# Fitting the global anchors

## Global no-effect score

For every buyer, predict

\[
\widehat r_{i,t}=\pi_{i,t}.
\]

The mean buyer negative log-likelihood is

\[
\operatorname{NLL}_{0}
=
-\frac{1}{N_B}
\sum_{i:Y_i=1}\log\pi_{i,T_i}.
\]

This is the proper baseline for measuring how much arm information the response model has extracted.

## Global scalar maximum likelihood

The global scalar estimate is

\[
\widehat\beta
=
\arg\min_{\beta\ge0}
\sum_{i:Y_i=1}\ell_i^{\mathrm{scalar}}(\beta).
\]

Because this is a one-dimensional convex problem, a bounded scalar optimizer is sufficient.

```python
from elasticity_only.scalar import fit_global_scalar_beta

buyer_mask = purchase == 1
fit = fit_global_scalar_beta(
    arm=arm[buyer_mask],
    pi=propensity_matrix[buyer_mask],
    z=log_price_dose_matrix[buyer_mask],
)
print(fit.beta, fit.nll)
```

## Global two-gap maximum likelihood

The global two-gap estimate is

\[
(\widehat u,\widehat v)
=
\arg\min_{u\ge0,v\ge0}
\sum_{i:Y_i=1}\ell_i^{\mathrm{gap}}(u,v).
\]

The direct-gap loss is convex, so a bounded two-dimensional optimizer is reliable.

```python
from elasticity_only.two_gap import fit_global_two_gap

fit = fit_global_two_gap(
    arm=arm[buyer_mask],
    pi=propensity_matrix[buyer_mask],
)
print(fit.gap_high, fit.gap_low)
print(fit.log_rr_high, fit.log_rr_low)
```

### Closed form when propensities are constant and constraints do not bind

Suppose the propensity vector is constant and the buyer counts are

\[
n_H,\qquad n_C,\qquad n_L.
\]

The unconstrained empirical buyer probabilities are

\[
\widehat r_H=\frac{n_H}{n_H+n_C+n_L},
\]

with analogous expressions for control and low.

The unconstrained risk-ratio estimates are

\[
\widehat{RR}_{HC}
=
\frac{n_H/n_C}{\pi_H/\pi_C},
\]

and

\[
\widehat{RR}_{LC}
=
\frac{n_L/n_C}{\pi_L/\pi_C}.
\]

If these violate monotonicity, the constrained optimum should be obtained by maximizing the joint likelihood. Simply clipping each ratio independently is not always the joint constrained maximum because the categorical normalization couples the arms.

# Exact scikit-learn-compatible scalar and two-gap models

Scikit-learn provides reusable preprocessing, validation, and estimator interfaces. Its built-in logistic regression does not directly implement the scalar or joint two-gap categorical likelihood. A custom estimator can nevertheless follow the scikit-learn `BaseEstimator` interface while using SciPy for optimization.

## Penalized scalar linear model

Let \(\phi(x)\) denote the transformed feature vector produced by a scikit-learn preprocessing pipeline. Define the raw score

\[
f(x)=\alpha+\phi(x)^\top\gamma,
\]

where \(\alpha\) is an intercept and \(\gamma\) is a coefficient vector.

The elasticity magnitude is

\[
\beta(x)=\operatorname{softplus}[f(x)].
\]

An L2-penalized objective is

\[
J(\alpha,\gamma)
=
\frac{1}{N_B}
\sum_{i:Y_i=1}\ell_i^{\mathrm{scalar}}
+
\frac{\lambda}{2}\|\gamma\|_2^2.
\]

The notation \(\|\gamma\|_2^2\) means the sum of squared coefficients. The intercept is normally not penalized.

The supplied `SklearnScalarFlipRegressor` evaluates the exact loss and analytic gradient and minimizes it with the limited-memory Broyden-Fletcher-Goldfarb-Shanno algorithm with bounds, abbreviated **L-BFGS-B**.

```python
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from elasticity_only.scalar import SklearnScalarFlipRegressor

preprocess = ColumnTransformer(
    [
        ("numeric", StandardScaler(), numeric_columns),
        (
            "categorical",
            OneHotEncoder(
                handle_unknown="infrequent_if_exist",
                min_frequency=20,
            ),
            categorical_columns,
        ),
    ]
)

model = Pipeline(
    [
        ("preprocess", preprocess),
        ("elasticity", SklearnScalarFlipRegressor(l2=1.0)),
    ]
)
```

Metadata such as `pi` and `z` must be routed to the final estimator explicitly. A production wrapper should make this routing unambiguous rather than hiding it in global state.

## Penalized exact two-gap linear model

Use two raw-score surfaces:

\[
f_H(x)=\alpha_H+\phi(x)^\top\gamma_H,
\]

and

\[
f_L(x)=\alpha_L+\phi(x)^\top\gamma_L.
\]

For a direct-gap parameterization,

\[
u(x)=\operatorname{softplus}[f_H(x)],
\]

\[
v(x)=\operatorname{softplus}[f_L(x)].
\]

For a dose-aware two-slope parameterization, the softplus outputs are \(\beta_H(x)\) and \(\beta_L(x)\), and the gaps are obtained by multiplying by the corresponding positive log-price distances.

A useful objective is

\[
\begin{aligned}
J={}&
\frac{1}{N_B}\sum_{i:Y_i=1}
\ell_i^{\mathrm{gap}}
+
\frac{\lambda}{2}
(\|\gamma_H\|_2^2+\|\gamma_L\|_2^2)\\
&+
\frac{\lambda_{\mathrm{asym}}}{2N_B}
\sum_{i:Y_i=1}
[\beta_H(X_i)-\beta_L(X_i)]^2.
\end{aligned}
\]

The first penalty controls general complexity. The second shrinks the two sides toward a scalar response.

```python
from elasticity_only.two_gap import SklearnTwoGapFlipRegressor

model = SklearnTwoGapFlipRegressor(
    l2=1.0,
    asymmetry_l2=10.0,
    parameterization="slope",
)
model.fit(
    X_buyers_transformed,
    arm_buyers,
    pi=pi_buyers,
    z=z_buyers,
)

side_elasticity = model.predict_side_elasticities(
    X_future_transformed,
    z=z_future,
)
log_rr_high, log_rr_low = model.predict_log_rr(
    X_future_transformed,
    z=z_future,
)
```

## Feature sharing choices

The two sides can use:

- the same transformed feature matrix with separate coefficients;
- separate predeclared feature subsets;
- a shared common score plus smaller side-specific deviations;
- spline terms shared across sides and selected side-specific interactions.

The default should favor sharing. Completely independent high and low feature engineering doubles the opportunity to fit noise.

# Pairwise penalized logistic regression

## Exact offset formulation

For contrast arm \(t\in\{H,L\}\), the binary logit is

\[
\eta_{tC}(x)
=
\log\frac{\pi_t(x)}{\pi_C(x)}
+
\ell_{tC}(x),
\]

where

\[
\ell_{tC}(x)=\log RR_{tC}(x).
\]

A linear model writes

\[
\ell_{tC}(x)=\alpha_t+\phi(x)^\top\theta_t.
\]

The offset must remain fixed. An implementation can optimize the penalized binary cross-entropy directly with SciPy or another generalized-linear-model package that supports observation-level offsets.

## Inverse-propensity weighting workaround

Many scikit-learn classifiers do not support row-level offsets. In a pairwise buyer sample, weighting each row by

\[
w_i=\frac{1}{\pi_{i,T_i}}
\]

creates a weighted conditional distribution whose class odds equal the conversion-risk odds. A standard probabilistic classifier can then target the risk ratio.

This workaround is exact for the weighted population under correct logging probabilities. Do not also use `class_weight="balanced"`, because that changes the target posterior again.

## Penalization

For weak side-arm signal, tune the inverse regularization strength and the mixture between L1 and L2 shrinkage. Strong regularization should be considered the default, not a fallback.

# Pairwise LightGBM

LightGBM is a gradient-boosted decision-tree library. It adds trees sequentially so that each new tree reduces the current training loss.

## Offset implementation

For pairwise contrast \(t/C\), define the starting raw margin

\[
M_i^{(0)}
=
\log\frac{\pi_{i,t}}{\pi_{i,C}}
+
\bar\ell_t,
\]

where \(\bar\ell_t\) is the training-fold global log risk ratio for that contrast.

Supply this margin through LightGBM's initial-score mechanism. The trees learn a residual function \(F_t(x)\), so

\[
\widehat{\log RR}_{tC}(x)
=
\bar\ell_t+F_t(x).
\]

For likelihood evaluation, add the row-level propensity offset back before applying the sigmoid:

\[
\widehat p_{tC}(x)
=
\sigma\left[
\log\frac{\pi_t(x)}{\pi_C(x)}
+
\widehat{\log RR}_{tC}(x)
\right].
\]

The model output \(\widehat{\log RR}\) and the pairwise buyer probability \(\widehat p\) are not the same quantity.

## Important LightGBM controls

The following hyperparameters are especially important:

- `learning_rate`: size of each boosting update;
- `num_leaves`: maximum terminal regions in a tree;
- `max_depth`: maximum split depth;
- `min_data_in_leaf`: minimum buyer rows in a leaf;
- `min_sum_hessian_in_leaf`: minimum curvature in a leaf;
- `feature_fraction`: fraction of features used by a tree;
- `bagging_fraction` and `bagging_freq`: row subsampling;
- `lambda_l1` and `lambda_l2`: leaf-value penalties;
- `min_gain_to_split`: minimum estimated loss reduction for a split;
- `max_bin`: histogram resolution.

Leaf size should be judged in side-arm buyers, not only total pairwise rows.

## Exact joint two-gap LightGBM

LightGBM permits custom multiclass gradients and Hessian arrays. However, the exact two-gap Hessian has a nonzero cross-output element. The standard interface accepts one Hessian value per output and therefore represents a diagonal approximation rather than the full row Hessian.

Three options are defensible:

1. use the two pairwise binary models as the primary tree implementation;
2. use a custom two-output or three-logit objective with a diagonal Fisher approximation and label it as an approximation;
3. fit an exact joint two-gap model with a general differentiable optimizer rather than forcing it into the tree interface.

The first option is usually the strongest production baseline.

# Pairwise XGBoost

XGBoost is another gradient-boosted decision-tree library. It uses first and second derivatives of the objective to choose splits and leaf values.

## Base margin

For pairwise contrast \(t/C\), supply

\[
\log\frac{\pi_{i,t}}{\pi_{i,C}}+\bar\ell_t
\]

as the training and validation `base_margin`. The trees learn a residual around the fold-local global risk ratio.

At prediction time, be explicit about whether the requested output is:

- the tree residual;
- the full log risk ratio;
- the pairwise buyer logit including propensity offset;
- the pairwise buyer probability.

Confusing these outputs is a common implementation error.

## Important XGBoost controls

Tune:

- `eta`, the learning rate;
- `max_depth` or `max_leaves`, depending on growth policy;
- `min_child_weight`, the minimum child-node curvature;
- `gamma`, the minimum split gain;
- `subsample` and `colsample_bytree`;
- `reg_alpha` and `reg_lambda`;
- `max_bin` for histogram resolution;
- `max_delta_step` when very large leaf updates appear.

Keep `scale_pos_weight=1` in the offset likelihood. The class imbalance is part of the randomized buyer distribution and should not be silently removed.

## Scalar custom objective

The scalar custom objective is row-additive and has one raw output. It is therefore well suited to XGBoost.

Let

\[
\beta_i=\operatorname{softplus}(f_i),
\]

where \(f_i\) is the current raw tree score. The gradient is

\[
g_i
=
[z_{i,T_i}-\mu_i]\sigma(f_i).
\]

A positive Fisher curvature is

\[
h_i^F
=
\operatorname{Var}_{r_i}(z_i)\sigma(f_i)^2+\epsilon,
\]

where \(\epsilon>0\) is a numerical floor.

Initialize the raw score with the inverse softplus of the training-fold global scalar estimate. This makes the trees learn residual heterogeneity rather than starting from the arbitrary value \(\operatorname{softplus}(0)=\log2\).

## Exact joint two-gap XGBoost

XGBoost's documented custom-objective conditions state that multi-output objectives should have a diagonal row Hessian. The exact two-gap likelihood violates that condition because the two gap outputs share a categorical normalization.

A diagonal Fisher approximation is possible, but it ignores cross-gap curvature. It should be treated as an experimental challenger, not as an exact implementation of the joint likelihood. The exact pairwise binary objectives and the scalar one-output objective fit XGBoost's interface more naturally.

# Random Forest approaches

A Random Forest averages many decision trees fitted to bootstrap samples and random feature subsets. Unlike gradient boosting, a standard scikit-learn Random Forest does not optimize an arbitrary differentiable custom objective.

## Pairwise inverse-propensity-weighted forest

For each pairwise buyer dataset:

1. construct the binary arm label;
2. weight each row by the inverse of its observed-arm propensity;
3. fit `RandomForestClassifier` with `class_weight=None`;
4. use large minimum leaf sizes;
5. calibrate predictions on out-of-fold data;
6. interpret the calibrated class log odds as the log risk ratio.

Important hyperparameters are:

- `n_estimators`;
- `max_depth`;
- `min_samples_leaf`;
- `max_features`;
- `max_samples`;
- `min_impurity_decrease`;
- `ccp_alpha`, the cost-complexity pruning parameter.

The number of trees mainly controls Monte Carlo stability after it is sufficiently large. Leaf size and depth are the more important complexity controls.

## Multiclass inverse-propensity-weighted forest

A three-class forest can be fitted among buyers with weight

\[
w_i=\frac{1}{\pi_{i,T_i}}.
\]

The weighted class probabilities target normalized demand rather than the original buyer-arm posterior. Risk ratios can be recovered from their class-probability ratios.

This is a useful diagnostic, but pairwise models are often easier to calibrate and interpret.

## Scalar moment-inversion forest

A scalar Random Forest benchmark can be constructed without pretending that individual elasticity is observed.

Let the observed dose for buyer \(i\) be \(z_{i,T_i}\). After inverse-propensity weighting, fit a `RandomForestRegressor` to estimate a conditional dose moment. Under the scalar model, the theoretical expected dose is a monotone function of \(\beta(x)\). Numerically invert that function to recover \(\widehat\beta(x)\).

This is a method-of-moments estimator rather than maximum likelihood. Inversion can amplify noise, so large leaves and strong smoothing are required.

# Joint multiclass and geometric models

## Direct buyer posterior

A generic multiclass classifier predicts

\[
\widehat r_H(x),\quad
\widehat r_C(x),\quad
\widehat r_L(x).
\]

The corresponding risk ratios are obtained through the Bayes-flip identity.

Without structural constraints, the classifier can violate monotone demand and waste capacity learning the known randomization prior.

## Exact constrained parameterization

The two-gap logits

\[
\log\pi(x)+[-u(x),0,v(x)]
\]

provide an exact constrained multiclass model. They span the interior of the monotone feasible region.

The model can also be represented geometrically in the probability simplex. For fixed 10%/80%/10% assignment, the feasible buyer probabilities form a triangle whose boundaries correspond to no response on the high or low side.

![Feasible buyer-probability geometry under monotone demand](figures/feasible_triangle.png){width=85%}

## Post-hoc projection

An unconstrained prediction can be projected onto the feasible region. The projection discrepancy should match the training score. The **Kullback-Leibler divergence** measures the log-probability discrepancy between two distributions. The **Brier score** is squared error between a probability vector and the one-hot observed class vector. Therefore:

- use Kullback-Leibler projection after cross-entropy training;
- use Euclidean projection after Brier-score training.

Projection is a safety layer, not a substitute for learning a coherent response. Report the fraction of predictions moved and the average projection distance.

# Calibration and shrinkage

A flexible model can rank customers usefully while exaggerating the magnitude of risk-ratio differences. Calibration is therefore mandatory.

## Pairwise affine calibration

For a pairwise contrast, let

\[
\widehat\ell_{\mathrm{raw}}(x)
\]

be the raw predicted log risk ratio. Fit, on predictions generated out of fold relative to the base learner,

\[
\boxed{
\ell_{\mathrm{cal}}(x)
=
\alpha+s[\widehat\ell_{\mathrm{raw}}(x)-c],
\qquad s\ge0.
}
\]

Here:

- \(c\) is a centering constant;
- \(\alpha\) corrects the portfolio-level effect;
- \(s\) is the calibration slope;
- \(s<1\) shrinks excessive heterogeneity;
- \(s=0\) collapses the model to a global effect.

The calibration likelihood must include the propensity offset.

## Joint two-gap calibration

For direct gaps, a simple calibration layer is

\[
\begin{pmatrix}
u_{\mathrm{cal}}(x)\\v_{\mathrm{cal}}(x)
\end{pmatrix}
=
\begin{pmatrix}a_H\\a_L\end{pmatrix}
+
S
\begin{pmatrix}
u_{\mathrm{raw}}(x)-c_H\\v_{\mathrm{raw}}(x)-c_L
\end{pmatrix},
\]

followed by a positive transformation or constrained optimization.

The matrix \(S\) can be restricted to a diagonal matrix to avoid overfitting. A shared scalar slope is even more conservative.

## Shrinkage toward global anchors

A transparent alternative is

\[
\ell_{tC}^{\mathrm{final}}(x)
=
\bar\ell_{tC}
+
\lambda_t
[\ell_{tC}^{\mathrm{flex}}(x)-\bar\ell_{tC}],
\]

with

\[
0\le\lambda_t\le1.
\]

The values \(\lambda_H\) and \(\lambda_L\) are chosen out of fold. The same idea can shrink side-specific elasticities toward the global scalar value.

![Out-of-fold calibration and shrinkage](figures/calibration_shrinkage.png){width=95%}

## Monotonicity after calibration

After calibration, enforce

\[
\log RR_{HC}(x)\le0,
\]

and

\[
\log RR_{LC}(x)\ge0.
\]

For direct gaps, nonnegativity is already built in. For pairwise models, use a sign-constrained calibrator or a final projection.

A high frequency of sign corrections is evidence against the raw model, not merely a cosmetic issue.

# Constrained ensembles

Suppose several calibrated models produce high/control and low/control log risk ratios. A convex ensemble is

\[
\ell_H^{\mathrm{ens}}(x)
=
\sum_{k=1}^K a_k\ell_{H,k}(x),
\]

\[
\ell_L^{\mathrm{ens}}(x)
=
\sum_{k=1}^K a_k\ell_{L,k}(x),
\]

where

\[
a_k\ge0,
\qquad
\sum_{k=1}^K a_k=1.
\]

A convex combination of sign-valid log risk ratios remains sign-valid.

Fit the ensemble weights on out-of-fold predictions using buyer cross-entropy with a complexity penalty. Do not fit ensemble weights on the final chronological holdout.

Useful components can include:

- global scalar;
- global two-gap;
- penalized pairwise logistic regression;
- pairwise LightGBM;
- pairwise XGBoost;
- calibrated Random Forest;
- exact linear two-gap model.

The global anchors should remain eligible ensemble components so that the optimizer can shrink a weak flexible model back toward a stable portfolio response.

# Part V - Real-data validation and model selection {.unnumbered}

# Required real-data contract

The minimum analysis table should contain one row per eligible randomized quote, including buyers and nonbuyers.

## Required identifiers

- `quote_id`: unique experimental quote opportunity;
- `customer_id` or `household_id`: grouping variable for repeated customers;
- `quote_timestamp`: time of randomization or price display;
- `eligible`: indicator defining the randomized analysis population.

## Required treatment fields

- `arm`: randomized arm \(H\), \(C\), or \(L\);
- `pi_H`, `pi_C`, `pi_L`: row-level logged assignment probabilities;
- `assigned_multiplier`: intended experimental multiplier;
- `base_premium`: price before the experimental multiplier;
- `displayed_premium`: price actually shown;
- `tariff_version`: pricing-model or tariff release identifier;
- override and compliance indicators when applicable.

## Required outcome fields

- `purchase`: binary conversion outcome;
- `purchase_timestamp` or an auditable outcome-window field;
- cancellation or reversal fields when the business definition excludes immediate cancellations.

## Feature manifest

Maintain a separate feature manifest containing:

- feature name;
- business description;
- data type;
- observation timestamp;
- confirmation that the feature precedes treatment;
- missingness meaning;
- expected monotonic relation, when any;
- legal, fairness, and governance status;
- owner and source system.

# Experiment audit before modeling

A model cannot repair a broken experiment. The following audit is mandatory.

## Assignment counts and propensity agreement

Compare observed arm counts with the sums of logged propensities:

\[
\sum_i\mathbf{1}\{T_i=t\}
\quad\text{versus}\quad
\sum_i\pi_{i,t}.
\]

Investigate discrepancies by day, channel, tariff version, and randomization block.

## Covariate balance

For every important pre-treatment feature, compare arm distributions. Randomization does not require exact equality in finite samples, but large systematic imbalances can reveal implementation defects or post-randomization filtering.

Use standardized mean differences for numeric features and appropriate distributional comparisons for categorical features. Do not select features for the elasticity model based on arm imbalance alone.

## Treatment compliance

Verify that the displayed premium corresponds to the assigned arm after known rounding and business rules. Record:

- arm rows with no actual price change;
- multipliers outside expected bounds;
- manual overrides;
- quote recalculations after assignment;
- customers who received several prices.

## Outcome completeness

Confirm that every included quote has a completed observation window. A recent quote whose purchase window is still open should not be coded as a nonbuyer.

## Repeated exposures

Summarize the number of quotes and distinct arms per customer or household. Decide whether the estimand concerns the first eligible exposure, every eligible quote, or a specified episode. Keep all rows from one grouping unit in the same validation fold.

# Validation architecture

## Development and final test periods

Split the data chronologically into:

1. a **development period**, used for model fitting, hyperparameter tuning, calibration, and model selection;
2. a **final chronological holdout**, untouched until the entire procedure is frozen.

A time holdout tests whether elasticity patterns survive tariff changes, market conditions, and operational drift.

## Fold and out-of-fold prediction

A **fold** is one validation subset in a resampling scheme. In each fold, a model is fitted on the remaining development rows and predicts the held-out fold.

A prediction is **out of fold** when the row was not used to fit the model that produced its prediction.

Out-of-fold predictions are required for:

- honest model comparison;
- calibration;
- shrinkage selection;
- ensemble-weight fitting;
- policy construction used in offline evaluation.

## Group-disjoint splitting

The same customer or household must not appear in both training and validation partitions.

`StratifiedGroupKFold` attempts to preserve class proportions while keeping each group in one fold. It is useful for buyer-arm data, but it can still produce imperfect balance when groups are large or heterogeneous. Always inspect the resulting fold counts.

## Nested cross-validation

**Nested cross-validation** has two levels:

- the **outer loop** estimates model performance;
- the **inner loop** selects hyperparameters and produces calibration data for each outer training set.

The outer validation rows must not influence preprocessing, feature selection, Optuna studies, early stopping, calibration, shrinkage, or ensemble weights.

![Nested customer-disjoint and time-aware validation](figures/nested_validation.png){width=96%}

## Repeated seeds

Tree algorithms and fold assignment can be stochastic. Repeat key candidates with several prespecified seeds. Seed variation is part of model uncertainty and should not be hidden by reporting only the best run.

# Primary probability metrics

## Joint buyer negative log-likelihood

For a model that predicts a full buyer-arm distribution \(\widehat r_i\), define

\[
\operatorname{NLL}_{\mathrm{joint}}
=
-\frac{1}{N_B}
\sum_{i:Y_i=1}
\log\widehat r_{i,T_i}.
\]

This is the primary proper score for scalar and joint two-gap models.

## Pairwise buyer negative log-likelihood

For contrast \(t/C\), let \(\mathcal{B}_{tC}\) be the set of buyers whose arm is \(t\) or \(C\). Let \(N_{tC}\) be the number of rows in that set.

If \(A_{tC,i}\) is the binary arm label and \(\widehat p_{tC,i}\) is the predicted pairwise buyer probability including the propensity offset, define

\[
\operatorname{NLL}_{tC}
=
-\frac{1}{N_{tC}}
\sum_{i\in\mathcal{B}_{tC}}
\left[
A_{tC,i}\log\widehat p_{tC,i}
+
(1-A_{tC,i})\log(1-\widehat p_{tC,i})
\right].
\]

For joint tuning of two pairwise models, use an equal-contrast score:

\[
\boxed{
\operatorname{NLL}_{\mathrm{equal}}
=
\frac12\operatorname{NLL}_{HC}
+
\frac12\operatorname{NLL}_{LC}.
}
\]

This prevents the easier or larger contrast from dominating the search.

## Information gain over a global anchor

For a flexible model \(M\) and an anchor \(A\), define

\[
\Delta_{A\to M}
=
\operatorname{NLL}_A-
\operatorname{NLL}_M.
\]

A positive value means the flexible model predicts held-out buyer arms better.

Because improvements can be numerically small, report them in **millinats per buyer**, equal to 1,000 times the natural-log loss difference.

## Why AUC and VUS are secondary

The area under the receiver-operating-characteristic curve, abbreviated **AUC**, evaluates ranking in a binary problem. A three-class volume under a receiver-operating-characteristic surface, often abbreviated **VUS**, is a multiclass ranking measure.

Risk ratios depend on calibrated numerical probability ratios. A monotone transformation can preserve rankings while changing the inferred elasticity materially. Therefore, AUC and VUS can be reported as secondary diagnostics but should not select the final model.

# Calibration of relative effects

## Pairwise calibration intercept and slope

Using out-of-fold predictions, fit

\[
\operatorname{logit}P(T=t\mid Y=1,T\in\{t,C\},X)
=
\log\frac{\pi_t}{\pi_C}
+a+b\widehat\ell_{tC}(X).
\]

Here \(a\) is the calibration intercept and \(b\) is the calibration slope.

An ideal model has

\[
a=0,
\qquad
b=1.
\]

A slope below one indicates excessive heterogeneity. A slope near zero indicates that the model's ranking carries little repeatable price-response information.

## Joint calibration

For a joint model, compare predicted and observed buyer-arm shares in large groups and fit low-dimensional recalibration parameters on the joint categorical likelihood.

Do not calibrate the three probabilities independently and then renormalize without checking whether the resulting risk ratios remain monotone.

# Randomized grouped risk-ratio calibration

Individual true elasticity is not observed. A customer receives only one arm. Therefore, real-data evaluation must compare predicted heterogeneity with randomized group-level effects.

## Group construction

Use strictly out-of-fold predictions to sort quotes or buyers by a chosen score, such as:

- predicted high/control log risk ratio;
- predicted low/control log risk ratio;
- predicted scalar elasticity magnitude;
- predicted relative contribution gain.

Form a small number of groups with enough side-arm observations. Five large groups are often more reliable than ten small deciles.

## Experimental group risks

For a group \(G\), estimate the arm-specific conversion risk using inverse-propensity weighting:

\[
\widehat q_t(G)
=
\frac{
\sum_{i\in G}
\mathbf{1}\{T_i=t\}Y_i/\pi_{i,t}
}{
\sum_{i\in G}
\mathbf{1}\{T_i=t\}/\pi_{i,t}
}.
\]

Then calculate

\[
\widehat{RR}_{HC}(G)
=
\frac{\widehat q_H(G)}{\widehat q_C(G)},
\]

and

\[
\widehat{RR}_{LC}(G)
=
\frac{\widehat q_L(G)}{\widehat q_C(G)}.
\]

Compare these randomized estimates with the model-implied group risk ratios.

## Correct aggregation of individual predictions

A ratio of average risks is not generally equal to the unweighted average of individual risk ratios.

For group \(G\),

\[
\frac{E[q_t(X)\mid G]}{E[q_C(X)\mid G]}
\neq
E[RR_{tC}(X)\mid G]
\]

in general.

A shape-only comparison can use control-buyer weighting, or a separate scale estimate can be introduced for aggregation. The evaluation code must state which estimand it computes.

# Uncertainty estimation

## Cluster bootstrap

A **bootstrap** repeatedly resamples analysis units and recalculates a statistic. Because one customer can create several rows, resample customers or households rather than individual quotes.

For each bootstrap replication:

1. sample grouping units with replacement;
2. include all rows belonging to each sampled unit;
3. recalculate the metric or policy value using fixed out-of-fold predictions when appropriate;
4. summarize the empirical distribution.

The resulting intervals capture sampling variability at the chosen cluster level.

## Paired comparison

When comparing two models, use the same folds and the same bootstrap resamples. The primary statistic is the paired difference in loss, calibration error, or policy value. Paired evaluation removes much of the noise shared by both models.

# Business-policy evaluation

## Policy definition

A pricing policy is a function

\[
d(x)\in\{H,C,L\}
\]

that maps a quote context to one tested arm.

The policy can include an abstention rule that defaults to control when the estimated gain is too small or too uncertain.

## Inverse-propensity policy value

Let

\[
R_i^{\mathrm{business}}
=Y_i g_{T_i}(X_i)
\]

be the observed contribution from quote \(i\). The superscript distinguishes this business reward from the risk-ratio notation \(RR\).

An inverse-propensity-score estimate of policy value is

\[
\boxed{
\widehat V_{\mathrm{IPS}}(d)
=
\frac1N\sum_{i=1}^N
\frac{
\mathbf{1}\{T_i=d(X_i)\}
R_i^{\mathrm{business}}
}{\pi_{i,T_i}}.
}
\]

The abbreviation **IPS** means inverse propensity score.

The policy predictions used in this formula must be out of fold relative to quote \(i\). Otherwise, the same random outcomes influence both policy construction and evaluation.

## Effective sample size

A highly selective policy may agree with the randomized arm for only a small number of rows. If the nonzero evaluation weights are $w_i$, a common diagnostic is

\[
N_{\mathrm{eff}}=\frac{(\sum_i w_i)^2}{\sum_i w_i^2}.
\]

Report this effective sample size and the arm-specific match counts.

A high point estimate with almost no matching high-arm observations is not reliable evidence.

## Doubly robust extension

A doubly robust estimator combines IPS weighting with an outcome model. The outcome model can reduce variance and becomes useful when evaluating many narrow policies.

Absolute conversion modeling is therefore a possible side effect of the evaluation process, not the primary elasticity target.

## Benchmark policies

Compare every personalized policy with:

- control for everyone;
- high price for everyone;
- low price for everyone;
- the best uniform tested arm;
- the global scalar policy;
- the global two-gap policy;
- simple predeclared actuarial segment rules.

# Comparing scalar and two-gap models

The scalar model is nested inside the two-gap model, but flexible machine-learning versions differ in effective complexity. In-sample likelihood will almost always favor the more flexible model. The comparison must be out of sample.

## Required evidence for the two-gap model

Promote the two-gap model over the scalar model only when it provides reproducible gains in:

1. joint buyer negative log-likelihood;
2. separate high/control and low/control calibration;
3. randomized grouped risk-ratio calibration;
4. chronological holdout performance;
5. contribution-policy value or safer decision boundaries.

## Asymmetry diagnostic

For any two-gap prediction, calculate

\[
D_{\mathrm{asym}}(x)
=
\frac{u(x)}{z_H(x)}
-
\frac{v(x)}{-z_L(x)}.
\]

The scalar restriction is

\[
D_{\mathrm{asym}}(x)=0.
\]

Inspect the distribution of \(D_{\mathrm{asym}}\), its calibration by large groups, and its stability across folds and time. Large unstable asymmetry is a warning of side-arm noise.

## Prefer shrinkage over a hard winner-takes-all choice

When the two-gap model improves fit modestly, a strongly asymmetry-penalized model is often preferable to a fully free two-gap surface. This preserves most of the scalar model's stability while allowing evidence-supported departures.

# Optuna hyperparameter optimization

Optuna is a Python framework for automated hyperparameter optimization. A **study** is one optimization problem. A **trial** is one evaluated hyperparameter configuration.

## Study boundaries

Create separate studies for:

- each model family;
- high/control and low/control pairwise contrasts;
- scalar versus two-gap structural models;
- direct-gap versus dose-aware two-slope parameterizations when both are considered.

A single enormous conditional study makes diagnostics and fair compute allocation difficult.

## Study objective

The Optuna objective must be an inner-validation proper loss:

- joint buyer negative log-likelihood for scalar and joint two-gap models;
- pairwise buyer negative log-likelihood for one contrast;
- equal-contrast negative log-likelihood for a jointly selected pairwise system.

Do not optimize training loss, AUC, VUS, accuracy, or in-sample policy value.

## Sampler and pruner

A robust default is a seeded tree-structured Parzen-estimator sampler, abbreviated **TPE**, with a median pruner for iterative models.

```python
import optuna

sampler = optuna.samplers.TPESampler(
    seed=2026,
    n_startup_trials=30,
    multivariate=True,
    group=True,
)

pruner = optuna.pruners.MedianPruner(
    n_startup_trials=15,
    n_warmup_steps=1,
    n_min_trials=5,
)
```

Experimental sampler options such as multivariate and grouped TPE should be isolated in configuration so that they can be disabled if the installed Optuna version changes behavior.

![Nested Optuna workflow](figures/optuna_flow.png){width=96%}

## Number of trials

Trial count depends on sample size, model cost, and search-space dimension. Reasonable starting budgets are:

- 50 to 100 trials for penalized linear models;
- 100 to 250 trials per pairwise LightGBM or XGBoost study;
- 100 to 200 trials for Random Forest;
- 100 to 250 trials for a scalar boosting objective;
- 150 to 300 trials for a two-gap model with separate complexity and asymmetry penalties.

More trials do not repair a weak validation design.

# Hyperparameter ranges

The ranges below are starting spaces for this weak-signal buyer problem. They must be adapted to actual buyer counts and compute constraints.

## Penalized scalar linear model

Tune:

\[
\lambda_{L2}\in[10^{-5},10^2]
\]

on a logarithmic scale.

For spline models, also tune:

- number of knots: 3 to 8 per selected numeric feature;
- spline degree: 1 to 3;
- whether selected interactions are included;
- category minimum frequency: 10 to 200 buyer rows.

## Exact two-gap linear or spline model

Tune:

\[
\lambda_{L2}\in[10^{-5},10^2]
\]

and

\[
\lambda_{\mathrm{asym}}
\in[10^{-4},10^4]
\]

on logarithmic scales.

Also consider:

- `parameterization`: `gap` or `slope` when dose variation is material;
- shared versus side-specific spline terms;
- a common feature subset versus selected side-specific additions;
- upper numerical bounds used only for optimizer safety.

The asymmetry penalty is one of the most important two-gap hyperparameters. Omitting it effectively assumes that the data can support two independent heterogeneous surfaces.

## Pairwise penalized logistic regression

Tune:

- inverse regularization strength `C`: \(10^{-4}\) to \(10^2\), logarithmic;
- L1 ratio: 0 to 1;
- category minimum frequency: 10 to 200;
- selected spline or interaction complexity.

Do not tune class balancing because it changes the target.

## Pairwise LightGBM

Suggested ranges are:

\[
\text{learning rate}\in[0.005,0.10]
\]

on a logarithmic scale;

\[
\text{max depth}\in\{2,\ldots,7\};
\]

\[
\text{num leaves}\in
\{4,\ldots,\min(64,2^{\text{max depth}}-1)\}.
\]

Tune:

- `min_data_in_leaf` using a dynamic range based on minority side-arm buyers;
- `min_sum_hessian_in_leaf`: 0.1 to 50, logarithmic;
- `feature_fraction`: 0.5 to 1.0;
- `bagging_fraction`: 0.6 to 1.0;
- `bagging_freq`: 1 to 10;
- `lambda_l1`: \(10^{-8}\) to \(10^2\);
- `lambda_l2`: \(10^{-3}\) to \(10^2\);
- `min_gain_to_split`: zero or \(10^{-5}\) to 1;
- `max_bin`: 63, 127, 255, or 511.

A useful lower bound for leaf size is

\[
\max\left\{20,\frac{10}{\rho_{\min}}\right\},
\]

where \(\rho_{\min}\) is the minority side-arm fraction in the pairwise buyer sample. Round this lower bound up to the next integer. The heuristic aims for roughly ten minority-arm buyers in a minimally sized leaf.

## Pairwise XGBoost

Suggested ranges are:

- `eta`: 0.005 to 0.10, logarithmic;
- `max_depth`: 2 to 7 for depthwise growth;
- `max_leaves`: 8 to 64 for lossguide growth;
- `min_child_weight`: 1 to 100, logarithmic;
- `subsample`: 0.6 to 1.0;
- `colsample_bytree`: 0.5 to 1.0;
- `gamma`: zero or \(10^{-6}\) to 10;
- `reg_alpha`: \(10^{-8}\) to \(10^2\);
- `reg_lambda`: \(10^{-3}\) to \(10^2\);
- `max_bin`: 64, 128, 256, or 512;
- `max_delta_step`: 0, 1, 2, or 5.

## Scalar LightGBM or XGBoost custom objective

Use shallower spaces because one raw score controls the complete response curve:

- maximum depth: 1 to 4;
- learning rate: 0.005 to 0.05;
- strong L2 regularization;
- large minimum leaves;
- early stopping on exact joint buyer negative log-likelihood;
- optional post-fit shrinkage toward the global scalar value.

## Experimental two-gap boosting objective

When a diagonal Fisher approximation is implemented, tune:

- shared versus separate tree structures for the two outputs;
- diagonal-Hessian floor;
- asymmetry penalty;
- maximum depth: 1 to 4;
- learning rate: 0.003 to 0.03;
- large minimum curvature and leaf-size constraints;
- a global two-gap or global scalar base margin.

This model should be compared with pairwise trees under the same compute budget. Its approximate Hessian is a substantive implementation choice and must be reported.

## Random Forest

Fix `n_estimators` at a sufficiently large value, such as 800 to 1,500, after checking probability stability. Tune:

- `criterion`: `log_loss` or `gini`;
- `max_depth`: 4 to 16;
- `min_samples_leaf`: a dynamic buyer-count range;
- `max_features`: `sqrt`, `log2`, or 0.2 to 1.0;
- `max_samples`: 0.5 to 1.0;
- `min_impurity_decrease`: zero or \(10^{-8}\) to \(10^{-3}\);
- `ccp_alpha`: zero or \(10^{-8}\) to \(10^{-2}\).

# Optuna trial procedure

Each trial must:

1. receive one hyperparameter configuration;
2. fit preprocessing only on the inner-training rows;
3. fit the model on inner-training buyers;
4. use early stopping only on the inner-validation fold;
5. predict the inner-validation buyers;
6. calculate the correct offset-aware loss;
7. aggregate losses across inner folds;
8. report intermediate fold results to the pruner when appropriate;
9. store fold counts, convergence status, and selected iteration counts as trial attributes.

Failed trials should return a controlled failure state with an informative reason, not a fabricated large score that hides systematic numerical problems.

# Model inspection

## Stability by fold and time

Report for every candidate:

- mean and standard deviation of loss across folds;
- paired loss difference versus anchors;
- calibration intercept and slope by fold;
- distribution of predicted risk ratios;
- predicted high/low asymmetry;
- selected tree iterations;
- feature importance stability;
- performance by tariff version and time period.

## Partial dependence and accumulated local effects

A partial-dependence plot averages predictions while replacing one feature with selected values. It can be misleading when features are strongly correlated.

An accumulated-local-effects plot summarizes local prediction changes over the observed feature distribution and is often safer for correlated insurance variables.

Both describe the fitted model, not a causal effect of changing the feature.

## Interaction diagnostics

Tree models can discover interactions that are difficult to estimate reliably. Require an interaction to:

- appear across folds or seeds;
- have enough side-arm buyers in every relevant region;
- improve held-out likelihood;
- have a plausible pre-treatment interpretation;
- survive temporal validation.

# Failure modes and dead ends

## Training on all quotes with ordinary accuracy

Accuracy is dominated by nonbuyers and does not target relative price response. It is unsuitable for elasticity model selection.

## Balancing buyer classes without correction

Forcing buyer arm frequencies to one third removes part of the experimental treatment signal. Oversampling or weighting is valid only when the induced prior change is explicitly reversed.

## Duplicating buyers

Duplicating rows does not create experimental information. It can make an optimizer appear more confident without increasing the number of independent buyers.

## Deleting observations to enforce monotonicity

Removing high-price buyers or low-price nonbuyers changes the randomized experiment. Constraints belong in the model or a transparent post-processing layer, not in outcome-dependent data deletion.

## Treating individual elasticity as observed

No quote reveals all three potential purchase outcomes. Individual elasticity cannot be used as a supervised target on real data.

## Calling every high/low difference curvature

Two finite side responses do not identify a unique continuous second derivative. Call the difference **finite-response asymmetry** unless a richer price experiment supports a curvature model.

## Ignoring the propensity offset

A pairwise buyer probability is not a risk ratio. Omitting the propensity offset causes the model to learn the experimental allocation as if it were demand.

## Reusing calibration rows

Calibrating on predictions from a model trained on the same rows creates optimistic slopes and intercepts. Calibration predictions must be out of fold.

## Selecting the most profitable model on the same data used to train it

This is policy overfitting. Policy construction and randomized evaluation must be separated by cross-fitting or an untouched holdout.

## Excessive two-gap flexibility

A flexible two-gap model can fit independent noise in the high and low side arms. Use asymmetry shrinkage, large leaves, and a scalar anchor.

## Extrapolating beyond tested prices

The experiment identifies effects at the tested prices. A scalar power law supplies an extrapolation rule, but that rule is an assumption. A two-gap model supplies no unique curve outside the tested points.

# Model-selection gates

A personalized model is eligible for production only when it passes all gates below.

## Gate one: experiment validity

- assignment and propensity audit passes;
- treatment precedes every feature;
- outcome window is complete;
- repeated exposures are handled;
- no post-randomization exclusions create bias.

## Gate two: proper probability performance

- out-of-fold buyer negative log-likelihood beats the relevant global anchor;
- the paired confidence interval supports a real improvement;
- gains are not concentrated in one fold or seed.

## Gate three: calibration

- pairwise or joint calibration intercepts are acceptable;
- calibration slopes remain positive and reasonably close to one after shrinkage;
- grouped randomized risk ratios move consistently with predictions.

## Gate four: stability

- performance survives a forward-time holdout;
- risk-ratio distributions are not dominated by extreme tails;
- important features and interactions are stable;
- model results are not dependent on one random seed.

## Gate five: business value

- the out-of-fold policy beats the best uniform tested arm;
- the lower confidence bound is positive for the intended deployment population;
- match counts and effective sample size are adequate;
- governance, fairness, and operational constraints are satisfied.

If a flexible model fails these gates, use the global scalar, global two-gap, or control policy. Increasing model capacity is not the automatic remedy.

# Recommended end-to-end sequence

1. Freeze the eligible population and data contract.
2. Audit assignment, propensities, price compliance, outcomes, and repeated customers.
3. Produce model-free arm conversion rates and portfolio risk ratios.
4. Fit the no-effect, global scalar, and global two-gap buyer models.
5. Compare global scalar and two-gap assumptions.
6. Build customer-disjoint nested folds and a chronological holdout.
7. Fit penalized pairwise logistic regression.
8. Tune pairwise LightGBM and XGBoost with identical folds.
9. Fit a strongly smoothed pairwise Random Forest benchmark.
10. Fit the exact linear or spline two-gap model with an Optuna-selected asymmetry penalty.
11. Fit scalar custom-objective boosting as a low-dimensional nonlinear challenger.
12. Generate inner out-of-fold predictions for calibration and shrinkage.
13. Compare all models on outer-fold proper loss and calibration.
14. Evaluate randomized grouped risk ratios.
15. Construct contribution policies from out-of-fold predictions.
16. Evaluate policies with clustered IPS or doubly robust estimators.
17. Freeze the complete procedure.
18. Run the untouched chronological holdout once.
19. Document the selected model, rejected alternatives, uncertainty, and deployment restrictions.

![Recommended model ladder](figures/model_ladder.png){width=95%}

# Production monitoring

After deployment, monitor both the experimental data pipeline and the model.

## Data drift

Track:

- feature distributions;
- missingness;
- tariff versions;
- channel mix;
- realized price multipliers;
- customer repeat rates;
- competitor-position variables.

## Prediction drift

Track:

- distributions of \(RR_{HC}\) and \(RR_{LC}\);
- distributions of \(u\), \(v\), \(\beta_H\), and \(\beta_L\);
- scalar-versus-two-gap asymmetry;
- fraction of quotes assigned to each policy arm;
- abstention rate;
- projection or clipping rate.

## Experimental refresh

Maintain a randomized exploration population. Without continuing exploration, policy-driven price assignment can remove positivity and make future response evaluation impossible.

## Recalibration triggers

Recalibrate or refit when:

- buyer-arm calibration slopes drift;
- portfolio risk ratios change materially;
- tariff or market regimes change;
- the realized price dose changes;
- policy value no longer beats uniform benchmarks.

# Part VI - Implementation blueprint and reference {.unnumbered}

# Core Python calculations

The following compact functions show the exact numerical objects. Production code should add type checking, metadata routing, serialization, and data-contract validation.

## Stable two-gap buyer posterior

```python
import numpy as np
from scipy.special import logsumexp


def two_gap_buyer_posterior(
    gap_high: np.ndarray,
    gap_low: np.ndarray,
    propensity: np.ndarray,
) -> np.ndarray:
    """Return P(T=H,C,L | Y=1,X) under monotone direct gaps.

    gap_high[i] = log(q_C / q_H) for row i.
    gap_low[i]  = log(q_L / q_C) for row i.
    propensity has columns H, C, L and rows that sum to one.
    """
    u = np.asarray(gap_high, dtype=float).reshape(-1)
    v = np.asarray(gap_low, dtype=float).reshape(-1)
    pi = np.asarray(propensity, dtype=float)

    if pi.shape != (len(u), 3) or len(v) != len(u):
        raise ValueError("arrays do not align")
    if np.any(u < 0.0) or np.any(v < 0.0):
        raise ValueError("gaps must be nonnegative")
    if np.any(pi <= 0.0) or not np.allclose(pi.sum(axis=1), 1.0):
        raise ValueError("invalid propensities")

    logits = np.log(pi) + np.column_stack(
        [-u, np.zeros(len(u)), v]
    )
    return np.exp(logits - logsumexp(logits, axis=1, keepdims=True))
```

## Exact row loss and gap gradients

```python

def two_gap_nll_and_gradient(
    gap_high: np.ndarray,
    gap_low: np.ndarray,
    arm_index: np.ndarray,
    propensity: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Return row NLL and gradient with respect to (u, v)."""
    arm = np.asarray(arm_index, dtype=int).reshape(-1)
    posterior = two_gap_buyer_posterior(
        gap_high, gap_low, propensity
    )

    row_nll = -np.log(
        np.clip(
            posterior[np.arange(len(arm)), arm],
            1e-300,
            1.0,
        )
    )

    indicator_high = (arm == 0).astype(float)
    indicator_low = (arm == 2).astype(float)
    gradient = np.column_stack(
        [
            indicator_high - posterior[:, 0],
            posterior[:, 2] - indicator_low,
        ]
    )
    return row_nll, gradient
```

The arm encoding in this example is

\[
H\mapsto0,\qquad C\mapsto1,\qquad L\mapsto2.
\]

## Full direct-gap Hessian

```python

def two_gap_hessian(posterior: np.ndarray) -> np.ndarray:
    """Return one exact 2x2 direct-gap Hessian per row."""
    r = np.asarray(posterior, dtype=float)
    out = np.empty((len(r), 2, 2), dtype=float)

    out[:, 0, 0] = r[:, 0] * (1.0 - r[:, 0])
    out[:, 1, 1] = r[:, 2] * (1.0 - r[:, 2])
    out[:, 0, 1] = r[:, 0] * r[:, 2]
    out[:, 1, 0] = out[:, 0, 1]
    return out
```

## Transforming gaps to reported elasticities

```python

def two_gap_to_standard_elasticity(
    gap_high: np.ndarray,
    gap_low: np.ndarray,
    price_multiplier_high: np.ndarray,
    price_multiplier_low: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Return signed standard finite elasticities for H/C and L/C."""
    u = np.asarray(gap_high, dtype=float)
    v = np.asarray(gap_low, dtype=float)
    m_h = np.asarray(price_multiplier_high, dtype=float)
    m_l = np.asarray(price_multiplier_low, dtype=float)

    rr_h = np.exp(-u)
    rr_l = np.exp(v)
    e_h = (rr_h - 1.0) / (m_h - 1.0)
    e_l = (rr_l - 1.0) / (m_l - 1.0)
    return e_h, e_l
```

# Custom two-gap linear estimator

The reference package contains `SklearnTwoGapFlipRegressor`. Its principal steps are:

1. transform the feature matrix with a fold-local scikit-learn pipeline;
2. predict two raw linear scores;
3. transform them to nonnegative gaps or slopes with softplus;
4. calculate the exact joint buyer posterior;
5. calculate categorical negative log-likelihood;
6. add L2 and asymmetry penalties;
7. supply the analytic gradient to L-BFGS-B;
8. expose scikit-learn-compatible `fit` and `predict` methods.

A simplified fit call is:

```python
from elasticity_only.two_gap import SklearnTwoGapFlipRegressor

model = SklearnTwoGapFlipRegressor(
    l2=optuna_l2,
    asymmetry_l2=optuna_asymmetry_l2,
    parameterization="slope",
    fit_intercept=True,
    max_iter=2500,
    tol=1e-8,
)

model.fit(
    X=buyer_feature_matrix,
    y=buyer_arm_index,
    pi=buyer_propensity_matrix,
    z=buyer_log_price_doses,
)
```

The `slope` parameterization is preferred when actual arm price distances vary. The `gap` parameterization is simpler when every row receives the same nominal multipliers.

# Pairwise LightGBM implementation pattern

The pseudocode below separates the propensity offset from the learned log risk ratio.

```python
import lightgbm as lgb
import numpy as np


def fit_pairwise_lightgbm(
    X_train,
    arm_train,
    pi_train,
    X_valid,
    arm_valid,
    pi_valid,
    contrast_arm,
    global_log_rr,
    params,
):
    # Arm encoding: H=0, C=1, L=2.
    train_mask = np.isin(arm_train, [contrast_arm, 1])
    valid_mask = np.isin(arm_valid, [contrast_arm, 1])

    y_train = (arm_train[train_mask] == contrast_arm).astype(int)
    y_valid = (arm_valid[valid_mask] == contrast_arm).astype(int)

    train_offset = (
        np.log(pi_train[train_mask, contrast_arm])
        - np.log(pi_train[train_mask, 1])
    )
    valid_offset = (
        np.log(pi_valid[valid_mask, contrast_arm])
        - np.log(pi_valid[valid_mask, 1])
    )

    train_data = lgb.Dataset(
        X_train[train_mask],
        label=y_train,
        init_score=train_offset + global_log_rr,
        free_raw_data=False,
    )
    valid_data = lgb.Dataset(
        X_valid[valid_mask],
        label=y_valid,
        init_score=valid_offset + global_log_rr,
        reference=train_data,
        free_raw_data=False,
    )

    booster = lgb.train(
        {
            "objective": "binary",
            "metric": "binary_logloss",
            "boost_from_average": False,
            **params,
        },
        train_data,
        num_boost_round=5000,
        valid_sets=[valid_data],
        callbacks=[lgb.early_stopping(150, verbose=False)],
    )
    return booster
```

At inference, obtain the tree residual with `raw_score=True`, add the global log-risk-ratio anchor, and keep the propensity offset separate unless a buyer probability is required.

# Pairwise XGBoost implementation pattern

```python
import numpy as np
import xgboost as xgb


def make_pairwise_dmatrix(
    X,
    arm,
    propensity,
    contrast_arm,
    global_log_rr,
):
    mask = np.isin(arm, [contrast_arm, 1])
    label = (arm[mask] == contrast_arm).astype(float)
    offset = (
        np.log(propensity[mask, contrast_arm])
        - np.log(propensity[mask, 1])
    )
    matrix = xgb.DMatrix(
        X[mask],
        label=label,
        base_margin=offset + global_log_rr,
    )
    return matrix, mask
```

The validation matrix must receive its own row-level base margin. Early stopping on a matrix without the correct offsets evaluates the wrong probabilities.

# Scalar XGBoost objective pattern

```python
import numpy as np
from scipy.special import expit, logsumexp


def make_scalar_xgb_objective(propensity, dose, arm):
    pi = np.asarray(propensity, dtype=float)
    z = np.asarray(dose, dtype=float)
    t = np.asarray(arm, dtype=int)

    def objective(raw_score, dtrain):
        f = np.asarray(raw_score, dtype=float)
        beta = np.logaddexp(0.0, f)
        derivative = expit(f)

        logits = np.log(pi) - beta[:, None] * z
        log_normalizer = logsumexp(logits, axis=1)
        posterior = np.exp(logits - log_normalizer[:, None])

        mean_dose = np.sum(posterior * z, axis=1)
        variance_dose = np.sum(
            posterior * (z - mean_dose[:, None]) ** 2,
            axis=1,
        )

        grad_beta = z[np.arange(len(t)), t] - mean_dose
        grad = grad_beta * derivative
        hess = variance_dose * derivative**2 + 1e-10
        return grad, hess

    return objective
```

The corresponding evaluation metric must calculate the exact categorical buyer negative log-likelihood, not a binary surrogate.

# Optuna objective skeleton

```python
import numpy as np
import optuna


def optuna_objective(trial: optuna.Trial) -> float:
    params = suggest_model_parameters(trial)
    fold_losses = []

    for fold_number, (train_index, valid_index) in enumerate(inner_splits):
        fitted_pipeline = fit_fold_model(
            train_index=train_index,
            valid_index=valid_index,
            parameters=params,
        )
        prediction = fitted_pipeline.predict_response(valid_index)
        loss = exact_buyer_nll(valid_index, prediction)
        fold_losses.append(loss)

        trial.report(float(np.mean(fold_losses)), step=fold_number)
        if trial.should_prune():
            raise optuna.TrialPruned()

    trial.set_user_attr("fold_losses", fold_losses)
    return float(np.mean(fold_losses))
```

The functions in this skeleton must not access outer-validation outcomes or global preprocessing objects.

# Detailed instruction for an LLM modeling agent

The instruction below is written as an operational contract. An LLM agent should follow it literally and record every deviation.

## Mission

Build and compare elasticity-only models on real randomized motor-insurance quote data. Estimate high/control and low/control conversion risk ratios, derive requested elasticity conventions, and identify tested price adjustments with credible contribution gains.

Do not generate replacement data. Do not report simulated individual-elasticity accuracy as evidence about the portfolio.

## Required sequence

### Data intake

1. Load the supplied quote table without modifying source files.
2. Calculate and store a SHA-256 hash of the raw input.
3. Validate required columns and data types.
4. Verify that propensity rows are strictly positive and sum to one.
5. Verify arm labels and treatment dates.
6. Identify the grouping unit for repeated customers.
7. Create a feature manifest and reject post-treatment variables.

### Experiment audit

1. Reconstruct the eligible population.
2. Compare observed arm counts with expected propensity totals.
3. Audit balance by time, channel, tariff version, and major features.
4. Audit displayed-price compliance.
5. Audit incomplete outcome windows.
6. Quantify repeated and cross-arm customer exposures.
7. Stop and report defects before fitting a causal model when randomization integrity is uncertain.

### Model-free portfolio estimates

1. Estimate arm conversion rates with randomized or inverse-propensity estimators.
2. Estimate portfolio high/control and low/control risk ratios.
3. Transform them to standard finite, log-change, and midpoint elasticities.
4. Produce customer-clustered confidence intervals.
5. Record expected buyer counts in each arm.

### Validation design

1. Reserve a chronological final holdout.
2. Build customer- or household-disjoint outer folds in the development period.
3. Build inner group-disjoint folds inside each outer training set.
4. Persist the exact fold assignments.
5. Use identical outer folds for all candidate models.

### Mandatory anchors

Fit:

1. no-effect buyer model;
2. global scalar constant-log-elasticity model;
3. global two-gap model;
4. global pairwise high/control and low/control models.

Report their likelihoods and uncertainty before fitting heterogeneous models.

### Flexible candidates

Fit at least:

1. penalized pairwise logistic regression;
2. pairwise LightGBM;
3. pairwise XGBoost;
4. pairwise Random Forest with inverse-propensity weighting;
5. exact penalized linear or spline two-gap model;
6. scalar LightGBM or XGBoost custom-objective model.

The exact joint two-gap tree objective is optional and must be labeled approximate when a diagonal Hessian is used.

### Hyperparameter tuning

1. Run a separate Optuna study for every model family and contrast.
2. Optimize inner-validation proper loss.
3. Use fold-local preprocessing and early stopping.
4. Store study databases, sampler seeds, package versions, and trial attributes.
5. Inspect failed and pruned trials.
6. Prefer parsimonious configurations within statistical uncertainty of the best trial.

### Calibration and shrinkage

1. Generate base-model predictions that are out of fold inside each outer training set.
2. Fit propensity-aware calibration intercepts and slopes.
3. Tune shrinkage toward global anchors.
4. For two-gap models, tune shrinkage of side-specific elasticities toward equality.
5. Enforce monotonicity after calibration.
6. Record every prediction altered by a constraint or projection.

### Outer-fold evaluation

For every candidate, calculate:

1. joint or pairwise buyer negative log-likelihood;
2. paired improvement over global anchors;
3. calibration intercept and slope;
4. randomized grouped high/control and low/control risk-ratio calibration;
5. temporal and segment stability;
6. prediction-tail diagnostics;
7. policy value and uncertainty.

### Model selection

Select a personalized model only when it passes all model-selection gates. Otherwise select the stable global model or retain control.

### Final holdout

1. Freeze preprocessing, hyperparameters, calibration, shrinkage, ensemble weights, and policy thresholds.
2. Fit the frozen procedure on the complete development period.
3. Evaluate the final chronological holdout once.
4. Report every metric, including negative or inconclusive results.
5. Do not reopen tuning after observing the holdout without declaring a new development cycle.

### Deliverables

Produce:

- experiment-audit report;
- data dictionary and feature manifest;
- persisted fold assignments;
- Optuna study databases;
- out-of-fold prediction table;
- model cards for every candidate;
- calibration plots and grouped risk-ratio tables;
- policy-value report with clustered confidence intervals;
- selected-model rationale;
- rejected-model and dead-end log;
- reproducible Python package and environment lock;
- input and output integrity hashes.

# Notation glossary

| Symbol | Meaning |
|---|---|
| \(i\) | quote-row index |
| \(N\) | number of eligible quote rows |
| \(N_B\) | number of buyer rows |
| \(X_i\) | pre-treatment feature vector for row \(i\) |
| \(x\) | a particular feature context |
| \(T_i\) | randomized arm for row \(i\) |
| \(H,C,L\) | high, control, and low price arms |
| \(Y_i\) | purchase indicator |
| \(\pi_{i,t}\) | logged probability of assigning row \(i\) to arm \(t\) |
| \(P_{i,t}\) | displayed price that row \(i\) would receive under arm \(t\) |
| \(m_{i,t}\) | price multiplier \(P_{i,t}/P_{i,C}\) |
| \(z_{i,t}\) | log-price dose \(\log m_{i,t}\) |
| \(q_t(x)\) | conversion risk under arm \(t\) |
| \(r_t(x)\) | probability that a buyer came from arm \(t\) |
| \(RR_{HC}(x)\) | high/control conversion risk ratio |
| \(RR_{LC}(x)\) | low/control conversion risk ratio |
| \(u(x)\) | high gap \(\log[q_C(x)/q_H(x)]\) |
| \(v(x)\) | low gap \(\log[q_L(x)/q_C(x)]\) |
| \(\beta(x)\) | scalar nonnegative log-elasticity magnitude |
| \(\beta_H(x)\) | high-side nonnegative log-elasticity magnitude |
| \(\beta_L(x)\) | low-side nonnegative log-elasticity magnitude |
| \(g_t(x)\) | contribution conditional on purchase under arm \(t\) |
| \(V_t(x)\) | expected contribution per quote under arm \(t\) |
| \(d(x)\) | pricing policy or selected arm |
| \(f_H,f_L\) | unrestricted raw-score functions for the two gaps |
| \(\sigma\) | logistic sigmoid function |
| \(\ell\) | row loss or log-risk-ratio function, depending on subscript and context |
| \(\lambda\) | generic regularization strength |
| \(\Omega\) | generic complexity penalty |
| \(w_i\) | optional prespecified analysis weight |

# Assumption checklist

Before interpreting results, confirm each statement below.

- The arm was randomized among the analyzed eligible quotes.
- Logged row-level assignment probabilities are correct.
- Every modeled feature preceded price display.
- The arm changed price and did not unintentionally change coverage or service.
- The purchase outcome window is complete and consistent across arms.
- Repeated customers are handled in splitting and uncertainty estimation.
- Every target segment has positive probability of receiving every evaluated arm.
- The selected price lies within the tested action set unless extrapolation is explicitly declared.
- Monotone demand is a stated modeling assumption, not a data-cleaning operation.
- The scalar common-slope restriction is tested against a two-gap alternative.
- Two-gap asymmetry is interpreted as finite marginal response, not automatically as individual curvature.
- Hyperparameters, calibration, and policy thresholds are selected without using the final holdout.

# Derivation summary

The complete argument can be compressed into the following sequence.

Randomization and Bayes' rule give

\[
r_t(x)
=
\frac{\pi_t(x)q_t(x)}{\sum_j\pi_j(x)q_j(x)}.
\]

Therefore,

\[
RR_{tC}(x)
=
\frac{r_t(x)/\pi_t(x)}{r_C(x)/\pi_C(x)}.
\]

Monotone demand gives

\[
RR_{HC}(x)\le1,
\qquad
RR_{LC}(x)\ge1.
\]

The saturated monotone two-gap parameterization is

\[
RR_{HC}(x)=e^{-u(x)},
\qquad
RR_{LC}(x)=e^{v(x)},
\qquad
u(x),v(x)\ge0.
\]

Its buyer posterior is

\[
r(x)
=
\operatorname{softmax}
\left(
\log\pi(x)+[-u(x),0,v(x)]
\right).
\]

Its exact row loss is

\[
\ell_i^{\mathrm{gap}}
=-\log r_{i,T_i}.
\]

The scalar constant-log-elasticity restriction is

\[
u(x)=\beta(x)z_H(x),
\qquad
v(x)=\beta(x)[-z_L(x)].
\]

Pairwise models use

\[
\operatorname{logit}P(T=t\mid Y=1,T\in\{t,C\},X)
=
\log\frac{\pi_t}{\pi_C}
+
\log RR_{tC}(X).
\]

The business chooses among tested prices using

\[
d^*(x)
=
\arg\max_t g_t(x)RR_{tC}(x).
\]

# References and software documentation

Dai, J. Y., et al. "Case-only approach to identifying markers predicting treatment effects on the relative risk scale in randomized trials." *Biometrics*, 2018. The paper develops randomized case-only identification for relative-risk effect modification. [Open-access article](https://pmc.ncbi.nlm.nih.gov/articles/PMC5874156/)

Gneiting, T., and Raftery, A. E. "Strictly Proper Scoring Rules, Prediction, and Estimation." *Journal of the American Statistical Association*, 2007. This is the foundational reference for proper probabilistic scoring rules. [DOI record](https://doi.org/10.1198/016214506000001437)

Xu, Y., and Yadlowsky, S. "Calibration Error for Heterogeneous Treatment Effects." *Proceedings of AISTATS*, 2022. [AISTATS paper](https://proceedings.mlr.press/v151/xu22c.html)

van der Laan, L., et al. "Causal Isotonic Calibration for Heterogeneous Treatment Effects." *Proceedings of ICML*, 2023. [ICML paper](https://proceedings.mlr.press/v202/van-der-laan23a.html)

CORE Econ. "The elasticity of demand." This source explains point elasticity and constant-elasticity demand curves. [CORE Econ chapter](https://books.core-econ.org/the-economy-v1/book/text/leibniz-07-08-01.html)

XGBoost documentation. "Advanced Usage of Custom Objectives." The current documentation states the smoothness, row-additivity, convexity, and diagonal multi-output-Hessian conditions for custom objectives. [XGBoost custom-objective guide](https://xgboost.readthedocs.io/en/latest/tutorials/advanced_custom_obj.html)

XGBoost documentation. "Demo for creating customized multi-class objective function." The example uses a diagonal Hessian upper bound rather than the full multiclass Hessian. [XGBoost custom-softmax example](https://xgboost.readthedocs.io/en/stable/python/examples/custom_softmax.html)

LightGBM documentation. `LGBMClassifier` and custom objective interfaces. The multiclass interface returns gradient and Hessian arrays with one value per class output. [LightGBM API documentation](https://lightgbm.readthedocs.io/en/latest/pythonapi/lightgbm.LGBMClassifier.html)

Scikit-learn documentation. `StratifiedGroupKFold`, probability calibration, and Random Forest APIs. [Cross-validation documentation](https://scikit-learn.org/stable/modules/cross_validation.html) and [calibration documentation](https://scikit-learn.org/stable/modules/calibration.html)

Optuna documentation. Study creation, TPE sampling, pruning, persistent storage, and optimization concepts. [Optuna documentation](https://optuna.readthedocs.io/en/latest/)

# Closing perspective {.unnumbered}

The central statistical object is not an individual observed elasticity. It is the conditional distribution of randomized price arms among buyers. Bayes' rule turns that distribution into two relative conversion risks.

The two-gap model respects the actual dimensionality of the three-price experiment. It estimates one high-side gap and one low-side gap, imposes monotone demand, and makes no unnecessary continuous-curve assumption. The scalar model earns its lower variance by adding a common-slope restriction. Pairwise models trade exact joint coupling for compatibility with mature binary tree tooling.

The correct production question is therefore not "Which algorithm has the largest AUC?" It is:

> Which structural restriction and learning algorithm produce the most accurate, calibrated, stable, and economically valuable out-of-sample risk ratios under the randomized experiment?

The answer must come from the real quote-level test, with global anchors, nested validation, uncertainty, and a preserved randomized exploration population.
