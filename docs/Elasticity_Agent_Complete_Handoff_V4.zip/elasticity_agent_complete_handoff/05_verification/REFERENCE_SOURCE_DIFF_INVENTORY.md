# Reference source diff inventory: v0.5.0 to v0.6.0

Generated with a path-level recursive comparison. Documentation and QA files are included.

```text
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0: CHANGELOG.md
Only in /mnt/data/_v050_compare: FILE_SHA256SUMS.txt
Files /mnt/data/_v050_compare/LLM_AGENT_INSTRUCTION.md and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/LLM_AGENT_INSTRUCTION.md differ
Files /mnt/data/_v050_compare/README.md and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/README.md differ
Files /mnt/data/_v050_compare/RESEARCH_LOG.md and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/RESEARCH_LOG.md differ
Files /mnt/data/_v050_compare/config/example_config.yaml and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/config/example_config.yaml differ
Files /mnt/data/_v050_compare/elasticity_only/__init__.py and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only/__init__.py differ
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only: capabilities.py
Files /mnt/data/_v050_compare/elasticity_only/optuna_spaces.py and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only/optuna_spaces.py differ
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only: ordinal.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only: preservation.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only: residual.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only: shared.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/elasticity_only: torch_shared.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/examples: 06_fit_shared_two_slope.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/examples: 07_fit_all_threshold.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/examples: 08_common_residual_workflow.py
Files /mnt/data/_v050_compare/pyproject.toml and /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/pyproject.toml differ
Only in /mnt/data/_v050_compare/qa: COVERAGE.txt
Only in /mnt/data/_v050_compare/qa: ENVIRONMENT.json
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/qa: ENVIRONMENT_V060.json
Only in /mnt/data/_v050_compare/qa: QA_REPORT.md
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/qa: QA_REPORT_V060.md
Only in /mnt/data/_v050_compare/qa: TEST_RESULTS.txt
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/qa: TEST_RESULTS_V060.txt
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/qa: coverage_v060.xml
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/qa: legacy_v050
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0: requirements-verified.txt
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/tests: test_new_boosting_smoke.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/tests: test_ordinal.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/tests: test_preservation.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/tests: test_residual.py
Only in /mnt/data/elasticity_agent_complete_handoff/03_reference_implementation_v0.6.0/tests: test_shared.py
```
