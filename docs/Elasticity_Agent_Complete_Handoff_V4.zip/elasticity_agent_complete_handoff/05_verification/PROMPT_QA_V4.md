# Prompt QA — V4

- Words: 11997
- Lines: 2475
- Required concept checks: 12/12 passed.
- Missing checks: none

The active prompt explicitly treats the evolved repository as the source of truth, requires preservation before implementation, maps the supplied Python files rather than overwriting current code, protects real-data adaptation and artifacts, and includes the latest shared-information models and ablations.
