# No real insurance data included

The bundle contains source code, tests, documentation, empty schema templates,
configuration examples, and historical reference packages.

It does not contain:

- real quote rows;
- customer identifiers;
- policy records;
- proprietary feature values;
- model predictions from a real portfolio;
- Optuna databases from the user's repository;
- serialized models trained on real data;
- secrets or connection strings.

The CSV files in the bundle are templates with headers or metadata fields only.
The deterministic arrays in tests are software fixtures and are not presented
as an insurance dataset or model-quality evidence.
