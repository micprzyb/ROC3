#!/usr/bin/env python3
"""Verify the extracted handoff bundle and optionally run reference tests."""
from __future__ import annotations

import argparse
from hashlib import sha256
from pathlib import Path
import subprocess
import sys


def hash_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify(root: Path) -> int:
    manifest = root / "05_verification" / "SHA256SUMS.txt"
    if not manifest.exists():
        print(f"Missing manifest: {manifest}", file=sys.stderr)
        return 2
    failures = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        path = root / relative
        if not path.exists():
            print(f"MISSING  {relative}")
            failures += 1
            continue
        actual = hash_file(path)
        if actual != expected:
            print(f"FAILED   {relative}")
            failures += 1
        else:
            print(f"OK       {relative}")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-tests", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    failures = verify(root)
    if failures:
        return 1
    if args.run_tests:
        package = root / "03_reference_implementation_v0.6.0"
        env = dict(__import__("os").environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        return subprocess.call(
            [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"],
            cwd=package,
            env=env,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
