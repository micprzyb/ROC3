# Historical Python reference packages

These ZIP files are preserved byte-for-byte from earlier releases.  They are
included because an earlier agent may have adapted one of them, renamed its
classes, or ported pieces into another framework.

| File | Historical role | Use now |
|---|---|---|
| `Elasticity_Only_Insurance_Python_Reference_initial.zip` | Initial elasticity-only package | Provenance and diff only |
| `Elasticity_Only_Insurance_Python_Reference_v0.4.0.zip` | Power-law derivation and scalar-learning correction | Provenance and diff only |
| `Elasticity_Only_Insurance_Python_Reference_v0.5.0.zip` | Exact two-gap release | Immediate predecessor of v0.6.0 |

Do not install these over the current repository.  Compare them with the
preserved host code to determine which changes came from the earlier reference
and which came from the agent's own real-data integration work.
