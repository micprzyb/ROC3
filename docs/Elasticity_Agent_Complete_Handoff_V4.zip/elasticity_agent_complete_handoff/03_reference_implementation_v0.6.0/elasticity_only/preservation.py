"""Non-destructive preservation and fingerprint helpers for agent upgrades.

These helpers are deliberately conservative.  They create new manifests and
fail when an output path already exists.  They never delete files, mutate raw
data, clear caches, or rewrite version-control history.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from pathlib import Path
from typing import Iterable, Sequence
import json
import os
import tempfile

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class FileFingerprint:
    relative_path: str
    size_bytes: int
    modified_ns: int
    sha256: str


def sha256_file(path: str | Path, *, chunk_size: int = 1024 * 1024) -> str:
    """Hash one file without loading it fully into memory."""
    p = Path(path)
    digest = sha256()
    with p.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_new(path: str | Path, content: str | bytes) -> Path:
    """Atomically create a new file and refuse to overwrite an existing path."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError(f"refusing to overwrite existing path: {target}")
    mode = "wb" if isinstance(content, bytes) else "w"
    kwargs = {} if isinstance(content, bytes) else {"encoding": "utf-8"}
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, mode, **kwargs) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temp, target)
    finally:
        temp.unlink(missing_ok=True)
    return target


def inventory_tree(
    root: str | Path,
    *,
    exclude_names: Sequence[str] = (".git", "__pycache__", ".pytest_cache"),
    max_file_bytes: int | None = None,
) -> list[FileFingerprint]:
    """Create a deterministic file manifest without modifying the tree."""
    base = Path(root).resolve()
    records: list[FileFingerprint] = []
    excluded = set(exclude_names)
    for path in sorted(base.rglob("*")):
        if not path.is_file() or any(part in excluded for part in path.relative_to(base).parts):
            continue
        stat = path.stat()
        if max_file_bytes is not None and stat.st_size > max_file_bytes:
            digest = "SKIPPED_SIZE_LIMIT"
        else:
            digest = sha256_file(path)
        records.append(
            FileFingerprint(
                relative_path=path.relative_to(base).as_posix(),
                size_bytes=int(stat.st_size),
                modified_ns=int(stat.st_mtime_ns),
                sha256=digest,
            )
        )
    return records


def write_inventory_json(path: str | Path, records: Iterable[FileFingerprint]) -> Path:
    payload = json.dumps([asdict(record) for record in records], indent=2, sort_keys=True)
    return atomic_write_new(path, payload + "\n")


def dataframe_fingerprint(
    frame: pd.DataFrame,
    *,
    key_columns: Sequence[str] = (),
    include_value_hash: bool = False,
) -> dict[str, object]:
    """Return a privacy-conscious structural fingerprint of a prepared table.

    By default this records schema, row count, missing counts, and uniqueness of
    approved key columns.  ``include_value_hash=True`` hashes pandas' stable row
    hashes but should only be used inside the approved data-security boundary.
    """
    missing = {str(c): int(frame[c].isna().sum()) for c in frame.columns}
    result: dict[str, object] = {
        "rows": int(len(frame)),
        "columns": int(frame.shape[1]),
        "column_order": [str(c) for c in frame.columns],
        "dtypes": {str(c): str(frame[c].dtype) for c in frame.columns},
        "missing_counts": missing,
        "key_unique_counts": {
            str(c): int(frame[c].nunique(dropna=False)) for c in key_columns
        },
    }
    if include_value_hash:
        row_hash = pd.util.hash_pandas_object(frame, index=True).to_numpy(np.uint64)
        result["value_hash_sha256"] = sha256(row_hash.tobytes()).hexdigest()
    return result
