"""Models that share information between high- and low-price responses.

The unrestricted two-gap model has two response functions.  Low-arm buyers do
not directly add efficient information about the high/control gap when the
low-side response is an unrestricted nuisance.  Cross-arm transfer therefore
requires an explicit assumption.  This module implements a transparent
partial-pooling assumption:

    beta_H(x) = softplus(f_common(x) + f_high(x))
    beta_L(x) = softplus(f_common(x) + f_low(x))

The common surface is informed by all buyer arms.  The two deviation surfaces
allow asymmetric responses.  Strong deviation penalties approach a common
scalar response; weak penalties approach an unrestricted two-slope model.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.optimize import minimize
from scipy.special import expit, logsumexp
from sklearn.base import BaseEstimator, RegressorMixin

from .core import (
    DEFAULT_PI,
    DEFAULT_Z,
    as_arm_index,
    buyer_posterior_from_log_rr,
    inverse_softplus,
    project_log_rr_sign,
    softplus,
    validate_doses,
    validate_propensities,
)
from .scalar import fit_global_scalar_beta

FloatArray = NDArray[np.float64]


def _as_weight(sample_weight: ArrayLike | None, n: int) -> FloatArray:
    w = (
        np.ones(n, dtype=float)
        if sample_weight is None
        else np.asarray(sample_weight, dtype=float).reshape(-1)
    )
    if len(w) != n or np.any(~np.isfinite(w)) or np.any(w < 0.0) or not np.any(w > 0.0):
        raise ValueError("invalid sample_weight")
    return w


def positive_side_doses(z: ArrayLike, n: int) -> tuple[FloatArray, FloatArray]:
    """Return positive H/C and C/L log-price distances."""
    zz = validate_doses(z, n)
    high = zz[:, 0] - zz[:, 1]
    low = zz[:, 1] - zz[:, 2]
    if np.any(high <= 0.0) or np.any(low <= 0.0):
        raise ValueError("expected price order H > C > L in log-price dose")
    return high, low


def shared_two_slope_posterior(
    beta_high: ArrayLike,
    beta_low: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
    z: ArrayLike = DEFAULT_Z,
) -> FloatArray:
    """Buyer-arm probabilities under side-specific nonnegative slopes."""
    bh = np.asarray(beta_high, dtype=float).reshape(-1)
    bl = np.asarray(beta_low, dtype=float).reshape(-1)
    n = max(len(bh), len(bl))
    if len(bh) == 1 and n > 1:
        bh = np.full(n, float(bh[0]))
    if len(bl) == 1 and n > 1:
        bl = np.full(n, float(bl[0]))
    if len(bh) != n or len(bl) != n or np.any(bh < 0.0) or np.any(bl < 0.0):
        raise ValueError("side elasticities must be aligned and nonnegative")
    p = validate_propensities(pi, n)
    dh, dl = positive_side_doses(z, n)
    log_rr_h = -dh * bh
    log_rr_l = dl * bl
    return buyer_posterior_from_log_rr(log_rr_h, log_rr_l, p)


def shared_two_slope_raw_loss_gradient(
    raw_common: ArrayLike,
    raw_high_deviation: ArrayLike,
    raw_low_deviation: ArrayLike,
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
    z: ArrayLike = DEFAULT_Z,
    *,
    sample_weight: ArrayLike | None = None,
) -> tuple[FloatArray, FloatArray]:
    """Per-row categorical NLL and gradients for three raw score surfaces.

    The returned gradient columns correspond to ``raw_common``,
    ``raw_high_deviation``, and ``raw_low_deviation``.
    """
    t = as_arm_index(arm)
    n = len(t)

    def align(x: ArrayLike, name: str) -> FloatArray:
        a = np.asarray(x, dtype=float).reshape(-1)
        if len(a) == 1 and n > 1:
            a = np.full(n, float(a[0]))
        if len(a) != n or np.any(~np.isfinite(a)):
            raise ValueError(f"{name} must align with arm")
        return a

    fc = align(raw_common, "raw_common")
    fh = align(raw_high_deviation, "raw_high_deviation")
    fl = align(raw_low_deviation, "raw_low_deviation")
    p = validate_propensities(pi, n)
    dh, dl = positive_side_doses(z, n)
    w = _as_weight(sample_weight, n)

    total_h = fc + fh
    total_l = fc + fl
    beta_h = softplus(total_h)
    beta_l = softplus(total_l)
    log_rr_h = -dh * beta_h
    log_rr_l = dl * beta_l
    logits = np.log(p) + np.column_stack((log_rr_h, np.zeros(n), log_rr_l))
    log_norm = logsumexp(logits, axis=1)
    loss = log_norm - logits[np.arange(n), t]
    r = np.exp(logits - log_norm[:, None])

    grad_u = (t == 0).astype(float) - r[:, 0]
    grad_v = r[:, 2] - (t == 2).astype(float)
    grad_total_h = grad_u * dh * expit(total_h)
    grad_total_l = grad_v * dl * expit(total_l)
    grad = np.column_stack(
        (
            grad_total_h + grad_total_l,
            grad_total_h,
            grad_total_l,
        )
    )
    return w * loss, w[:, None] * grad


@dataclass(frozen=True)
class SharedTwoSlopeFitSummary:
    objective: float
    converged: bool
    iterations: int
    message: str
    global_beta: float


class SklearnSharedTwoSlopeFlipRegressor(BaseEstimator, RegressorMixin):
    """Exact joint partial-pooling model with linear common and deviation surfaces.

    Let ``phi(x)`` be the input matrix supplied to this estimator.  It learns

    ``f0(x) = a0 + phi(x) @ b0``
    ``fH(x) = aH + phi(x) @ bH``
    ``fL(x) = aL + phi(x) @ bL``

    and then

    ``beta_H(x) = softplus(f0(x) + fH(x))``
    ``beta_L(x) = softplus(f0(x) + fL(x))``.

    The exact three-arm buyer categorical likelihood trains all three surfaces.
    ``deviation_l2`` is the principal information-sharing control: large values
    force the side deviations toward zero and approach a common response.
    The model is intentionally a transparent reference implementation; it is
    not a claim that linear surfaces are the best production architecture.
    """

    def __init__(
        self,
        *,
        common_l2: float = 1.0,
        deviation_l2: float = 10.0,
        asymmetry_l2: float = 0.0,
        fit_intercept: bool = True,
        penalize_deviation_intercepts: bool = True,
        max_iter: int = 3000,
        tol: float = 1e-8,
        beta_upper_global_fit: float = 30.0,
    ) -> None:
        self.common_l2 = common_l2
        self.deviation_l2 = deviation_l2
        self.asymmetry_l2 = asymmetry_l2
        self.fit_intercept = fit_intercept
        self.penalize_deviation_intercepts = penalize_deviation_intercepts
        self.max_iter = max_iter
        self.tol = tol
        self.beta_upper_global_fit = beta_upper_global_fit

    @staticmethod
    def _matvec(X: Any, coef: FloatArray) -> FloatArray:
        return np.asarray(X @ coef, dtype=float).reshape(-1)

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        pi: ArrayLike = DEFAULT_PI,
        z: ArrayLike = DEFAULT_Z,
        sample_weight: ArrayLike | None = None,
    ) -> "SklearnSharedTwoSlopeFlipRegressor":
        penalties = (self.common_l2, self.deviation_l2, self.asymmetry_l2)
        if any((not np.isfinite(v) or v < 0.0) for v in penalties):
            raise ValueError("penalties must be finite and nonnegative")
        if self.max_iter <= 0 or not np.isfinite(self.tol) or self.tol <= 0.0:
            raise ValueError("invalid optimizer controls")
        if not hasattr(X, "shape") or len(X.shape) != 2:
            raise ValueError("X must be a two-dimensional matrix")

        t = as_arm_index(y)
        n, p_features = X.shape
        if n != len(t):
            raise ValueError("X and y must align")
        prop = validate_propensities(pi, n)
        zz = validate_doses(z, n)
        dh, dl = positive_side_doses(zz, n)
        w = _as_weight(sample_weight, n)
        wsum = float(np.sum(w))

        global_fit = fit_global_scalar_beta(
            t,
            prop,
            zz,
            sample_weight=w,
            beta_upper=self.beta_upper_global_fit,
        )
        global_beta = max(float(global_fit.beta), 1e-10)
        raw_global = float(inverse_softplus([global_beta])[0])

        block = p_features + (1 if self.fit_intercept else 0)
        initial = np.zeros(3 * block, dtype=float)
        if self.fit_intercept:
            initial[0] = raw_global
            # deviation intercepts remain zero, so both side slopes begin at
            # the fold-local global scalar elasticity.

        def unpack(params: FloatArray) -> tuple[float, FloatArray, float, FloatArray, float, FloatArray]:
            blocks = [params[j * block : (j + 1) * block] for j in range(3)]
            out: list[Any] = []
            for b in blocks:
                if self.fit_intercept:
                    out.extend((float(b[0]), np.asarray(b[1:], dtype=float)))
                else:
                    out.extend((0.0, np.asarray(b, dtype=float)))
            return tuple(out)  # type: ignore[return-value]

        def objective_and_gradient(params: FloatArray) -> tuple[float, FloatArray]:
            a0, b0, ah, bh, al, bl = unpack(params)
            f0 = a0 + self._matvec(X, b0)
            fhd = ah + self._matvec(X, bh)
            fld = al + self._matvec(X, bl)
            total_h = f0 + fhd
            total_l = f0 + fld
            beta_h = softplus(total_h)
            beta_l = softplus(total_l)
            sh = expit(total_h)
            sl = expit(total_l)

            log_rr_h = -dh * beta_h
            log_rr_l = dl * beta_l
            logits = np.log(prop) + np.column_stack((log_rr_h, np.zeros(n), log_rr_l))
            log_norm = logsumexp(logits, axis=1)
            row_loss = log_norm - logits[np.arange(n), t]
            r = np.exp(logits - log_norm[:, None])

            grad_u = (t == 0).astype(float) - r[:, 0]
            grad_v = r[:, 2] - (t == 2).astype(float)
            gh = grad_u * dh * sh
            gl = grad_v * dl * sl
            g0 = gh + gl

            asym = beta_h - beta_l
            if self.asymmetry_l2 > 0.0:
                gh = gh + self.asymmetry_l2 * asym * sh
                gl = gl - self.asymmetry_l2 * asym * sl
                g0 = gh + gl

            wg0 = w * g0 / wsum
            wgh = w * gh / wsum
            wgl = w * gl / wsum

            common_penalty = 0.5 * self.common_l2 * float(np.dot(b0, b0))
            dev_penalty = 0.5 * self.deviation_l2 * (
                float(np.dot(bh, bh)) + float(np.dot(bl, bl))
            )
            if self.fit_intercept and self.penalize_deviation_intercepts:
                dev_penalty += 0.5 * self.deviation_l2 * (ah * ah + al * al)
            asym_penalty = (
                0.5 * self.asymmetry_l2 * float(np.dot(w, asym * asym) / wsum)
            )
            loss = float(np.dot(w, row_loss) / wsum) + common_penalty + dev_penalty + asym_penalty

            gb0 = np.asarray(X.T @ wg0, dtype=float).reshape(-1) + self.common_l2 * b0
            gbh = np.asarray(X.T @ wgh, dtype=float).reshape(-1) + self.deviation_l2 * bh
            gbl = np.asarray(X.T @ wgl, dtype=float).reshape(-1) + self.deviation_l2 * bl

            if self.fit_intercept:
                gah = float(np.sum(wgh))
                gal = float(np.sum(wgl))
                if self.penalize_deviation_intercepts:
                    gah += self.deviation_l2 * ah
                    gal += self.deviation_l2 * al
                gradient = np.concatenate(
                    (
                        [float(np.sum(wg0))],
                        gb0,
                        [gah],
                        gbh,
                        [gal],
                        gbl,
                    )
                )
            else:
                gradient = np.concatenate((gb0, gbh, gbl))
            return loss, gradient

        result = minimize(
            objective_and_gradient,
            initial,
            method="L-BFGS-B",
            jac=True,
            options={
                "maxiter": int(self.max_iter),
                "ftol": float(self.tol),
                "gtol": float(self.tol),
            },
        )
        if np.any(~np.isfinite(result.x)) or not np.isfinite(result.fun):
            raise RuntimeError("shared two-slope optimization produced non-finite values")

        (
            self.intercept_common_,
            self.coef_common_,
            self.intercept_high_deviation_,
            self.coef_high_deviation_,
            self.intercept_low_deviation_,
            self.coef_low_deviation_,
        ) = unpack(np.asarray(result.x, dtype=float))
        self.n_features_in_ = int(p_features)
        self.global_beta_ = global_beta
        self.fit_summary_ = SharedTwoSlopeFitSummary(
            objective=float(result.fun),
            converged=bool(result.success),
            iterations=int(getattr(result, "nit", 0)),
            message=str(result.message),
            global_beta=global_beta,
        )
        return self

    def _raw_surfaces(self, X: Any) -> tuple[FloatArray, FloatArray, FloatArray]:
        if not hasattr(self, "coef_common_"):
            raise RuntimeError("estimator is not fitted")
        if not hasattr(X, "shape") or len(X.shape) != 2 or X.shape[1] != self.n_features_in_:
            raise ValueError("X has an unexpected shape")
        f0 = self.intercept_common_ + self._matvec(X, self.coef_common_)
        fh = self.intercept_high_deviation_ + self._matvec(X, self.coef_high_deviation_)
        fl = self.intercept_low_deviation_ + self._matvec(X, self.coef_low_deviation_)
        return f0, fh, fl

    def predict_side_elasticities(self, X: Any) -> FloatArray:
        f0, fh, fl = self._raw_surfaces(X)
        return np.column_stack((softplus(f0 + fh), softplus(f0 + fl)))

    def predict_log_rr(
        self,
        X: Any,
        *,
        z: ArrayLike = DEFAULT_Z,
        enforce_monotonicity: bool = True,
    ) -> tuple[FloatArray, FloatArray]:
        beta = self.predict_side_elasticities(X)
        dh, dl = positive_side_doses(z, len(beta))
        h = -dh * beta[:, 0]
        l = dl * beta[:, 1]
        return project_log_rr_sign(h, l) if enforce_monotonicity else (h, l)

    def predict_buyer_posterior(
        self,
        X: Any,
        *,
        pi: ArrayLike = DEFAULT_PI,
        z: ArrayLike = DEFAULT_Z,
    ) -> FloatArray:
        h, l = self.predict_log_rr(X, z=z)
        return buyer_posterior_from_log_rr(h, l, pi)

    def predict(self, X: Any) -> FloatArray:
        """Return the two positive side-specific log-elasticity magnitudes."""
        return self.predict_side_elasticities(X)
