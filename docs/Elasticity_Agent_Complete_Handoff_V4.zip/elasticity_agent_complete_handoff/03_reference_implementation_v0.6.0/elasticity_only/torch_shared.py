"""Optional PyTorch reference models for exact shared-information training.

PyTorch is intentionally an optional dependency.  The primary package remains
usable with scikit-learn, LightGBM, XGBoost, and Random Forest.  This module is
included because a neural shared trunk is the clearest implementation of true
multi-task representation sharing between the high- and low-price responses.
"""
from __future__ import annotations

from typing import Iterable, Sequence

try:
    import torch
    from torch import Tensor, nn
    import torch.nn.functional as F
except ImportError as exc:  # pragma: no cover - optional dependency
    raise ImportError(
        "torch_shared requires PyTorch; install the optional 'torch' dependency"
    ) from exc


class SharedTwoSlopeNetwork(nn.Module):
    """Shared trunk with one common sensitivity head and two deviation heads.

    The outputs are

    ``beta_H = softplus(common + high_deviation)`` and
    ``beta_L = softplus(common + low_deviation)``.

    Deviation heads can be strongly regularized or initialized at zero.  This
    lets all arms train a common representation while retaining asymmetric
    high- and low-side behavior.
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dims: Sequence[int] = (128, 64),
        *,
        dropout: float = 0.1,
        activation: str = "silu",
    ) -> None:
        super().__init__()
        if input_dim <= 0:
            raise ValueError("input_dim must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0,1)")
        act_factory: type[nn.Module]
        if activation == "silu":
            act_factory = nn.SiLU
        elif activation == "relu":
            act_factory = nn.ReLU
        elif activation == "gelu":
            act_factory = nn.GELU
        else:
            raise ValueError("activation must be silu, relu, or gelu")

        layers: list[nn.Module] = []
        width = input_dim
        for hidden in hidden_dims:
            if hidden <= 0:
                raise ValueError("hidden dimensions must be positive")
            layers.extend(
                [
                    nn.Linear(width, hidden),
                    act_factory(),
                    nn.Dropout(dropout),
                ]
            )
            width = hidden
        self.trunk = nn.Sequential(*layers) if layers else nn.Identity()
        self.common_head = nn.Linear(width, 1)
        self.high_deviation_head = nn.Linear(width, 1)
        self.low_deviation_head = nn.Linear(width, 1)

        nn.init.zeros_(self.high_deviation_head.weight)
        nn.init.zeros_(self.high_deviation_head.bias)
        nn.init.zeros_(self.low_deviation_head.weight)
        nn.init.zeros_(self.low_deviation_head.bias)

    def forward(self, x: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        h = self.trunk(x)
        common = self.common_head(h).squeeze(-1)
        high_dev = self.high_deviation_head(h).squeeze(-1)
        low_dev = self.low_deviation_head(h).squeeze(-1)
        beta_high = F.softplus(common + high_dev)
        beta_low = F.softplus(common + low_dev)
        return beta_high, beta_low, h

    def log_risk_ratios(
        self,
        x: Tensor,
        high_dose: Tensor,
        low_dose: Tensor,
    ) -> tuple[Tensor, Tensor]:
        beta_high, beta_low, _ = self(x)
        return -high_dose * beta_high, low_dose * beta_low

    def buyer_logits(
        self,
        x: Tensor,
        log_propensity: Tensor,
        high_dose: Tensor,
        low_dose: Tensor,
    ) -> Tensor:
        log_rr_h, log_rr_l = self.log_risk_ratios(x, high_dose, low_dose)
        zero = torch.zeros_like(log_rr_h)
        return log_propensity + torch.stack((log_rr_h, zero, log_rr_l), dim=1)


def categorical_buyer_loss(
    logits: Tensor,
    arm_index: Tensor,
    *,
    sample_weight: Tensor | None = None,
) -> Tensor:
    """Exact categorical buyer negative log-likelihood."""
    rows = F.cross_entropy(logits, arm_index.long(), reduction="none")
    if sample_weight is None:
        return rows.mean()
    weight = sample_weight.to(rows.dtype)
    return torch.sum(weight * rows) / torch.sum(weight)


def cumulative_targets_torch(arm_index: Tensor) -> Tensor:
    t = arm_index.long()
    return torch.stack(((t == 0).to(torch.float32), (t <= 1).to(torch.float32)), dim=1)


def cumulative_buyer_loss(
    logits: Tensor,
    arm_index: Tensor,
    *,
    threshold_weight: tuple[float, float] = (1.0, 1.0),
    sample_weight: Tensor | None = None,
) -> Tensor:
    """Proper all-threshold log score computed from categorical logits."""
    prob = torch.softmax(logits, dim=1)
    cumulative = torch.stack((prob[:, 0], prob[:, 0] + prob[:, 1]), dim=1)
    targets = cumulative_targets_torch(arm_index).to(cumulative.dtype)
    rows = F.binary_cross_entropy(
        cumulative.clamp(1e-7, 1.0 - 1e-7), targets, reduction="none"
    )
    tw = torch.tensor(threshold_weight, dtype=rows.dtype, device=rows.device)
    rows = torch.sum(rows * tw, dim=1)
    if sample_weight is None:
        return rows.mean()
    weight = sample_weight.to(rows.dtype)
    return torch.sum(weight * rows) / torch.sum(weight)


def hybrid_buyer_loss(
    logits: Tensor,
    arm_index: Tensor,
    *,
    ordinal_weight: float = 0.0,
    threshold_weight: tuple[float, float] = (1.0, 1.0),
    sample_weight: Tensor | None = None,
) -> Tensor:
    """Categorical likelihood plus optional proper cumulative auxiliary loss."""
    if ordinal_weight < 0.0:
        raise ValueError("ordinal_weight must be nonnegative")
    loss = categorical_buyer_loss(logits, arm_index, sample_weight=sample_weight)
    if ordinal_weight:
        loss = loss + ordinal_weight * cumulative_buyer_loss(
            logits,
            arm_index,
            threshold_weight=threshold_weight,
            sample_weight=sample_weight,
        )
    return loss


def deviation_penalty(
    model: SharedTwoSlopeNetwork,
    *,
    coefficient: float,
) -> Tensor:
    """L2 penalty on the two deviation heads only."""
    if coefficient < 0.0:
        raise ValueError("coefficient must be nonnegative")
    if coefficient == 0.0:
        return next(model.parameters()).new_zeros(())
    terms: Iterable[Tensor] = (
        *model.high_deviation_head.parameters(),
        *model.low_deviation_head.parameters(),
    )
    return 0.5 * coefficient * sum(torch.sum(p * p) for p in terms)
