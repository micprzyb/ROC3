"""Runtime capability discovery for optional model backends."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import Any


@dataclass(frozen=True)
class BackendCapabilities:
    sklearn_version: str | None
    lightgbm_version: str | None
    xgboost_version: str | None
    optuna_version: str | None
    torch_version: str | None
    xgboost_multi_output_tree_candidate: bool
    notes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _package_version(name: str) -> str | None:
    try:
        return version(name)
    except PackageNotFoundError:
        return None


def _major_minor(v: str | None) -> tuple[int, int] | None:
    if v is None:
        return None
    try:
        parts = v.split(".")
        return int(parts[0]), int(parts[1])
    except (ValueError, IndexError):
        return None


def detect_backend_capabilities() -> BackendCapabilities:
    """Inspect installed versions without fitting a model or changing state."""
    sk = _package_version("scikit-learn")
    lgb = _package_version("lightgbm")
    xgb = _package_version("xgboost")
    optuna = _package_version("optuna")
    torch = _package_version("torch")
    xgb_mm = _major_minor(xgb)
    candidate = bool(xgb_mm is not None and xgb_mm >= (2, 0))
    notes = [
        "Version detection is not a substitute for a backend smoke test.",
        "XGBoost multi_output_tree remains a challenger and may have feature limitations.",
        "LightGBM and default XGBoost multiclass normally use output-specific trees.",
    ]
    return BackendCapabilities(
        sklearn_version=sk,
        lightgbm_version=lgb,
        xgboost_version=xgb,
        optuna_version=optuna,
        torch_version=torch,
        xgboost_multi_output_tree_candidate=candidate,
        notes=tuple(notes),
    )
