"""Exact monotone two-gap Bayes-flip models.

The two-gap model is the saturated monotone relative-risk model for three
randomized price arms.  It defines

    u(x) = log(q_C(x) / q_H(x)) >= 0
    v(x) = log(q_L(x) / q_C(x)) >= 0

so that ``log RR_HC = -u`` and ``log RR_LC = v``.  Among buyers,

    P(T=t | Y=1, X=x) = softmax(log(pi) + [-u, 0, v])_t.

No individual elasticity labels are required.  The gaps are learned from the
observed randomized arm labels of buyers by categorical maximum likelihood.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.optimize import minimize
from scipy.special import expit, logsumexp
from sklearn.base import BaseEstimator, RegressorMixin

from .core import (
    DEFAULT_PI,
    DEFAULT_Z,
    as_arm_index,
    inverse_softplus,
    softplus,
    validate_doses,
    validate_propensities,
)

FloatArray = NDArray[np.float64]


def _as_1d(x: ArrayLike, n: int, name: str) -> FloatArray:
    arr = np.asarray(x, dtype=float).reshape(-1)
    if len(arr) == 1 and n > 1:
        arr = np.full(n, float(arr[0]), dtype=float)
    if len(arr) != n or np.any(~np.isfinite(arr)):
        raise ValueError(f"{name} must be finite and align with the rows")
    return arr


def two_gap_buyer_posterior(
    gap_high: ArrayLike,
    gap_low: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
) -> FloatArray:
    """Return buyer-arm probabilities under nonnegative high and low gaps.

    Parameters
    ----------
    gap_high:
        ``u = log(q_C / q_H)``.  Must be nonnegative.
    gap_low:
        ``v = log(q_L / q_C)``.  Must be nonnegative.
    pi:
        Logged randomization probabilities in arm order H, C, L.
    """
    u0 = np.asarray(gap_high, dtype=float).reshape(-1)
    v0 = np.asarray(gap_low, dtype=float).reshape(-1)
    n = max(len(u0), len(v0))
    u = _as_1d(u0, n, "gap_high")
    v = _as_1d(v0, n, "gap_low")
    if np.any(u < 0.0) or np.any(v < 0.0):
        raise ValueError("two-gap parameters must be nonnegative")
    p = validate_propensities(pi, n)
    logits = np.log(p) + np.column_stack((-u, np.zeros(n), v))
    return np.exp(logits - logsumexp(logits, axis=1, keepdims=True))


def two_gap_nll_rows(
    gap_high: ArrayLike,
    gap_low: ArrayLike,
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
) -> FloatArray:
    """Categorical negative log-likelihood for buyer arm labels."""
    t = as_arm_index(arm)
    u = _as_1d(gap_high, len(t), "gap_high")
    v = _as_1d(gap_low, len(t), "gap_low")
    r = two_gap_buyer_posterior(u, v, pi)
    return -np.log(np.clip(r[np.arange(len(t)), t], 1e-300, 1.0))


def two_gap_gap_grad_hessian(
    gap_high: ArrayLike,
    gap_low: ArrayLike,
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
) -> tuple[FloatArray, FloatArray]:
    """Gradient and exact 2x2 Hessian with respect to direct gaps ``(u, v)``.

    Returns
    -------
    grad:
        Array with shape ``(n_rows, 2)``.
    hessian:
        Array with shape ``(n_rows, 2, 2)``.  Each row Hessian is positive
        semidefinite, so the direct-gap likelihood is convex in ``(u, v)``.
    """
    t = as_arm_index(arm)
    u = _as_1d(gap_high, len(t), "gap_high")
    v = _as_1d(gap_low, len(t), "gap_low")
    r = two_gap_buyer_posterior(u, v, pi)
    ih = (t == 0).astype(float)
    il = (t == 2).astype(float)

    grad = np.column_stack((ih - r[:, 0], r[:, 2] - il))
    hessian = np.empty((len(t), 2, 2), dtype=float)
    hessian[:, 0, 0] = r[:, 0] * (1.0 - r[:, 0])
    hessian[:, 1, 1] = r[:, 2] * (1.0 - r[:, 2])
    hessian[:, 0, 1] = r[:, 0] * r[:, 2]
    hessian[:, 1, 0] = hessian[:, 0, 1]
    return grad, hessian


def two_gap_raw_grad_hessian(
    raw_high: ArrayLike,
    raw_low: ArrayLike,
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
    *,
    hessian: Literal["exact", "fisher"] = "fisher",
    diagonal_only: bool = False,
    hessian_floor: float = 1e-10,
    sample_weight: ArrayLike | None = None,
) -> tuple[FloatArray, FloatArray]:
    """Derivatives after ``u=softplus(f_H)``, ``v=softplus(f_L)``.

    ``fisher`` removes the potentially negative second-derivative terms from
    the positivity links.  It is positive semidefinite.  ``diagonal_only``
    returns only the two diagonal entries and is intended for boosting
    libraries whose custom-objective interface cannot consume the exact
    cross-target Hessian.
    """
    t = as_arm_index(arm)
    fh = _as_1d(raw_high, len(t), "raw_high")
    fl = _as_1d(raw_low, len(t), "raw_low")
    u = softplus(fh)
    v = softplus(fl)
    grad_gap, h_gap = two_gap_gap_grad_hessian(u, v, t, pi)

    sh = expit(fh)
    sl = expit(fl)
    grad = np.column_stack((grad_gap[:, 0] * sh, grad_gap[:, 1] * sl))

    h_raw = np.empty_like(h_gap)
    h_raw[:, 0, 0] = h_gap[:, 0, 0] * sh * sh
    h_raw[:, 1, 1] = h_gap[:, 1, 1] * sl * sl
    h_raw[:, 0, 1] = h_gap[:, 0, 1] * sh * sl
    h_raw[:, 1, 0] = h_raw[:, 0, 1]

    if hessian == "exact":
        h_raw[:, 0, 0] += grad_gap[:, 0] * sh * (1.0 - sh)
        h_raw[:, 1, 1] += grad_gap[:, 1] * sl * (1.0 - sl)
    elif hessian != "fisher":
        raise ValueError("hessian must be 'exact' or 'fisher'")

    if sample_weight is not None:
        w = _as_1d(sample_weight, len(t), "sample_weight")
        if np.any(w < 0.0):
            raise ValueError("sample_weight must be nonnegative")
        grad *= w[:, None]
        h_raw *= w[:, None, None]

    if diagonal_only:
        diag = np.column_stack((h_raw[:, 0, 0], h_raw[:, 1, 1]))
        return grad, np.maximum(diag, hessian_floor)

    if hessian == "fisher":
        # A floor on the diagonal preserves positive semidefiniteness up to
        # numerical precision and avoids zero-curvature rows in optimizers.
        h_raw[:, 0, 0] += hessian_floor
        h_raw[:, 1, 1] += hessian_floor
    return grad, h_raw


@dataclass(frozen=True)
class GlobalTwoGapFit:
    gap_high: float
    gap_low: float
    log_rr_high: float
    log_rr_low: float
    nll: float
    converged: bool
    message: str


def fit_global_two_gap(
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
    *,
    sample_weight: ArrayLike | None = None,
    gap_upper: float = 20.0,
) -> GlobalTwoGapFit:
    """Fit one portfolio-level high gap and one portfolio-level low gap."""
    t = as_arm_index(arm)
    p = validate_propensities(pi, len(t))
    w = (
        np.ones(len(t), dtype=float)
        if sample_weight is None
        else _as_1d(sample_weight, len(t), "sample_weight")
    )
    if np.any(w < 0.0) or not np.any(w > 0.0):
        raise ValueError("sample_weight must contain a positive value")
    wsum = float(np.sum(w))

    def value_and_grad(theta: FloatArray) -> tuple[float, FloatArray]:
        u = np.full(len(t), theta[0], dtype=float)
        v = np.full(len(t), theta[1], dtype=float)
        rows = two_gap_nll_rows(u, v, t, p)
        grad_rows, _ = two_gap_gap_grad_hessian(u, v, t, p)
        value = float(np.dot(w, rows) / wsum)
        grad = np.sum(w[:, None] * grad_rows, axis=0) / wsum
        return value, grad

    result = minimize(
        value_and_grad,
        x0=np.array([0.1, 0.1], dtype=float),
        method="L-BFGS-B",
        jac=True,
        bounds=[(0.0, gap_upper), (0.0, gap_upper)],
        options={"maxiter": 2000, "ftol": 1e-12, "gtol": 1e-10},
    )
    u, v = np.asarray(result.x, dtype=float)
    return GlobalTwoGapFit(
        gap_high=float(u),
        gap_low=float(v),
        log_rr_high=float(-u),
        log_rr_low=float(v),
        nll=float(result.fun),
        converged=bool(result.success),
        message=str(result.message),
    )


def _positive_side_doses(z: ArrayLike, n: int) -> tuple[FloatArray, FloatArray]:
    zz = validate_doses(z, n)
    high = zz[:, 0] - zz[:, 1]
    low = zz[:, 1] - zz[:, 2]
    if np.any(high <= 0.0) or np.any(low <= 0.0):
        raise ValueError(
            "two-slope parameterization requires high price above control "
            "and low price below control"
        )
    return high, low


class SklearnTwoGapFlipRegressor(BaseEstimator, RegressorMixin):
    """Penalized exact two-gap Bayes-flip estimator with linear raw surfaces.

    The estimator learns two functions from buyer arm labels:

    ``u(x) = softplus(a_H + X @ b_H)`` and
    ``v(x) = softplus(a_L + X @ b_L)``.

    With ``parameterization='gap'``, these are the two tested-arm log-risk
    gaps directly.  With ``parameterization='slope'``, the softplus outputs
    are side-specific log-elasticity magnitudes and are multiplied by the
    row-level log-price distances from control.

    ``asymmetry_l2`` shrinks the two side-specific log-elasticity magnitudes
    toward one another.  This nests the scalar constant-log-elasticity model
    as the limiting case of infinite asymmetry shrinkage, subject to the
    chosen feature class.
    """

    def __init__(
        self,
        l2: float = 1.0,
        asymmetry_l2: float = 1.0,
        parameterization: Literal["gap", "slope"] = "slope",
        fit_intercept: bool = True,
        max_iter: int = 2500,
        tol: float = 1e-8,
    ) -> None:
        self.l2 = l2
        self.asymmetry_l2 = asymmetry_l2
        self.parameterization = parameterization
        self.fit_intercept = fit_intercept
        self.max_iter = max_iter
        self.tol = tol

    @staticmethod
    def _matvec(X: Any, coef: FloatArray) -> FloatArray:
        return np.asarray(X @ coef, dtype=float).reshape(-1)

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        pi: ArrayLike = DEFAULT_PI,
        z: ArrayLike = DEFAULT_Z,
        sample_weight: ArrayLike | None = None,
    ) -> "SklearnTwoGapFlipRegressor":
        if self.parameterization not in {"gap", "slope"}:
            raise ValueError("parameterization must be 'gap' or 'slope'")
        if self.l2 < 0.0 or self.asymmetry_l2 < 0.0:
            raise ValueError("penalties must be nonnegative")
        if self.max_iter <= 0 or self.tol <= 0.0:
            raise ValueError("invalid optimizer controls")
        if not hasattr(X, "shape") or len(X.shape) != 2:
            raise ValueError("X must be a two-dimensional matrix")

        t = as_arm_index(y)
        n, p_features = X.shape
        if n != len(t):
            raise ValueError("X and y must align")
        prop = validate_propensities(pi, n)
        high_dose, low_dose = _positive_side_doses(z, n)
        w = (
            np.ones(n, dtype=float)
            if sample_weight is None
            else _as_1d(sample_weight, n, "sample_weight")
        )
        if np.any(w < 0.0) or not np.any(w > 0.0):
            raise ValueError("invalid sample_weight")
        wsum = float(np.sum(w))

        global_fit = fit_global_two_gap(t, prop, sample_weight=w)
        if self.parameterization == "gap":
            start_h = max(global_fit.gap_high, 1e-10)
            start_l = max(global_fit.gap_low, 1e-10)
        else:
            # Use weighted average doses only for initialization.  The fitted
            # likelihood uses each row's actual logged price dose.
            start_h = max(global_fit.gap_high / np.average(high_dose, weights=w), 1e-10)
            start_l = max(global_fit.gap_low / np.average(low_dose, weights=w), 1e-10)

        intercept_h = float(inverse_softplus([start_h])[0])
        intercept_l = float(inverse_softplus([start_l])[0])
        block = p_features + (1 if self.fit_intercept else 0)
        initial = np.zeros(2 * block, dtype=float)
        if self.fit_intercept:
            initial[0] = intercept_h
            initial[block] = intercept_l

        def unpack(params: FloatArray) -> tuple[float, FloatArray, float, FloatArray]:
            if self.fit_intercept:
                ah = float(params[0])
                bh = np.asarray(params[1:block], dtype=float)
                al = float(params[block])
                bl = np.asarray(params[block + 1 :], dtype=float)
            else:
                ah = 0.0
                bh = np.asarray(params[:block], dtype=float)
                al = 0.0
                bl = np.asarray(params[block:], dtype=float)
            return ah, bh, al, bl

        def objective_and_gradient(params: FloatArray) -> tuple[float, FloatArray]:
            ah, bh, al, bl = unpack(params)
            fh = ah + self._matvec(X, bh)
            fl = al + self._matvec(X, bl)
            positive_h = softplus(fh)
            positive_l = softplus(fl)
            sh = expit(fh)
            sl = expit(fl)

            if self.parameterization == "slope":
                beta_h = positive_h
                beta_l = positive_l
                u = beta_h * high_dose
                v = beta_l * low_dose
                du_df = sh * high_dose
                dv_df = sl * low_dose
                asym_diff = beta_h - beta_l
                dasym_h = sh
                dasym_l = -sl
            else:
                u = positive_h
                v = positive_l
                du_df = sh
                dv_df = sl
                beta_h = u / high_dose
                beta_l = v / low_dose
                asym_diff = beta_h - beta_l
                dasym_h = sh / high_dose
                dasym_l = -sl / low_dose

            logits = np.log(prop) + np.column_stack((-u, np.zeros(n), v))
            log_norm = logsumexp(logits, axis=1)
            row_loss = log_norm - logits[np.arange(n), t]
            posterior = np.exp(logits - log_norm[:, None])

            grad_u = (t == 0).astype(float) - posterior[:, 0]
            grad_v = posterior[:, 2] - (t == 2).astype(float)
            grad_fh = grad_u * du_df
            grad_fl = grad_v * dv_df

            asym_loss = 0.5 * self.asymmetry_l2 * np.dot(w, asym_diff * asym_diff) / wsum
            grad_fh += self.asymmetry_l2 * asym_diff * dasym_h
            grad_fl += self.asymmetry_l2 * asym_diff * dasym_l

            wrh = w * grad_fh / wsum
            wrl = w * grad_fl / wsum
            loss = (
                float(np.dot(w, row_loss) / wsum)
                + 0.5 * self.l2 * (float(np.dot(bh, bh)) + float(np.dot(bl, bl)))
                + float(asym_loss)
            )

            grad_bh = np.asarray(X.T @ wrh, dtype=float).reshape(-1) + self.l2 * bh
            grad_bl = np.asarray(X.T @ wrl, dtype=float).reshape(-1) + self.l2 * bl
            if self.fit_intercept:
                gradient = np.concatenate(
                    ([float(np.sum(wrh))], grad_bh, [float(np.sum(wrl))], grad_bl)
                )
            else:
                gradient = np.concatenate((grad_bh, grad_bl))
            return loss, gradient

        result = minimize(
            objective_and_gradient,
            initial,
            method="L-BFGS-B",
            jac=True,
            options={
                "maxiter": int(self.max_iter),
                "ftol": float(self.tol),
                "gtol": float(self.tol),
            },
        )
        if np.any(~np.isfinite(result.x)) or not np.isfinite(result.fun):
            raise RuntimeError("two-gap optimization produced non-finite values")

        self.intercept_high_, self.coef_high_, self.intercept_low_, self.coef_low_ = unpack(
            np.asarray(result.x, dtype=float)
        )
        self.n_features_in_ = int(p_features)
        self.converged_ = bool(result.success)
        self.n_iter_ = int(getattr(result, "nit", 0))
        self.objective_ = float(result.fun)
        self.optimization_message_ = str(result.message)
        self.global_fit_ = global_fit
        return self

    def _raw(self, X: Any) -> tuple[FloatArray, FloatArray]:
        if not hasattr(self, "coef_high_"):
            raise RuntimeError("estimator is not fitted")
        if not hasattr(X, "shape") or len(X.shape) != 2 or X.shape[1] != self.n_features_in_:
            raise ValueError("X has an unexpected shape")
        fh = self.intercept_high_ + self._matvec(X, self.coef_high_)
        fl = self.intercept_low_ + self._matvec(X, self.coef_low_)
        return fh, fl

    def predict_side_elasticities(
        self,
        X: Any,
        *,
        z: ArrayLike = DEFAULT_Z,
    ) -> FloatArray:
        """Return positive high-side and low-side log-elasticity magnitudes."""
        fh, fl = self._raw(X)
        ph, pl = softplus(fh), softplus(fl)
        if self.parameterization == "slope":
            return np.column_stack((ph, pl))
        high_dose, low_dose = _positive_side_doses(z, len(ph))
        return np.column_stack((ph / high_dose, pl / low_dose))

    def predict_gaps(
        self,
        X: Any,
        *,
        z: ArrayLike = DEFAULT_Z,
    ) -> FloatArray:
        fh, fl = self._raw(X)
        ph, pl = softplus(fh), softplus(fl)
        if self.parameterization == "gap":
            return np.column_stack((ph, pl))
        high_dose, low_dose = _positive_side_doses(z, len(ph))
        return np.column_stack((ph * high_dose, pl * low_dose))

    def predict_log_rr(
        self,
        X: Any,
        *,
        z: ArrayLike = DEFAULT_Z,
    ) -> tuple[FloatArray, FloatArray]:
        gaps = self.predict_gaps(X, z=z)
        return -gaps[:, 0], gaps[:, 1]

    def predict(self, X: Any) -> FloatArray:
        """Return side-specific positive log-elasticity magnitudes."""
        return self.predict_side_elasticities(X)

    def predict_buyer_posterior(
        self,
        X: Any,
        *,
        pi: ArrayLike = DEFAULT_PI,
        z: ArrayLike = DEFAULT_Z,
    ) -> FloatArray:
        gaps = self.predict_gaps(X, z=z)
        return two_gap_buyer_posterior(gaps[:, 0], gaps[:, 1], pi)
