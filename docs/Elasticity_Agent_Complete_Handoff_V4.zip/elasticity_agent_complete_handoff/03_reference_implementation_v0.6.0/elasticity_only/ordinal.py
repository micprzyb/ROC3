"""Ordered-arm buyer models and proper cumulative losses.

The experimental arm order is H < C < L when ordered from highest displayed
price to lowest displayed price.  This module supplies an all-threshold
representation of the three-class buyer outcome:

    F1(x) = P(T=H | Y=1, X=x)
    F2(x) = P(T in {H,C} | Y=1, X=x)

Every buyer contributes to both binary thresholds.  The cumulative log score
is a proper score for the full three-class probability vector when
``0 <= F1 <= F2 <= 1``.  It can be used as a challenger or as an auxiliary
term beside the exact categorical buyer likelihood.

No function in this module fabricates insurance observations.  Hand-written
arrays are appropriate only for software tests and derivative checks.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.special import expit
from sklearn.base import BaseEstimator, ClassifierMixin, clone

from .core import (
    DEFAULT_PI,
    as_arm_index,
    buyer_posterior_from_log_rr,
    risk_ratios_from_buyer_posterior,
    stable_logit,
    validate_propensities,
)
from .pairwise import _fit_with_sample_weight, row_subset
from .two_gap import two_gap_buyer_posterior

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


def cumulative_targets(arm: ArrayLike) -> FloatArray:
    """Return the two all-threshold binary targets.

    Arm indices are ``H=0``, ``C=1``, and ``L=2``.  The returned columns are

    ``Z1 = 1{T=H}`` and ``Z2 = 1{T in {H,C}}``.

    Consequently H, C, and L map to ``(1,1)``, ``(0,1)``, and ``(0,0)``.
    """
    t = as_arm_index(arm)
    return np.column_stack(((t == 0).astype(float), (t <= 1).astype(float)))


def cumulative_from_posterior(posterior: ArrayLike) -> FloatArray:
    """Convert class probabilities ``(r_H,r_C,r_L)`` to ``(F1,F2)``."""
    r = np.asarray(posterior, dtype=float)
    if r.ndim != 2 or r.shape[1] != 3:
        raise ValueError("posterior must have shape (n, 3)")
    if np.any(~np.isfinite(r)) or np.any(r < 0.0):
        raise ValueError("posterior must be finite and nonnegative")
    if not np.allclose(r.sum(axis=1), 1.0, atol=1e-8, rtol=1e-8):
        raise ValueError("posterior rows must sum to one")
    return np.column_stack((r[:, 0], r[:, 0] + r[:, 1]))


def project_cumulative_probabilities(cumulative: ArrayLike) -> FloatArray:
    """Euclidean projection onto ``0 <= F1 <= F2 <= 1`` for two thresholds.

    With only two cumulative coordinates, clipping followed by averaging a
    violated pair is the exact Euclidean isotonic projection.
    """
    f = np.asarray(cumulative, dtype=float)
    if f.ndim != 2 or f.shape[1] != 2:
        raise ValueError("cumulative must have shape (n, 2)")
    if np.any(~np.isfinite(f)):
        raise ValueError("cumulative contains non-finite values")
    out = np.clip(f, 0.0, 1.0).copy()
    bad = out[:, 0] > out[:, 1]
    if np.any(bad):
        mean = 0.5 * (out[bad, 0] + out[bad, 1])
        out[bad, 0] = mean
        out[bad, 1] = mean
    return out


def posterior_from_cumulative(
    cumulative: ArrayLike,
    *,
    project: bool = True,
    probability_floor: float = 1e-12,
) -> FloatArray:
    """Recover ``(r_H,r_C,r_L)`` from two cumulative probabilities."""
    if not 0.0 <= probability_floor < 1.0 / 3.0:
        raise ValueError("probability_floor must lie in [0, 1/3)")
    f = (
        project_cumulative_probabilities(cumulative)
        if project
        else np.asarray(cumulative, dtype=float)
    )
    if f.ndim != 2 or f.shape[1] != 2:
        raise ValueError("cumulative must have shape (n, 2)")
    if np.any(f[:, 0] < 0.0) or np.any(f[:, 1] > 1.0) or np.any(f[:, 0] > f[:, 1]):
        raise ValueError("cumulative probabilities are incoherent")
    r = np.column_stack((f[:, 0], f[:, 1] - f[:, 0], 1.0 - f[:, 1]))
    if probability_floor > 0.0:
        r = np.maximum(r, probability_floor)
        r /= r.sum(axis=1, keepdims=True)
    return r


def _binary_log_loss_rows(target: FloatArray, probability: FloatArray) -> FloatArray:
    p = np.clip(np.asarray(probability, dtype=float), 1e-15, 1.0 - 1e-15)
    y = np.asarray(target, dtype=float)
    return -(y * np.log(p) + (1.0 - y) * np.log1p(-p))


def cumulative_log_loss_rows(
    posterior: ArrayLike,
    arm: ArrayLike,
    *,
    threshold_weight: ArrayLike = (1.0, 1.0),
) -> FloatArray:
    """Per-buyer all-threshold cumulative log loss.

    Positive threshold weights preserve the same population minimizer.  They
    change finite-sample emphasis and regularization scale, so they must be
    selected strictly out of fold.
    """
    r = np.asarray(posterior, dtype=float)
    t = as_arm_index(arm)
    if r.shape != (len(t), 3):
        raise ValueError("posterior and arm must align")
    w = np.asarray(threshold_weight, dtype=float).reshape(-1)
    if w.shape != (2,) or np.any(~np.isfinite(w)) or np.any(w <= 0.0):
        raise ValueError("threshold_weight must contain two positive values")
    f = cumulative_from_posterior(r)
    z = cumulative_targets(t)
    return w[0] * _binary_log_loss_rows(z[:, 0], f[:, 0]) + w[1] * _binary_log_loss_rows(
        z[:, 1], f[:, 1]
    )


def categorical_log_loss_rows(posterior: ArrayLike, arm: ArrayLike) -> FloatArray:
    """Per-buyer categorical negative log-likelihood."""
    r = np.asarray(posterior, dtype=float)
    t = as_arm_index(arm)
    if r.shape != (len(t), 3):
        raise ValueError("posterior and arm must align")
    return -np.log(np.clip(r[np.arange(len(t)), t], 1e-300, 1.0))


def hybrid_log_loss_rows(
    posterior: ArrayLike,
    arm: ArrayLike,
    *,
    ordinal_weight: float = 0.0,
    threshold_weight: ArrayLike = (1.0, 1.0),
) -> FloatArray:
    """Exact categorical NLL plus a proper cumulative auxiliary score."""
    if not np.isfinite(ordinal_weight) or ordinal_weight < 0.0:
        raise ValueError("ordinal_weight must be finite and nonnegative")
    cat = categorical_log_loss_rows(posterior, arm)
    if ordinal_weight == 0.0:
        return cat
    return cat + ordinal_weight * cumulative_log_loss_rows(
        posterior, arm, threshold_weight=threshold_weight
    )


def ranked_probability_score_rows(posterior: ArrayLike, arm: ArrayLike) -> FloatArray:
    """Per-buyer ranked probability score for ordered arms H, C, L."""
    r = np.asarray(posterior, dtype=float)
    t = as_arm_index(arm)
    if r.shape != (len(t), 3):
        raise ValueError("posterior and arm must align")
    f = cumulative_from_posterior(r)
    z = cumulative_targets(t)
    return np.sum((f - z) ** 2, axis=1)


def cumulative_two_gap_gradient(
    gap_high: ArrayLike,
    gap_low: ArrayLike,
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
    *,
    threshold_weight: ArrayLike = (1.0, 1.0),
) -> FloatArray:
    """Gradient of cumulative log loss with respect to direct gaps ``(u,v)``.

    This derivative is useful for deterministic checks and custom optimizers.
    It is not an assertion that cumulative loss contains more statistical
    information than the exact categorical likelihood.
    """
    t = as_arm_index(arm)
    u = np.asarray(gap_high, dtype=float).reshape(-1)
    v = np.asarray(gap_low, dtype=float).reshape(-1)
    if len(u) == 1 and len(t) > 1:
        u = np.full(len(t), float(u[0]))
    if len(v) == 1 and len(t) > 1:
        v = np.full(len(t), float(v[0]))
    if len(u) != len(t) or len(v) != len(t):
        raise ValueError("gaps and arm must align")
    w = np.asarray(threshold_weight, dtype=float).reshape(-1)
    if w.shape != (2,) or np.any(w <= 0.0):
        raise ValueError("threshold_weight must contain two positive values")

    r = two_gap_buyer_posterior(u, v, pi)
    z = cumulative_targets(t)
    f1 = np.clip(r[:, 0], 1e-15, 1.0 - 1e-15)
    f2 = np.clip(1.0 - r[:, 2], 1e-15, 1.0 - 1e-15)

    d1 = w[0] * (f1 - z[:, 0]) / (f1 * (1.0 - f1))
    d2 = w[1] * (f2 - z[:, 1]) / (f2 * (1.0 - f2))

    # d r_H / d u = -r_H(1-r_H), d r_H / d v = -r_H r_L
    # d F2 / d u = -r_H r_L,       d F2 / d v = -r_L(1-r_L)
    grad_u = d1 * (-r[:, 0] * (1.0 - r[:, 0])) + d2 * (-r[:, 0] * r[:, 2])
    grad_v = d1 * (-r[:, 0] * r[:, 2]) + d2 * (-r[:, 2] * (1.0 - r[:, 2]))
    return np.column_stack((grad_u, grad_v))


@dataclass(frozen=True)
class ThresholdReplication:
    """Replicated binary table for an all-threshold learner."""

    X: Any
    target: FloatArray
    base_margin: FloatArray
    sample_weight: FloatArray
    original_index: IntArray
    threshold: IntArray
    original_feature_count: int


def _append_threshold_feature(X: Any, threshold: IntArray) -> Any:
    """Append a numeric threshold indicator without mutating the input."""
    try:
        import pandas as pd

        if isinstance(X, pd.DataFrame):
            out = X.iloc[np.repeat(np.arange(len(X)), 2)].reset_index(drop=True).copy()
            name = "__elasticity_threshold__"
            if name in out.columns:
                raise ValueError(f"reserved threshold column {name!r} already exists")
            out[name] = threshold
            return out
    except ImportError:  # pragma: no cover - pandas is a declared dependency
        pass

    try:
        from scipy import sparse

        if sparse.issparse(X):
            repeated = X[np.repeat(np.arange(X.shape[0]), 2)]
            return sparse.hstack(
                [repeated, sparse.csr_matrix(threshold[:, None])], format="csr"
            )
    except ImportError:  # pragma: no cover - scipy is a declared dependency
        pass

    arr = np.asarray(X)
    if arr.ndim != 2:
        raise ValueError("X must be a two-dimensional array, sparse matrix, or DataFrame")
    repeated = np.repeat(arr, 2, axis=0)
    return np.column_stack((repeated, threshold))


def make_all_threshold_replication(
    X: Any,
    arm: ArrayLike,
    pi: ArrayLike = DEFAULT_PI,
    *,
    sample_weight: ArrayLike | None = None,
    threshold_weight: ArrayLike = (1.0, 1.0),
) -> ThresholdReplication:
    """Create the two-row-per-buyer representation used by cumulative models."""
    t = as_arm_index(arm)
    if not hasattr(X, "shape") or len(X.shape) != 2 or X.shape[0] != len(t):
        raise ValueError("X and arm must align")
    p = validate_propensities(pi, len(t))
    base = (
        np.ones(len(t), dtype=float)
        if sample_weight is None
        else np.asarray(sample_weight, dtype=float).reshape(-1)
    )
    if len(base) != len(t) or np.any(~np.isfinite(base)) or np.any(base < 0.0):
        raise ValueError("invalid sample_weight")
    tw = np.asarray(threshold_weight, dtype=float).reshape(-1)
    if tw.shape != (2,) or np.any(~np.isfinite(tw)) or np.any(tw <= 0.0):
        raise ValueError("threshold_weight must contain two positive values")

    original_index = np.repeat(np.arange(len(t), dtype=np.int64), 2)
    threshold = np.tile(np.array([0, 1], dtype=np.int64), len(t))
    target = cumulative_targets(t).reshape(-1)
    prior = np.column_stack((p[:, 0], p[:, 0] + p[:, 1])).reshape(-1)
    base_margin = stable_logit(prior)
    replicated_weight = np.repeat(base, 2) * np.tile(tw, len(t))
    X_replicated = _append_threshold_feature(X, threshold)
    return ThresholdReplication(
        X=X_replicated,
        target=target,
        base_margin=base_margin,
        sample_weight=replicated_weight,
        original_index=original_index,
        threshold=threshold,
        original_feature_count=int(X.shape[1]),
    )


def make_all_threshold_prediction_rows(X: Any, pi: ArrayLike = DEFAULT_PI) -> ThresholdReplication:
    """Replicate prediction rows and construct their known no-effect margins."""
    n = int(X.shape[0])
    dummy_arm = np.full(n, 1, dtype=int)
    return make_all_threshold_replication(X, dummy_arm, pi)


class IPWAllThresholdClassifier(BaseEstimator, ClassifierMixin):
    """Generic sklearn/RF cumulative learner targeting normalized demand.

    Each original buyer receives inverse-assignment-propensity weight.  In the
    resulting pseudo-population, the arm distribution is proportional to
    ``q_t(x)``.  The two cumulative probabilities therefore identify the risk
    ratios after reconstruction.  This is a useful Random-Forest benchmark,
    but the exact propensity-offset likelihood is preferable when supported.
    """

    def __init__(
        self,
        estimator: Any,
        *,
        threshold_weight: tuple[float, float] = (1.0, 1.0),
        project_probabilities: bool = True,
    ) -> None:
        self.estimator = estimator
        self.threshold_weight = threshold_weight
        self.project_probabilities = project_probabilities

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        pi: ArrayLike = DEFAULT_PI,
        sample_weight: ArrayLike | None = None,
    ) -> "IPWAllThresholdClassifier":
        t = as_arm_index(y)
        p = validate_propensities(pi, len(t))
        base = (
            np.ones(len(t), dtype=float)
            if sample_weight is None
            else np.asarray(sample_weight, dtype=float).reshape(-1)
        )
        if len(base) != len(t):
            raise ValueError("sample_weight must align")
        assigned = p[np.arange(len(t)), t]
        ipw = base / assigned
        ipw /= np.mean(ipw)
        rep = make_all_threshold_replication(
            X,
            t,
            p,
            sample_weight=ipw,
            threshold_weight=self.threshold_weight,
        )
        self.model_ = clone(self.estimator)
        _fit_with_sample_weight(self.model_, rep.X, rep.target.astype(int), rep.sample_weight)
        self.classes_ = np.array([0, 1])
        self.n_features_in_ = int(X.shape[1])
        return self

    def predict_cumulative(self, X: Any) -> FloatArray:
        if not hasattr(self, "model_"):
            raise RuntimeError("estimator is not fitted")
        rep = make_all_threshold_prediction_rows(X, DEFAULT_PI)
        proba = np.asarray(self.model_.predict_proba(rep.X), dtype=float)
        if proba.ndim != 2 or proba.shape[1] != 2:
            raise ValueError("base estimator must provide binary probabilities")
        f = proba[:, 1].reshape(len(X), 2)
        return project_cumulative_probabilities(f) if self.project_probabilities else f

    def predict_normalized_demand(self, X: Any) -> FloatArray:
        return posterior_from_cumulative(self.predict_cumulative(X), project=True)

    def predict_log_rr(self, X: Any) -> tuple[FloatArray, FloatArray]:
        s = self.predict_normalized_demand(X)
        h = np.log(np.clip(s[:, 0], 1e-12, None)) - np.log(
            np.clip(s[:, 1], 1e-12, None)
        )
        l = np.log(np.clip(s[:, 2], 1e-12, None)) - np.log(
            np.clip(s[:, 1], 1e-12, None)
        )
        return h, l

    def predict_buyer_posterior(self, X: Any, pi: ArrayLike = DEFAULT_PI) -> FloatArray:
        h, l = self.predict_log_rr(X)
        return buyer_posterior_from_log_rr(h, l, pi)


class XGBAllThresholdClassifier(BaseEstimator, ClassifierMixin):
    """XGBoost all-threshold model with logged propensity base margins."""

    def __init__(
        self,
        params: Mapping[str, Any] | None = None,
        *,
        num_boost_round: int = 3000,
        early_stopping_rounds: int = 100,
        threshold_weight: tuple[float, float] = (1.0, 1.0),
        monotone_threshold: bool = True,
        project_probabilities: bool = True,
        random_state: int = 2026,
    ) -> None:
        self.params = params
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds
        self.threshold_weight = threshold_weight
        self.monotone_threshold = monotone_threshold
        self.project_probabilities = project_probabilities
        self.random_state = random_state

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        pi: ArrayLike = DEFAULT_PI,
        sample_weight: ArrayLike | None = None,
        eval_set: tuple[Any, ArrayLike] | None = None,
        eval_pi: ArrayLike | None = None,
        eval_sample_weight: ArrayLike | None = None,
        verbose_eval: bool | int = False,
    ) -> "XGBAllThresholdClassifier":
        import xgboost as xgb

        t = as_arm_index(y)
        p = validate_propensities(pi, len(t))
        rep = make_all_threshold_replication(
            X,
            t,
            p,
            sample_weight=sample_weight,
            threshold_weight=self.threshold_weight,
        )
        dtrain = xgb.DMatrix(
            rep.X,
            label=rep.target,
            weight=rep.sample_weight,
            base_margin=rep.base_margin,
            enable_categorical=True,
        )
        evals = [(dtrain, "train")]
        if eval_set is not None:
            Xv, yv = eval_set
            tv = as_arm_index(yv)
            if eval_pi is None:
                if not np.allclose(p, p[[0]], atol=1e-12, rtol=1e-12):
                    raise ValueError("eval_pi is required when training propensities vary")
                pv = validate_propensities(p[0], len(tv))
            else:
                pv = validate_propensities(eval_pi, len(tv))
            rv = make_all_threshold_replication(
                Xv,
                tv,
                pv,
                sample_weight=eval_sample_weight,
                threshold_weight=self.threshold_weight,
            )
            dvalid = xgb.DMatrix(
                rv.X,
                label=rv.target,
                weight=rv.sample_weight,
                base_margin=rv.base_margin,
                enable_categorical=True,
            )
            evals.append((dvalid, "valid"))

        params: dict[str, Any] = {
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "tree_method": "hist",
            "eta": 0.03,
            "max_depth": 4,
            "min_child_weight": 20.0,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "reg_lambda": 10.0,
            "reg_alpha": 0.0,
            "seed": self.random_state,
            "nthread": 1,
        }
        if self.monotone_threshold:
            params["monotone_constraints"] = tuple(
                [0] * rep.original_feature_count + [1]
            )
        if self.params:
            params.update(dict(self.params))
        self.booster_ = xgb.train(
            params,
            dtrain,
            num_boost_round=self.num_boost_round,
            evals=evals,
            early_stopping_rounds=(
                self.early_stopping_rounds if eval_set is not None else None
            ),
            verbose_eval=verbose_eval,
        )
        self.best_iteration_ = getattr(
            self.booster_, "best_iteration", self.num_boost_round - 1
        )
        self.n_features_in_ = int(X.shape[1])
        self.classes_ = np.array([0, 1])
        return self

    def predict_cumulative(self, X: Any, *, pi: ArrayLike = DEFAULT_PI) -> FloatArray:
        import xgboost as xgb

        rep = make_all_threshold_prediction_rows(X, pi)
        d = xgb.DMatrix(
            rep.X,
            base_margin=rep.base_margin,
            enable_categorical=True,
        )
        pred = np.asarray(
            self.booster_.predict(
                d, iteration_range=(0, int(self.best_iteration_) + 1)
            ),
            dtype=float,
        ).reshape(len(X), 2)
        return (
            project_cumulative_probabilities(pred)
            if self.project_probabilities
            else pred
        )

    def predict_buyer_posterior(self, X: Any, *, pi: ArrayLike = DEFAULT_PI) -> FloatArray:
        return posterior_from_cumulative(self.predict_cumulative(X, pi=pi), project=True)

    def predict_log_rr(self, X: Any, *, pi: ArrayLike = DEFAULT_PI) -> tuple[FloatArray, FloatArray]:
        r = self.predict_buyer_posterior(X, pi=pi)
        rr = risk_ratios_from_buyer_posterior(r, pi)
        return np.log(rr[:, 0]), np.log(rr[:, 2])


class LGBAllThresholdClassifier(BaseEstimator, ClassifierMixin):
    """LightGBM all-threshold model with logged propensity initial scores.

    LightGBM does not include ``init_score`` automatically in ordinary model
    predictions.  This wrapper therefore predicts the learned residual raw
    margin and explicitly adds the row-level no-effect base margin.
    """

    def __init__(
        self,
        params: Mapping[str, Any] | None = None,
        *,
        num_boost_round: int = 3000,
        early_stopping_rounds: int = 100,
        threshold_weight: tuple[float, float] = (1.0, 1.0),
        monotone_threshold: bool = True,
        project_probabilities: bool = True,
        random_state: int = 2026,
    ) -> None:
        self.params = params
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds
        self.threshold_weight = threshold_weight
        self.monotone_threshold = monotone_threshold
        self.project_probabilities = project_probabilities
        self.random_state = random_state

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        pi: ArrayLike = DEFAULT_PI,
        sample_weight: ArrayLike | None = None,
        eval_set: tuple[Any, ArrayLike] | None = None,
        eval_pi: ArrayLike | None = None,
        eval_sample_weight: ArrayLike | None = None,
        categorical_feature: Any = "auto",
        verbose_eval: int = 0,
    ) -> "LGBAllThresholdClassifier":
        import lightgbm as lgb

        t = as_arm_index(y)
        p = validate_propensities(pi, len(t))
        rep = make_all_threshold_replication(
            X,
            t,
            p,
            sample_weight=sample_weight,
            threshold_weight=self.threshold_weight,
        )
        train = lgb.Dataset(
            rep.X,
            label=rep.target,
            weight=rep.sample_weight,
            init_score=rep.base_margin,
            categorical_feature=categorical_feature,
            free_raw_data=False,
        )
        valid_sets = [train]
        valid_names = ["train"]
        if eval_set is not None:
            Xv, yv = eval_set
            tv = as_arm_index(yv)
            if eval_pi is None:
                if not np.allclose(p, p[[0]], atol=1e-12, rtol=1e-12):
                    raise ValueError("eval_pi is required when training propensities vary")
                pv = validate_propensities(p[0], len(tv))
            else:
                pv = validate_propensities(eval_pi, len(tv))
            rv = make_all_threshold_replication(
                Xv,
                tv,
                pv,
                sample_weight=eval_sample_weight,
                threshold_weight=self.threshold_weight,
            )
            valid = lgb.Dataset(
                rv.X,
                label=rv.target,
                weight=rv.sample_weight,
                init_score=rv.base_margin,
                categorical_feature=categorical_feature,
                reference=train,
                free_raw_data=False,
            )
            valid_sets.append(valid)
            valid_names.append("valid")

        params: dict[str, Any] = {
            "objective": "binary",
            "metric": "binary_logloss",
            "boosting_type": "gbdt",
            "learning_rate": 0.03,
            "num_leaves": 15,
            "max_depth": 5,
            "min_data_in_leaf": 150,
            "min_sum_hessian_in_leaf": 5.0,
            "feature_fraction": 0.8,
            "bagging_fraction": 0.8,
            "bagging_freq": 1,
            "lambda_l1": 0.0,
            "lambda_l2": 10.0,
            "boost_from_average": False,
            "feature_pre_filter": False,
            "verbosity": -1,
            "seed": self.random_state,
            "num_threads": 1,
        }
        if self.monotone_threshold:
            params["monotone_constraints"] = [0] * rep.original_feature_count + [1]
            params.setdefault("monotone_constraints_method", "intermediate")
        if self.params:
            params.update(dict(self.params))
        callbacks = []
        if eval_set is not None:
            callbacks.append(lgb.early_stopping(self.early_stopping_rounds, verbose=False))
        if verbose_eval:
            callbacks.append(lgb.log_evaluation(verbose_eval))
        self.booster_ = lgb.train(
            params,
            train,
            num_boost_round=self.num_boost_round,
            valid_sets=valid_sets,
            valid_names=valid_names,
            callbacks=callbacks,
        )
        self.best_iteration_ = self.booster_.best_iteration or self.num_boost_round
        self.n_features_in_ = int(X.shape[1])
        self.classes_ = np.array([0, 1])
        return self

    def predict_cumulative(self, X: Any, *, pi: ArrayLike = DEFAULT_PI) -> FloatArray:
        rep = make_all_threshold_prediction_rows(X, pi)
        residual = np.asarray(
            self.booster_.predict(
                rep.X,
                raw_score=True,
                num_iteration=self.best_iteration_,
            ),
            dtype=float,
        )
        pred = expit(rep.base_margin + residual).reshape(len(X), 2)
        return (
            project_cumulative_probabilities(pred)
            if self.project_probabilities
            else pred
        )

    def predict_buyer_posterior(self, X: Any, *, pi: ArrayLike = DEFAULT_PI) -> FloatArray:
        return posterior_from_cumulative(self.predict_cumulative(X, pi=pi), project=True)

    def predict_log_rr(self, X: Any, *, pi: ArrayLike = DEFAULT_PI) -> tuple[FloatArray, FloatArray]:
        r = self.predict_buyer_posterior(X, pi=pi)
        rr = risk_ratios_from_buyer_posterior(r, pi)
        return np.log(rr[:, 0]), np.log(rr[:, 2])
