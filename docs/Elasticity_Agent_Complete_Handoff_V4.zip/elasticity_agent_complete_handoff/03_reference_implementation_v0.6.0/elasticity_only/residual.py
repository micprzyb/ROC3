"""Common elasticity plus contrast-specific residual models.

This module supports a practical tree architecture for sharing information
across all buyer arms without forcing the high and low responses to be equal:

1. fit an all-arm common scalar elasticity model;
2. generate strictly out-of-fold common log-risk-ratio predictions;
3. fit an H/C residual model around the common H/C margin;
4. fit an L/C residual model around the common L/C margin;
5. shrink the residuals and reconstruct one coherent buyer posterior.

The residual learners must never be trained on in-sample common-model
predictions.  Use :func:`crossfit_common_log_rr` or an equivalent nested
cross-fitting implementation in the host repository.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.special import expit
from sklearn.base import BaseEstimator, ClassifierMixin

from .core import (
    DEFAULT_PI,
    DEFAULT_Z,
    as_arm_index,
    buyer_posterior_from_log_rr,
    project_log_rr_sign,
    validate_doses,
    validate_propensities,
)
from .pairwise import pairwise_subset, row_subset

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


def _aligned_vector(x: ArrayLike, n: int, name: str) -> FloatArray:
    a = np.asarray(x, dtype=float).reshape(-1)
    if len(a) == 1 and n > 1:
        a = np.full(n, float(a[0]))
    if len(a) != n or np.any(~np.isfinite(a)):
        raise ValueError(f"{name} must be finite and align with rows")
    return a


def crossfit_common_log_rr(
    estimator_factory: Callable[[], Any],
    X: Any,
    arm: ArrayLike,
    pi: ArrayLike,
    z: ArrayLike,
    folds: Sequence[tuple[ArrayLike, ArrayLike]],
    *,
    sample_weight: ArrayLike | None = None,
) -> tuple[FloatArray, FloatArray, list[Any]]:
    """Generate leakage-free common-model log-risk-ratio predictions.

    ``estimator_factory`` must return a fresh estimator supporting
    ``fit(X, arm, pi=..., z=..., sample_weight=...)`` and
    ``predict_log_rr(X, z=...)``.  Every row must appear in exactly one
    validation fold.
    """
    t = as_arm_index(arm)
    n = len(t)
    p = validate_propensities(pi, n)
    zz = validate_doses(z, n)
    if not hasattr(X, "shape") or X.shape[0] != n:
        raise ValueError("X and arm must align")
    w = None if sample_weight is None else _aligned_vector(sample_weight, n, "sample_weight")
    out_h = np.full(n, np.nan, dtype=float)
    out_l = np.full(n, np.nan, dtype=float)
    seen = np.zeros(n, dtype=int)
    models: list[Any] = []

    for train_index, valid_index in folds:
        tr = np.asarray(train_index, dtype=int)
        va = np.asarray(valid_index, dtype=int)
        if np.intersect1d(tr, va).size:
            raise ValueError("train and validation indices overlap")
        if np.any(va < 0) or np.any(va >= n) or np.any(tr < 0) or np.any(tr >= n):
            raise ValueError("fold index out of range")
        model = estimator_factory()
        fit_kwargs: dict[str, Any] = {"pi": p[tr], "z": zz[tr]}
        if w is not None:
            fit_kwargs["sample_weight"] = w[tr]
        model.fit(row_subset(X, tr), t[tr], **fit_kwargs)
        h, l = model.predict_log_rr(row_subset(X, va), z=zz[va])
        out_h[va] = np.asarray(h, dtype=float)
        out_l[va] = np.asarray(l, dtype=float)
        seen[va] += 1
        models.append(model)

    if np.any(seen != 1) or np.any(~np.isfinite(out_h)) or np.any(~np.isfinite(out_l)):
        raise ValueError("folds must produce exactly one finite prediction per row")
    return out_h, out_l, models


class XGBOffsetResidualPairwiseClassifier(BaseEstimator, ClassifierMixin):
    """XGBoost pairwise residual learner around an external common margin."""

    def __init__(
        self,
        contrast_arm: int,
        params: Mapping[str, Any] | None = None,
        *,
        num_boost_round: int = 3000,
        early_stopping_rounds: int = 100,
        residual_shrinkage: float = 1.0,
        random_state: int = 2026,
    ) -> None:
        self.contrast_arm = contrast_arm
        self.params = params
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds
        self.residual_shrinkage = residual_shrinkage
        self.random_state = random_state

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        base_log_rr: ArrayLike,
        pi: ArrayLike = DEFAULT_PI,
        sample_weight: ArrayLike | None = None,
        eval_set: tuple[Any, ArrayLike] | None = None,
        eval_base_log_rr: ArrayLike | None = None,
        eval_pi: ArrayLike | None = None,
        eval_sample_weight: ArrayLike | None = None,
        verbose_eval: bool | int = False,
    ) -> "XGBOffsetResidualPairwiseClassifier":
        import xgboost as xgb

        if self.contrast_arm not in (0, 2):
            raise ValueError("contrast_arm must be 0 (H) or 2 (L)")
        if not 0.0 <= self.residual_shrinkage <= 1.0:
            raise ValueError("residual_shrinkage must be in [0,1]")
        t = as_arm_index(y)
        p = validate_propensities(pi, len(t))
        base = _aligned_vector(base_log_rr, len(t), "base_log_rr")
        mask, binary, _, propensity_offset = pairwise_subset(t, p, self.contrast_arm)
        w = (
            np.ones(len(t), dtype=float)
            if sample_weight is None
            else _aligned_vector(sample_weight, len(t), "sample_weight")
        )
        dtrain = xgb.DMatrix(
            row_subset(X, mask),
            label=binary.astype(float),
            weight=w[mask],
            base_margin=propensity_offset + base[mask],
            enable_categorical=True,
        )
        evals = [(dtrain, "train")]
        if eval_set is not None:
            if eval_base_log_rr is None:
                raise ValueError("eval_base_log_rr is required with eval_set")
            Xv, yv = eval_set
            tv = as_arm_index(yv)
            if eval_pi is None:
                if not np.allclose(p, p[[0]], atol=1e-12, rtol=1e-12):
                    raise ValueError("eval_pi is required when training propensities vary")
                pv = validate_propensities(p[0], len(tv))
            else:
                pv = validate_propensities(eval_pi, len(tv))
            bv = _aligned_vector(eval_base_log_rr, len(tv), "eval_base_log_rr")
            mv, ybv, _, ov = pairwise_subset(tv, pv, self.contrast_arm)
            wv = (
                np.ones(len(tv), dtype=float)
                if eval_sample_weight is None
                else _aligned_vector(eval_sample_weight, len(tv), "eval_sample_weight")
            )
            dvalid = xgb.DMatrix(
                row_subset(Xv, mv),
                label=ybv.astype(float),
                weight=wv[mv],
                base_margin=ov + bv[mv],
                enable_categorical=True,
            )
            evals.append((dvalid, "valid"))

        params: dict[str, Any] = {
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "tree_method": "hist",
            "eta": 0.02,
            "max_depth": 3,
            "min_child_weight": 30.0,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "gamma": 0.0,
            "reg_alpha": 0.0,
            "reg_lambda": 30.0,
            "seed": self.random_state,
            "nthread": 1,
        }
        if self.params:
            params.update(dict(self.params))
        self.booster_ = xgb.train(
            params,
            dtrain,
            num_boost_round=self.num_boost_round,
            evals=evals,
            early_stopping_rounds=(
                self.early_stopping_rounds if eval_set is not None else None
            ),
            verbose_eval=verbose_eval,
        )
        self.best_iteration_ = getattr(
            self.booster_, "best_iteration", self.num_boost_round - 1
        )
        self.classes_ = np.array([0, 1])
        return self

    def predict_residual(self, X: Any) -> FloatArray:
        import xgboost as xgb

        d = xgb.DMatrix(
            X,
            base_margin=np.zeros(len(X), dtype=float),
            enable_categorical=True,
        )
        return np.asarray(
            self.booster_.predict(
                d,
                output_margin=True,
                iteration_range=(0, int(self.best_iteration_) + 1),
            ),
            dtype=float,
        )

    def predict_log_rr(self, X: Any, *, base_log_rr: ArrayLike) -> FloatArray:
        base = _aligned_vector(base_log_rr, len(X), "base_log_rr")
        return base + self.residual_shrinkage * self.predict_residual(X)

    def predict_pair_probability(
        self,
        X: Any,
        *,
        base_log_rr: ArrayLike,
        pi_treatment: ArrayLike,
        pi_control: ArrayLike,
    ) -> FloatArray:
        log_rr = self.predict_log_rr(X, base_log_rr=base_log_rr)
        return expit(
            np.log(np.asarray(pi_treatment, dtype=float))
            - np.log(np.asarray(pi_control, dtype=float))
            + log_rr
        )


class LGBOffsetResidualPairwiseClassifier(BaseEstimator, ClassifierMixin):
    """LightGBM pairwise residual learner around an external common margin."""

    def __init__(
        self,
        contrast_arm: int,
        params: Mapping[str, Any] | None = None,
        *,
        num_boost_round: int = 3000,
        early_stopping_rounds: int = 100,
        residual_shrinkage: float = 1.0,
        random_state: int = 2026,
    ) -> None:
        self.contrast_arm = contrast_arm
        self.params = params
        self.num_boost_round = num_boost_round
        self.early_stopping_rounds = early_stopping_rounds
        self.residual_shrinkage = residual_shrinkage
        self.random_state = random_state

    def fit(
        self,
        X: Any,
        y: ArrayLike,
        *,
        base_log_rr: ArrayLike,
        pi: ArrayLike = DEFAULT_PI,
        sample_weight: ArrayLike | None = None,
        eval_set: tuple[Any, ArrayLike] | None = None,
        eval_base_log_rr: ArrayLike | None = None,
        eval_pi: ArrayLike | None = None,
        eval_sample_weight: ArrayLike | None = None,
        categorical_feature: Any = "auto",
        verbose_eval: int = 0,
    ) -> "LGBOffsetResidualPairwiseClassifier":
        import lightgbm as lgb

        if self.contrast_arm not in (0, 2):
            raise ValueError("contrast_arm must be 0 (H) or 2 (L)")
        if not 0.0 <= self.residual_shrinkage <= 1.0:
            raise ValueError("residual_shrinkage must be in [0,1]")
        t = as_arm_index(y)
        p = validate_propensities(pi, len(t))
        base = _aligned_vector(base_log_rr, len(t), "base_log_rr")
        mask, binary, _, propensity_offset = pairwise_subset(t, p, self.contrast_arm)
        w = (
            np.ones(len(t), dtype=float)
            if sample_weight is None
            else _aligned_vector(sample_weight, len(t), "sample_weight")
        )
        train = lgb.Dataset(
            row_subset(X, mask),
            label=binary.astype(float),
            weight=w[mask],
            init_score=propensity_offset + base[mask],
            categorical_feature=categorical_feature,
            free_raw_data=False,
        )
        valid_sets = [train]
        valid_names = ["train"]
        if eval_set is not None:
            if eval_base_log_rr is None:
                raise ValueError("eval_base_log_rr is required with eval_set")
            Xv, yv = eval_set
            tv = as_arm_index(yv)
            if eval_pi is None:
                if not np.allclose(p, p[[0]], atol=1e-12, rtol=1e-12):
                    raise ValueError("eval_pi is required when training propensities vary")
                pv = validate_propensities(p[0], len(tv))
            else:
                pv = validate_propensities(eval_pi, len(tv))
            bv = _aligned_vector(eval_base_log_rr, len(tv), "eval_base_log_rr")
            mv, ybv, _, ov = pairwise_subset(tv, pv, self.contrast_arm)
            wv = (
                np.ones(len(tv), dtype=float)
                if eval_sample_weight is None
                else _aligned_vector(eval_sample_weight, len(tv), "eval_sample_weight")
            )
            valid = lgb.Dataset(
                row_subset(Xv, mv),
                label=ybv.astype(float),
                weight=wv[mv],
                init_score=ov + bv[mv],
                categorical_feature=categorical_feature,
                reference=train,
                free_raw_data=False,
            )
            valid_sets.append(valid)
            valid_names.append("valid")

        params: dict[str, Any] = {
            "objective": "binary",
            "metric": "binary_logloss",
            "boosting_type": "gbdt",
            "learning_rate": 0.02,
            "num_leaves": 7,
            "max_depth": 3,
            "min_data_in_leaf": 250,
            "min_sum_hessian_in_leaf": 10.0,
            "feature_fraction": 0.8,
            "bagging_fraction": 0.8,
            "bagging_freq": 1,
            "lambda_l1": 0.0,
            "lambda_l2": 30.0,
            "min_gain_to_split": 0.0,
            "boost_from_average": False,
            "feature_pre_filter": False,
            "verbosity": -1,
            "seed": self.random_state,
            "num_threads": 1,
        }
        if self.params:
            params.update(dict(self.params))
        callbacks = []
        if eval_set is not None:
            callbacks.append(lgb.early_stopping(self.early_stopping_rounds, verbose=False))
        if verbose_eval:
            callbacks.append(lgb.log_evaluation(verbose_eval))
        self.booster_ = lgb.train(
            params,
            train,
            num_boost_round=self.num_boost_round,
            valid_sets=valid_sets,
            valid_names=valid_names,
            callbacks=callbacks,
        )
        self.best_iteration_ = self.booster_.best_iteration or self.num_boost_round
        self.classes_ = np.array([0, 1])
        return self

    def predict_residual(self, X: Any) -> FloatArray:
        return np.asarray(
            self.booster_.predict(
                X,
                raw_score=True,
                num_iteration=self.best_iteration_,
            ),
            dtype=float,
        )

    def predict_log_rr(self, X: Any, *, base_log_rr: ArrayLike) -> FloatArray:
        base = _aligned_vector(base_log_rr, len(X), "base_log_rr")
        return base + self.residual_shrinkage * self.predict_residual(X)

    def predict_pair_probability(
        self,
        X: Any,
        *,
        base_log_rr: ArrayLike,
        pi_treatment: ArrayLike,
        pi_control: ArrayLike,
    ) -> FloatArray:
        log_rr = self.predict_log_rr(X, base_log_rr=base_log_rr)
        return expit(
            np.log(np.asarray(pi_treatment, dtype=float))
            - np.log(np.asarray(pi_control, dtype=float))
            + log_rr
        )


@dataclass
class CommonResidualElasticityModel:
    """Prediction-time composition of a common model and two residual models."""

    common_model: Any
    high_residual_model: Any
    low_residual_model: Any
    enforce_monotonicity: bool = True

    def predict_log_rr(
        self,
        X: Any,
        *,
        z: ArrayLike = DEFAULT_Z,
    ) -> tuple[FloatArray, FloatArray]:
        base_h, base_l = self.common_model.predict_log_rr(X, z=z)
        h = self.high_residual_model.predict_log_rr(X, base_log_rr=base_h)
        l = self.low_residual_model.predict_log_rr(X, base_log_rr=base_l)
        return project_log_rr_sign(h, l) if self.enforce_monotonicity else (h, l)

    def predict_buyer_posterior(
        self,
        X: Any,
        *,
        pi: ArrayLike = DEFAULT_PI,
        z: ArrayLike = DEFAULT_Z,
    ) -> FloatArray:
        h, l = self.predict_log_rr(X, z=z)
        return buyer_posterior_from_log_rr(h, l, pi)
