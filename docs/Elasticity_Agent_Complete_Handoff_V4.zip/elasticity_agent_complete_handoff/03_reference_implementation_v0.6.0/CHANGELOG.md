# Changelog

## 0.6.0

Added the post-v0.5 shared-information research and preservation support:

- exact common-plus-deviation two-slope estimator;
- proper cumulative and hybrid buyer losses;
- all-threshold replication and RF/LightGBM/XGBoost wrappers;
- leakage-free common-model cross-fitting;
- external-common-margin residual LightGBM/XGBoost pairwise wrappers;
- prediction-time common-plus-residual composition;
- optional PyTorch shared-trunk model and losses;
- preservation, hashing, and prepared-table fingerprint helpers;
- runtime backend capability discovery;
- new Optuna spaces for sharing, ordinal emphasis, residual shrinkage, and all-threshold models;
- new examples and deterministic tests.

The statistical correction is explicit: L-arm observations should influence the H/C response only through an explicit sharing assumption or a proper ordered-probability score.  Arbitrary larger L weights in H-versus-rest classification are not a calibrated H/C elasticity estimator.

## 0.5.0

Added exact two-gap models, direct and dose-aware parameterizations, exact derivatives, global MLE, and asymmetry shrinkage.
