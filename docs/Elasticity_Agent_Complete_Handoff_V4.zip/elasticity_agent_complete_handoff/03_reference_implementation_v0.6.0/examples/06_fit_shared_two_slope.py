"""Fit the exact common-plus-deviation model on validated real buyer rows."""
from __future__ import annotations

from elasticity_only.shared import SklearnSharedTwoSlopeFlipRegressor


def fit_shared_model(X_buyers, arm_buyers, pi_buyers, z_buyers):
    """Return a fitted partial-pooling model.

    ``X_buyers`` must come from the existing fold-local preprocessing pipeline.
    The function deliberately performs no raw-data loading or feature creation.
    """
    model = SklearnSharedTwoSlopeFlipRegressor(
        common_l2=1.0,
        deviation_l2=30.0,
        asymmetry_l2=1.0,
        max_iter=3000,
    )
    model.fit(X_buyers, arm_buyers, pi=pi_buyers, z=z_buyers)
    return model
