"""Fit exact global and penalized linear two-gap models on real buyer rows.

This example expects the caller to supply already validated arrays.  It does
not generate substitute insurance data.
"""
from __future__ import annotations

from elasticity_only.two_gap import (
    SklearnTwoGapFlipRegressor,
    fit_global_two_gap,
)


def fit_models(X_buyers, arm_buyers, pi_buyers, z_buyers):
    global_fit = fit_global_two_gap(arm_buyers, pi_buyers)
    model = SklearnTwoGapFlipRegressor(
        l2=1.0,
        asymmetry_l2=10.0,
        parameterization="slope",
    )
    model.fit(
        X_buyers,
        arm_buyers,
        pi=pi_buyers,
        z=z_buyers,
    )
    return global_fit, model
