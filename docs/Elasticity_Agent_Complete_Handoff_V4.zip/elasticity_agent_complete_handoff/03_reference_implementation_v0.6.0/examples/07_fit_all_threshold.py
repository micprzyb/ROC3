"""Fit all-threshold challengers on validated real buyer rows."""
from __future__ import annotations

from sklearn.ensemble import RandomForestClassifier

from elasticity_only.ordinal import (
    IPWAllThresholdClassifier,
    LGBAllThresholdClassifier,
    XGBAllThresholdClassifier,
)


def build_models():
    """Construct unfitted reference models; tune them within nested folds."""
    rf = IPWAllThresholdClassifier(
        RandomForestClassifier(
            n_estimators=1000,
            max_depth=8,
            min_samples_leaf=200,
            max_features="sqrt",
            class_weight=None,
            random_state=2026,
            n_jobs=-1,
        )
    )
    lgb = LGBAllThresholdClassifier()
    xgb = XGBAllThresholdClassifier()
    return {"random_forest": rf, "lightgbm": lgb, "xgboost": xgb}
