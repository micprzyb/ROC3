"""Reference outline for leakage-free common-plus-residual boosting.

This file intentionally accepts prepared real arrays and existing fold
assignments.  It does not regenerate folds or load raw insurance data.
"""
from __future__ import annotations

from elasticity_only.residual import (
    LGBOffsetResidualPairwiseClassifier,
    crossfit_common_log_rr,
)
from elasticity_only.scalar import LGBScalarFlipRegressor


def make_common_model():
    return LGBScalarFlipRegressor(
        params={
            "learning_rate": 0.02,
            "max_depth": 3,
            "num_leaves": 7,
            "lambda_l2": 30.0,
        }
    )


def crossfit_common(X, arm, pi, z, folds):
    return crossfit_common_log_rr(make_common_model, X, arm, pi, z, folds)


def make_high_residual_model():
    return LGBOffsetResidualPairwiseClassifier(
        contrast_arm=0,
        residual_shrinkage=0.5,
        params={
            "learning_rate": 0.01,
            "max_depth": 2,
            "num_leaves": 4,
            "lambda_l2": 100.0,
        },
    )


def make_low_residual_model():
    return LGBOffsetResidualPairwiseClassifier(
        contrast_arm=2,
        residual_shrinkage=0.5,
        params={
            "learning_rate": 0.01,
            "max_depth": 2,
            "num_leaves": 4,
            "lambda_l2": 100.0,
        },
    )
