# Elasticity-only insurance modeling reference — version 0.6.0

This is a **real-data-only reference implementation** for learning relative
demand and price elasticity from a randomized three-arm motor-insurance quote
experiment.

It is intended to accompany the preservation-first LLM-agent prompt in the
handoff bundle.  It is not intended to be copied wholesale over an evolved
repository.  The agent must first map the host repository, preserve its current
real-data adaptation, and then port only missing capabilities through adapters
or versioned extensions.

The package contains no generated insurance dataset and no synthetic model
leaderboard.  Hand-constructed arrays appear only in deterministic software,
derivative, and API tests.

## 1. Statistical target

For price arm `t` in `H`, `C`, `L`, define

```text
q_t(x) = P(purchase | T=t, X=x)
pi_t(x) = P(T=t | X=x)                 # logged randomization propensity
r_t(x) = P(T=t | purchase, X=x)        # buyer-arm posterior
```

Bayes' rule gives

```text
r_t(x) proportional to pi_t(x) * q_t(x)
```

and therefore

```text
q_t(x) / q_C(x)
  = [r_t(x) / pi_t(x)] / [r_C(x) / pi_C(x)].
```

The buyer-arm outcome identifies the high/control and low/control risk ratios
without requiring a customer-level base-conversion model.

If `g_t(x)` is contribution conditional on purchase, the tested-arm decision is

```text
argmax_t g_t(x) * RR_tC(x),
```

because the positive factor `q_C(x)` is common to all tested arms.

## 2. What changed in version 0.6.0

Version 0.5.0 already contained global, scalar, pairwise, exact two-gap,
multiclass, calibration, policy, and Optuna utilities.  Version 0.6.0 adds the
models required by the latest shared-information research:

### Exact common-plus-deviation learning

`elasticity_only.shared.SklearnSharedTwoSlopeFlipRegressor` learns

```text
beta_H(x) = softplus(f_common(x) + f_H(x))
beta_L(x) = softplus(f_common(x) + f_L(x))
```

from the exact three-arm buyer categorical likelihood.  The common surface is
updated by all buyer arms.  Strong deviation regularization approaches a common
scalar response; weak regularization approaches an unrestricted two-slope
model.

### All-threshold cumulative models

`elasticity_only.ordinal` represents the ordered arm outcome through

```text
F1(x) = P(T=H | buyer, X=x)
F2(x) = P(T in {H,C} | buyer, X=x).
```

Every buyer contributes to both thresholds.  The module includes:

- cumulative targets and coherent probability reconstruction;
- categorical, cumulative, hybrid, and ranked-probability losses;
- analytic cumulative-loss gradients with respect to two gaps;
- replicated all-threshold training tables;
- inverse-propensity sklearn/Random-Forest implementation;
- propensity-base-margin LightGBM and XGBoost wrappers.

The cumulative score is a proper challenger or auxiliary score.  It does not
create information absent from the experiment and need not be more efficient
than the exact categorical likelihood.

### Common scalar model plus residual pairwise boosters

`elasticity_only.residual` implements a practical tree architecture:

1. fit one all-arm scalar/common model;
2. generate strictly out-of-fold common predictions;
3. fit strongly regularized H/C and L/C residual boosters around those margins;
4. shrink residual corrections;
5. reconstruct one coherent posterior.

The module includes `crossfit_common_log_rr`, XGBoost and LightGBM residual
wrappers, and `CommonResidualElasticityModel` for prediction-time composition.

### Optional neural shared trunk

`elasticity_only.torch_shared` supplies an optional PyTorch shared-trunk model
and exact categorical, cumulative, and hybrid losses.  PyTorch is not a core
dependency.

### Preservation utilities

`elasticity_only.preservation` contains conservative hashing, manifest, atomic
write, and prepared-table fingerprint helpers.  They are support tools, not a
replacement for the full preservation protocol in the agent prompt.

## 3. Why low-arm data do not automatically identify the high/control gap

Under an unrestricted two-gap model,

```text
u(x) = -log RR_HC(x)
v(x) =  log RR_LC(x),
```

and the buyer posterior is

```text
softmax(log(pi) + [-u, 0, v]).
```

The exact direct gradient on `u` is the same for a control buyer and a low-arm
buyer.  Conditional H/C likelihood retains the efficient information about `u`
when `v` is an unrestricted nuisance.  Therefore, an L observation should
influence H/C only through an explicit, testable sharing assumption or a proper
ordered-probability score.

Do **not** train `H versus rest` with a larger arbitrary weight on L and then
interpret the output as `RR_HC`.  The label-dependent weighting changes the
population target.

## 4. Installation and verification

Create an isolated environment and install from this directory:

```bash
python -m pip install -e .
pytest -q
```

This release was checked with Python 3.13, scikit-learn 1.8.0, LightGBM 4.6.0,
XGBoost 3.1.3, Optuna 4.8.0, and optional PyTorch 2.10.0.  Production work
should lock the versions validated in the host repository rather than blindly
replacing its environment.

## 5. Integration rule for an evolved repository

Do not copy this directory over the host repository.  Follow this order:

1. preserve the current repository, uncommitted changes, real-data adapter,
   folds, Optuna studies, models, predictions, and reports;
2. reproduce current baseline outputs;
3. create a capability map from host code to this package;
4. retain host implementations that are already equivalent or better;
5. add compatibility wrappers around host data and prediction schemas;
6. port missing modules under new names or feature flags;
7. run parity tests before any model comparison;
8. evaluate new models in shadow mode on the frozen real-data and fold versions.

The handoff bundle includes a detailed preservation-first prompt and migration
templates.

## 6. Main modules

- `core.py`: exact Bayes identities, risk ratios, elasticity conventions,
  monotonicity, and contribution decisions.
- `scalar.py`: global and heterogeneous common-elasticity models, custom
  LightGBM/XGBoost objectives, and Random-Forest moment inversion.
- `two_gap.py`: exact two-gap likelihood, derivatives, global MLE, and a
  penalized two-slope estimator.
- `shared.py`: exact common-plus-deviation partial pooling.
- `pairwise.py`: H/C and L/C propensity-offset and inverse-propensity models.
- `ordinal.py`: all-threshold and hybrid-loss utilities and wrappers.
- `residual.py`: cross-fitted common model plus residual pairwise boosters.
- `multiclass.py`: inverse-propensity multiclass benchmark.
- `calibration.py`: propensity-aware calibration and heterogeneity shrinkage.
- `metrics.py`: proper buyer losses, grouped calibration, information gain,
  and clustered comparisons.
- `policy.py`: IPS/SNIPS pricing-policy evaluation.
- `optuna_spaces.py`: model-specific and sharing-specific search spaces.
- `schema.py`, `audit.py`, `splits.py`: real-data validation and leakage control.
- `preservation.py`: non-destructive manifest and fingerprint helpers.
- `capabilities.py`: read-only backend version discovery.

## 7. New model examples

The `examples/` directory contains functions that accept already validated,
prepared real arrays.  They deliberately do not regenerate folds or reload raw
data independently.

- `05_fit_two_gap.py`
- `06_fit_shared_two_slope.py`
- `07_fit_all_threshold.py`
- `08_common_residual_workflow.py`

The common-residual workflow must use inner out-of-fold common predictions for
residual training.  A common model trained on a row must not generate the base
margin used to train the residual model on that same row.

## 8. Model-selection hierarchy

Use identical customer-disjoint outer folds and a final untouched chronological
holdout.  Compare all candidate predictions after conversion to the common
schema

```text
quote_id, log_rr_HC, log_rr_LC
```

and then reconstruct one three-class buyer posterior.

Primary evidence:

1. held-out H/C conditional negative log-likelihood;
2. held-out L/C conditional negative log-likelihood;
3. joint three-arm buyer negative log-likelihood;
4. side-specific and grouped randomized risk-ratio calibration;
5. stability across groups, seeds, and forward time;
6. randomized contribution-policy value with clustered uncertainty.

To test whether L data help the H response, compare the same sharing
architecture with and without L in the common component.  Do not infer transfer
from gradient magnitude alone.

## 9. Optuna priorities

Besides ordinary tree complexity, tune the assumptions that govern information
sharing:

```text
deviation_l2          # common versus side-specific surfaces
asymmetry_l2          # shrink beta_H toward beta_L
ordinal_weight        # categorical versus cumulative auxiliary score
threshold_weight      # relative cumulative-threshold emphasis
residual_shrinkage    # common prediction versus side residual correction
```

These parameters can matter more than small changes in depth or learning rate.
Every model family and contrast should have its own persistent study.  Do not
reuse an old study name after changing the objective or data/fold semantics.

## 10. Non-negotiable safeguards

- Use logged row-level propensities.
- Use only pre-treatment features for the primary causal analysis.
- Keep all quotes for experiment audit and policy evaluation, even when the
  elasticity likelihood is buyer-only.
- Keep a customer or household in one fold.
- Preserve existing valid fold assignments for like-for-like comparisons.
- Do not balance buyer classes unless the induced prior shift is corrected.
- Do not optimize AUC, VUS, accuracy, or in-sample policy value as the primary
  elasticity objective.
- Do not report individual elasticity RMSE on real data.
- Do not overwrite old studies, models, predictions, caches, or reports.
- Keep the global scalar model as an anchor and reject personalization when it
  fails to improve held-out evidence.

## 11. Evidential boundary

The 51 included tests verify formulas, gradients, APIs, offsets, serialization
assumptions, and non-destructive helpers.  They do not establish which model is
best for a real insurance portfolio.  That conclusion requires the preserved
real randomized experiment.
