# QA report — elasticity-only reference implementation v0.6.0

## Scope

This report covers the reference implementation shipped in the preservation-first agent handoff bundle.  It verifies software behavior only.  It does not validate a model on an insurance portfolio.

## Environment

- Python: 3.13.5
- NumPy: 2.3.5
- pandas: 2.2.3
- SciPy: 1.17.0
- scikit-learn: 1.8.0
- LightGBM: 4.6.0
- XGBoost: 3.1.3
- Optuna: 4.8.0
- optional PyTorch: 2.10.0+cpu

## Checks performed

```text
python -m compileall -q elasticity_only examples tests
pytest -q
pytest -q --cov=elasticity_only --cov-report=term-missing
```

## Result

- 51 tests passed.
- 0 tests failed.
- Statement coverage: 75% across the full package.
- New shared, ordinal, residual, and preservation modules have direct deterministic tests.
- Native LightGBM and XGBoost smoke tests passed for:
  - all-threshold cumulative wrappers;
  - external-common-margin residual pairwise wrappers.
- Analytic gradients were checked against finite differences for:
  - exact two-gap loss in the prior package;
  - cumulative two-gap loss;
  - common-plus-deviation raw surfaces.
- Non-destructive atomic-write behavior and fingerprints were tested.

## Warnings

Optuna emitted its documented experimental-interface warnings for multivariate and grouped TPE.  The prompt requires isolating those settings so ordinary TPE can replace them if package compatibility changes.

## Deliberate limitations

- No real insurance rows are included.
- No generated insurance dataset or synthetic model leaderboard is included.
- PyTorch is optional; the neural reference module was compiled and imported in the verified environment but is not included in core coverage because it is not a required dependency.
- XGBoost vector-leaf multi-output support is capability-detected only and is not treated as a production-ready default.
- The package is a reference and migration aid.  The host repository remains the source of truth for real-data adaptation, folds, prior studies, and production interfaces.
