# QA and reproducibility report

## Release scope

This release rewrites the elasticity-only insurance tutorial around the exact three-arm model hierarchy: scalar common-slope, exact two-gap, and pairwise composite formulations. It includes a real-data-only Python reference implementation. It contains no generated insurance dataset and no synthetic model leaderboard.

## Document verification

- Final DOCX: `Elasticity_Only_Insurance_Tutorial_Two_Gap_Revised.docx`.
- Final PDF: `Elasticity_Only_Insurance_Tutorial_Two_Gap_Revised.pdf`.
- Page count: 57.
- Page format: A4.
- PDF: tagged, unencrypted, 238 outline items, embedded fonts.
- The DOCX was rendered to 57 PNG pages and every page was visually inspected.
- Two layout defects found during the review were corrected: overlap in the Bayes-flip diagram and a broken ceiling-function glyph in the leaf-size formula.
- A final accessibility edit replaced raw URL display text with descriptive link text. Pixel comparison showed that pages 1-56 were unchanged; page 57 was re-inspected.
- The final DOCX accessibility audit reported 0 high-, 0 medium-, and 0 low-severity findings.
- The final PDF was independently rendered at 171 DPI. All 57 PDF renderings were pixel-identical to the final DOCX-emitted page renderings.
- PDF preflight confirmed that the file opens, is not encrypted, is not scan-only, and contains no XFA form.

## Software verification

- Package version: 0.5.0.
- Python compilation completed for `elasticity_only/`, `examples/`, and `tests/`.
- `pytest -q`: 34 passed, 0 failed.
- The only warnings are current Optuna notices that `TPESampler(multivariate=True, group=True)` is an experimental interface.
- Statement coverage: 75% across 1,872 executable package statements.
- The two-gap module has 82% statement coverage.
- Native LightGBM and XGBoost smoke tests are included.
- The package imports successfully after editable installation with local build isolation disabled in the offline QA environment.
- The compact tutorial code examples compile and import successfully.

## New two-gap checks

The test suite verifies:

1. buyer-posterior normalization;
2. monotone risk-ratio reconstruction;
3. exact direct-gap row losses;
4. analytic gap gradients against numerical derivatives;
5. the full `2 x 2` Hessian and positive-semidefinite Fisher curvature;
6. raw-score derivatives after softplus links;
7. global two-gap maximum-likelihood fitting;
8. the scikit-learn-compatible heterogeneous estimator;
9. direct-gap and dose-aware side-slope predictions;
10. scalar-shrinkage and monotonicity behavior;
11. relevant Optuna search-space generation.

## Evidence boundary

The checks establish mathematical and software consistency. They do not establish:

- that heterogeneous elasticity exists in a particular portfolio;
- that a two-gap model outperforms a scalar model on real customers;
- that high/low asymmetry represents individual continuous curvature;
- that LightGBM, XGBoost, Random Forest, or a linear model is the production winner;
- that a personalized pricing policy has positive real contribution lift.

Those questions require the insurer's real randomized quote-level experiment, customer-disjoint nested validation, a final chronological holdout, grouped randomized effect calibration, and policy-value uncertainty.

## Production-hardening limitations

The code is a research reference implementation, not a managed production service. Before deployment, add organization-specific dependency locking, security review, data-access controls, feature governance, model-registry integration, distributed and failure-path testing, protected-class review, audit logging, monitoring, and change-control procedures.
