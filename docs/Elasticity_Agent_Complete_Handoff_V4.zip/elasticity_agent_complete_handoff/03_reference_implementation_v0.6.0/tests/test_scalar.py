import numpy as np
from elasticity_only.core import DEFAULT_PI,DEFAULT_Z
from elasticity_only.scalar import RandomForestMomentElasticity,fit_global_scalar_beta,scalar_flip_nll_rows,scalar_raw_grad_hess

def test_gradient():
    arm=np.array([0,1,2,1,0]); pi=np.tile(DEFAULT_PI,(len(arm),1)); z=np.tile(DEFAULT_Z,(len(arm),1)); raw=np.array([.1,-.4,.7,0,.3]); grad,_=scalar_raw_grad_hess(raw,arm,pi,z); eps=1e-6; num=[]
    for i in range(len(raw)):
        plus=raw.copy(); minus=raw.copy(); plus[i]+=eps; minus[i]-=eps; bp=np.log1p(np.exp(plus)); bm=np.log1p(np.exp(minus)); num.append((scalar_flip_nll_rows(bp,arm,pi,z)[i]-scalar_flip_nll_rows(bm,arm,pi,z)[i])/(2*eps))
    np.testing.assert_allclose(grad,num,rtol=1e-5,atol=1e-6)
def test_global_positive(): assert fit_global_scalar_beta(np.array([2]*40+[1]*50+[0]*10)).beta>0
def test_rf_moment_center_invariant():
    m=RandomForestMomentElasticity(beta_max=20); beta=np.array([0.,2.,8.]); z=np.tile(DEFAULT_Z+2.5,(3,1)); means=m._mean_dose(beta,z); assert np.all(np.diff(means)<0); np.testing.assert_allclose(means,m._mean_dose(beta,np.tile(DEFAULT_Z,(3,1))))


def test_sklearn_scalar_intercept_matches_global():
    from elasticity_only.scalar import SklearnScalarFlipRegressor

    arm = np.array([0] * 8 + [1] * 80 + [2] * 16, dtype=int)
    X = np.zeros((len(arm), 1), dtype=float)
    global_fit = fit_global_scalar_beta(arm)
    model = SklearnScalarFlipRegressor(l2=1.0, max_iter=2000, tol=1e-10)
    model.fit(X, arm)
    predicted = model.predict(np.zeros((3, 1), dtype=float))
    np.testing.assert_allclose(predicted, global_fit.beta, rtol=2e-4, atol=2e-4)
    assert model.converged_


def test_sklearn_scalar_learns_directional_heterogeneity():
    from elasticity_only.scalar import SklearnScalarFlipRegressor

    # Group -1 has relatively more high-arm buyers; group +1 has more
    # low-arm buyers. The buyer likelihood should assign greater sensitivity
    # to the second group without using any elasticity labels.
    x_low = np.full((100, 1), -1.0)
    arm_low = np.array([0] * 14 + [1] * 80 + [2] * 6, dtype=int)
    x_high = np.full((100, 1), 1.0)
    arm_high = np.array([0] * 4 + [1] * 80 + [2] * 16, dtype=int)
    X = np.vstack([x_low, x_high])
    arm = np.concatenate([arm_low, arm_high])

    model = SklearnScalarFlipRegressor(l2=0.01, max_iter=3000, tol=1e-10)
    model.fit(X, arm)
    beta = model.predict(np.array([[-1.0], [1.0]]))
    assert beta[1] > beta[0]
    assert np.all(beta >= 0)
