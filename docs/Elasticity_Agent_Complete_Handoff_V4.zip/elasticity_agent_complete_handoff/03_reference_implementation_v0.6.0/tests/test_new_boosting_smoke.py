import importlib.util

import numpy as np
import pytest
from numpy.testing import assert_allclose

from elasticity_only.core import DEFAULT_PI
from elasticity_only.ordinal import LGBAllThresholdClassifier, XGBAllThresholdClassifier
from elasticity_only.residual import (
    LGBOffsetResidualPairwiseClassifier,
    XGBOffsetResidualPairwiseClassifier,
)


@pytest.mark.parametrize(
    "backend,cls",
    [
        ("xgboost", XGBAllThresholdClassifier),
        ("lightgbm", LGBAllThresholdClassifier),
    ],
)
def test_all_threshold_booster_smoke(backend, cls):
    if importlib.util.find_spec(backend) is None:
        pytest.skip(f"{backend} is not installed")
    rng = np.random.default_rng(12)
    X = rng.normal(size=(72, 3))
    arm = np.tile(np.array([0, 1, 2]), 24)
    model = cls(num_boost_round=8, early_stopping_rounds=3)
    model.fit(
        X[:54],
        arm[:54],
        pi=DEFAULT_PI,
        eval_set=(X[54:], arm[54:]),
        eval_pi=DEFAULT_PI,
    )
    posterior = model.predict_buyer_posterior(X[:6], pi=DEFAULT_PI)
    assert posterior.shape == (6, 3)
    assert_allclose(posterior.sum(axis=1), 1.0, atol=1e-8)


@pytest.mark.parametrize(
    "backend,cls",
    [
        ("xgboost", XGBOffsetResidualPairwiseClassifier),
        ("lightgbm", LGBOffsetResidualPairwiseClassifier),
    ],
)
def test_residual_booster_smoke(backend, cls):
    if importlib.util.find_spec(backend) is None:
        pytest.skip(f"{backend} is not installed")
    rng = np.random.default_rng(13)
    X = rng.normal(size=(90, 3))
    arm = np.tile(np.array([0, 1, 2]), 30)
    base = np.full(90, -0.1)
    model = cls(
        0,
        num_boost_round=8,
        early_stopping_rounds=3,
        residual_shrinkage=0.5,
    )
    model.fit(
        X[:66],
        arm[:66],
        base_log_rr=base[:66],
        pi=DEFAULT_PI,
        eval_set=(X[66:], arm[66:]),
        eval_base_log_rr=base[66:],
        eval_pi=DEFAULT_PI,
    )
    pred = model.predict_log_rr(X[:5], base_log_rr=base[:5])
    assert pred.shape == (5,)
    assert np.all(np.isfinite(pred))
