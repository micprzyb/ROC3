import numpy as np
from numpy.testing import assert_allclose

from elasticity_only.core import DEFAULT_PI, DEFAULT_Z
from elasticity_only.shared import (
    SklearnSharedTwoSlopeFlipRegressor,
    shared_two_slope_posterior,
    shared_two_slope_raw_loss_gradient,
)


def test_shared_posterior_is_monotone_and_normalized():
    bh = np.array([0.0, 1.0, 3.0])
    bl = np.array([0.0, 2.0, 4.0])
    r = shared_two_slope_posterior(bh, bl, DEFAULT_PI, DEFAULT_Z)
    assert_allclose(r.sum(axis=1), 1.0)
    assert np.all(r > 0.0)


def test_shared_raw_gradient_matches_finite_difference():
    arm = np.array([0, 1, 2, 1])
    fc = np.array([0.2, -0.3, 0.1, 0.4])
    fh = np.array([-0.1, 0.2, 0.3, -0.2])
    fl = np.array([0.4, -0.1, 0.2, 0.0])
    loss, grad = shared_two_slope_raw_loss_gradient(fc, fh, fl, arm)
    eps = 1e-6
    arrays = [fc, fh, fl]
    numerical = np.empty_like(grad)
    for j in range(3):
        plus = [a.copy() for a in arrays]
        minus = [a.copy() for a in arrays]
        plus[j] += eps
        minus[j] -= eps
        lp, _ = shared_two_slope_raw_loss_gradient(*plus, arm)
        lm, _ = shared_two_slope_raw_loss_gradient(*minus, arm)
        numerical[:, j] = (lp - lm) / (2 * eps)
    assert_allclose(grad, numerical, rtol=2e-5, atol=2e-6)


def test_sklearn_shared_model_fits_and_predicts():
    # Small hand-constructed arm table used only for implementation testing.
    rng = np.random.default_rng(4)
    X = rng.normal(size=(90, 3))
    arm = np.tile(np.array([0, 1, 2]), 30)
    model = SklearnSharedTwoSlopeFlipRegressor(
        common_l2=2.0,
        deviation_l2=20.0,
        asymmetry_l2=1.0,
        max_iter=300,
    )
    model.fit(X, arm, pi=DEFAULT_PI, z=DEFAULT_Z)
    h, l = model.predict_log_rr(X[:8])
    beta = model.predict_side_elasticities(X[:8])
    posterior = model.predict_buyer_posterior(X[:8])
    assert h.shape == (8,)
    assert l.shape == (8,)
    assert np.all(h <= 1e-12)
    assert np.all(l >= -1e-12)
    assert np.all(beta >= 0.0)
    assert_allclose(posterior.sum(axis=1), 1.0, atol=1e-10)
