import numpy as np
from elasticity_only.core import (
    DEFAULT_PI, buyer_posterior_from_log_rr, choose_price_from_relative_demand,
    log_change_elasticity_from_rr, log_rr_from_scalar_beta,
    midpoint_arc_elasticity_from_rr, relative_linear_buyer_posterior,
    relative_linear_risk_ratios, risk_ratios_from_buyer_posterior,
    rr_from_log_change_elasticity, rr_from_standard_relative_elasticity,
    scalar_buyer_posterior, standard_relative_elasticity_from_rr,
)

def test_bayes_flip_round_trip():
    h=np.array([-.3,-.1]); l=np.array([.4,.2]); post=buyer_posterior_from_log_rr(h,l,DEFAULT_PI); rr=risk_ratios_from_buyer_posterior(post,DEFAULT_PI)
    np.testing.assert_allclose(rr[:,0],np.exp(h)); np.testing.assert_allclose(rr[:,1],1); np.testing.assert_allclose(rr[:,2],np.exp(l))
def test_scalar_agreement():
    b=np.array([1.,3.,6.]); h,l=log_rr_from_scalar_beta(b); np.testing.assert_allclose(scalar_buyer_posterior(b),buyer_posterior_from_log_rr(h,l))
def test_policy_cancels_scale():
    rr=np.array([[.9,1,1.1],[.6,1,1.5]]); m=np.array([[120,100,80],[120,100,80]],float); d=choose_price_from_relative_demand(rr,m); np.testing.assert_array_equal(d.chosen_arm,[0,2])


def test_elasticity_convention_round_trips():
    signed_log_elasticity = -3.0
    for price_ratio in (1.10, 0.90):
        rr = rr_from_log_change_elasticity(signed_log_elasticity, price_ratio)
        np.testing.assert_allclose(
            log_change_elasticity_from_rr(rr, price_ratio), signed_log_elasticity
        )
        standard = standard_relative_elasticity_from_rr(rr, price_ratio)
        np.testing.assert_allclose(
            rr_from_standard_relative_elasticity(standard, price_ratio), rr
        )

def test_midpoint_arc_is_direction_symmetric():
    rr = 0.75
    price_ratio = 1.10
    forward = midpoint_arc_elasticity_from_rr(rr, price_ratio)
    reverse = midpoint_arc_elasticity_from_rr(1.0 / rr, 1.0 / price_ratio)
    np.testing.assert_allclose(forward, reverse)

def test_standard_and_log_conventions_differ_for_finite_change():
    rr_high = 1.10 ** -3.0
    rr_low = 0.90 ** -3.0
    e_high = standard_relative_elasticity_from_rr(rr_high, 1.10)
    e_low = standard_relative_elasticity_from_rr(rr_low, 0.90)
    assert not np.isclose(e_high, -3.0)
    assert not np.isclose(e_low, -3.0)
    assert not np.isclose(e_high, e_low)


def test_relative_linear_scalar_model_has_constant_standard_magnitude():
    beta = np.array([2.0, 4.0])
    rr = relative_linear_risk_ratios(beta)
    np.testing.assert_allclose(rr[:, 0], 1.0 - 0.10 * beta)
    np.testing.assert_allclose(rr[:, 1], 1.0)
    np.testing.assert_allclose(rr[:, 2], 1.0 + 0.10 * beta)
    np.testing.assert_allclose(
        -standard_relative_elasticity_from_rr(rr[:, 0], 1.10), beta
    )
    np.testing.assert_allclose(
        -standard_relative_elasticity_from_rr(rr[:, 2], 0.90), beta
    )
    posterior = relative_linear_buyer_posterior(beta)
    np.testing.assert_allclose(posterior.sum(axis=1), 1.0)

def test_relative_linear_scalar_model_rejects_nonpositive_risk():
    with np.testing.assert_raises(ValueError):
        relative_linear_risk_ratios(np.array([10.0]))
