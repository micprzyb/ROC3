from pathlib import Path

import pandas as pd
import pytest

from elasticity_only.preservation import (
    atomic_write_new,
    dataframe_fingerprint,
    inventory_tree,
    sha256_file,
)


def test_atomic_write_refuses_overwrite(tmp_path: Path):
    target = tmp_path / "record.txt"
    atomic_write_new(target, "first\n")
    assert target.read_text() == "first\n"
    with pytest.raises(FileExistsError):
        atomic_write_new(target, "second\n")


def test_inventory_and_dataframe_fingerprint(tmp_path: Path):
    (tmp_path / "a.txt").write_text("abc")
    records = inventory_tree(tmp_path)
    assert len(records) == 1
    assert records[0].sha256 == sha256_file(tmp_path / "a.txt")

    frame = pd.DataFrame({"quote_id": [1, 2], "arm": ["H", "C"]})
    fp = dataframe_fingerprint(frame, key_columns=["quote_id"], include_value_hash=True)
    assert fp["rows"] == 2
    assert fp["key_unique_counts"]["quote_id"] == 2
    assert "value_hash_sha256" in fp
