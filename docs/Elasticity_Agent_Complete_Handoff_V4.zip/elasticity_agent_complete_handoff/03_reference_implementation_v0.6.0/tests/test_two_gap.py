from __future__ import annotations

import numpy as np
from numpy.testing import assert_allclose
from scipy.optimize._numdiff import approx_derivative

from elasticity_only.two_gap import (
    SklearnTwoGapFlipRegressor,
    fit_global_two_gap,
    two_gap_buyer_posterior,
    two_gap_gap_grad_hessian,
    two_gap_nll_rows,
    two_gap_raw_grad_hessian,
)


def _hand_problem():
    arm = np.array([0, 1, 2, 1, 2, 0, 1, 1, 2], dtype=int)
    pi = np.tile(np.array([0.1, 0.8, 0.1]), (len(arm), 1))
    return arm, pi


def test_two_gap_posterior_constraints_and_ratios():
    pi = np.array([0.1, 0.8, 0.1])
    u = np.array([0.2, 0.0])
    v = np.array([0.3, 0.0])
    r = two_gap_buyer_posterior(u, v, pi)
    assert_allclose(r.sum(axis=1), 1.0)
    density = r / pi
    rr_h = density[:, 0] / density[:, 1]
    rr_l = density[:, 2] / density[:, 1]
    assert_allclose(rr_h, np.exp(-u))
    assert_allclose(rr_l, np.exp(v))
    assert np.all(rr_h <= 1.0 + 1e-12)
    assert np.all(rr_l >= 1.0 - 1e-12)


def test_direct_gap_gradient_and_hessian_match_finite_differences():
    arm, pi = _hand_problem()
    u = np.linspace(0.05, 0.4, len(arm))
    v = np.linspace(0.15, 0.55, len(arm))
    grad, hess = two_gap_gap_grad_hessian(u, v, arm, pi)

    for i in range(len(arm)):
        def f(theta):
            return two_gap_nll_rows(
                np.array([theta[0]]),
                np.array([theta[1]]),
                np.array([arm[i]]),
                pi[i],
            )[0]

        g_num = approx_derivative(lambda x: np.array([f(x)]), np.array([u[i], v[i]])).reshape(-1)
        h_num = approx_derivative(
            lambda x: two_gap_gap_grad_hessian(
                np.array([x[0]]), np.array([x[1]]), np.array([arm[i]]), pi[i]
            )[0].reshape(-1),
            np.array([u[i], v[i]]),
        )
        assert_allclose(grad[i], g_num, atol=2e-6, rtol=2e-6)
        assert_allclose(hess[i], h_num, atol=2e-6, rtol=2e-6)
        assert np.linalg.eigvalsh(hess[i]).min() >= -1e-12


def test_raw_gradient_matches_finite_difference_and_fisher_is_psd():
    arm, pi = _hand_problem()
    fh = np.linspace(-1.0, 0.7, len(arm))
    fl = np.linspace(-0.6, 1.1, len(arm))
    grad, fisher = two_gap_raw_grad_hessian(fh, fl, arm, pi, hessian="fisher")

    for i in range(len(arm)):
        def f(theta):
            u = np.logaddexp(0.0, theta[0])
            v = np.logaddexp(0.0, theta[1])
            return two_gap_nll_rows([u], [v], [arm[i]], pi[i])[0]

        g_num = approx_derivative(lambda x: np.array([f(x)]), np.array([fh[i], fl[i]])).reshape(-1)
        assert_allclose(grad[i], g_num, atol=2e-6, rtol=2e-6)
        assert np.linalg.eigvalsh(fisher[i]).min() >= -1e-12


def test_global_two_gap_moves_in_expected_direction():
    # More low-arm buyers and fewer high-arm buyers than the 10/80/10 prior.
    arm = np.array([0] * 5 + [1] * 80 + [2] * 15, dtype=int)
    fit = fit_global_two_gap(arm)
    assert fit.converged
    assert fit.gap_high > 0.0
    assert fit.gap_low > 0.0
    assert fit.log_rr_high < 0.0
    assert fit.log_rr_low > 0.0


def test_sklearn_two_gap_estimator_smoke():
    arm, pi = _hand_problem()
    X = np.column_stack(
        [
            np.linspace(-1.0, 1.0, len(arm)),
            np.array([0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=float),
        ]
    )
    model = SklearnTwoGapFlipRegressor(
        l2=10.0,
        asymmetry_l2=5.0,
        parameterization="slope",
        max_iter=500,
    ).fit(X, arm, pi=pi)
    gaps = model.predict_gaps(X)
    post = model.predict_buyer_posterior(X, pi=pi)
    assert gaps.shape == (len(arm), 2)
    assert np.all(gaps >= 0.0)
    assert_allclose(post.sum(axis=1), 1.0)
    assert model.predict(X).shape == (len(arm), 2)
