import numpy as np
from numpy.testing import assert_allclose

from elasticity_only.core import DEFAULT_PI, DEFAULT_Z
from elasticity_only.residual import CommonResidualElasticityModel, crossfit_common_log_rr
from elasticity_only.scalar import SklearnScalarFlipRegressor


class ZeroResidual:
    def predict_log_rr(self, X, *, base_log_rr):
        return np.asarray(base_log_rr, dtype=float)


def test_crossfit_common_log_rr_covers_every_row_once():
    rng = np.random.default_rng(11)
    X = rng.normal(size=(60, 2))
    arm = np.tile(np.array([0, 1, 2]), 20)
    folds = []
    for k in range(3):
        va = np.arange(k, 60, 3)
        tr = np.setdiff1d(np.arange(60), va)
        folds.append((tr, va))

    h, l, models = crossfit_common_log_rr(
        lambda: SklearnScalarFlipRegressor(l2=10.0, max_iter=300),
        X,
        arm,
        np.broadcast_to(DEFAULT_PI, (60, 3)),
        np.broadcast_to(DEFAULT_Z, (60, 3)),
        folds,
    )
    assert h.shape == (60,)
    assert l.shape == (60,)
    assert np.all(np.isfinite(h))
    assert np.all(np.isfinite(l))
    assert len(models) == 3


def test_common_residual_zero_residual_matches_common_model():
    rng = np.random.default_rng(3)
    X = rng.normal(size=(45, 2))
    arm = np.tile(np.array([0, 1, 2]), 15)
    common = SklearnScalarFlipRegressor(l2=5.0, max_iter=300).fit(X, arm)
    combined = CommonResidualElasticityModel(common, ZeroResidual(), ZeroResidual())
    ch, cl = common.predict_log_rr(X[:7])
    h, l = combined.predict_log_rr(X[:7])
    assert_allclose(h, ch)
    assert_allclose(l, cl)
