import numpy as np
from numpy.testing import assert_allclose
from sklearn.ensemble import RandomForestClassifier

from elasticity_only.core import DEFAULT_PI
from elasticity_only.ordinal import (
    IPWAllThresholdClassifier,
    categorical_log_loss_rows,
    cumulative_from_posterior,
    cumulative_log_loss_rows,
    cumulative_targets,
    cumulative_two_gap_gradient,
    hybrid_log_loss_rows,
    make_all_threshold_replication,
    posterior_from_cumulative,
    project_cumulative_probabilities,
)
from elasticity_only.two_gap import two_gap_buyer_posterior


def test_cumulative_targets_and_roundtrip():
    arm = np.array([0, 1, 2])
    expected = np.array([[1.0, 1.0], [0.0, 1.0], [0.0, 0.0]])
    assert_allclose(cumulative_targets(arm), expected)
    posterior = np.array([[0.1, 0.8, 0.1], [0.05, 0.75, 0.2]])
    assert_allclose(
        posterior_from_cumulative(cumulative_from_posterior(posterior)), posterior
    )


def test_projection_is_coherent():
    raw = np.array([[0.8, 0.2], [-0.1, 1.2], [0.2, 0.9]])
    projected = project_cumulative_probabilities(raw)
    assert np.all(projected[:, 0] >= 0.0)
    assert np.all(projected[:, 1] <= 1.0)
    assert np.all(projected[:, 0] <= projected[:, 1])
    assert_allclose(projected[0], [0.5, 0.5])


def test_hybrid_zero_weight_equals_categorical():
    arm = np.array([0, 1, 2, 1])
    posterior = np.array(
        [
            [0.2, 0.7, 0.1],
            [0.1, 0.8, 0.1],
            [0.1, 0.6, 0.3],
            [0.05, 0.9, 0.05],
        ]
    )
    assert_allclose(
        hybrid_log_loss_rows(posterior, arm, ordinal_weight=0.0),
        categorical_log_loss_rows(posterior, arm),
    )
    assert np.all(cumulative_log_loss_rows(posterior, arm) >= 0.0)


def test_cumulative_two_gap_gradient_matches_finite_difference():
    arm = np.array([0, 1, 2, 1, 2])
    u = np.array([0.2, 0.3, 0.5, 0.1, 0.4])
    v = np.array([0.1, 0.4, 0.2, 0.3, 0.6])
    analytic = cumulative_two_gap_gradient(u, v, arm, DEFAULT_PI)
    eps = 1e-6
    numerical = np.empty_like(analytic)
    for j in range(2):
        up, vp = u.copy(), v.copy()
        um, vm = u.copy(), v.copy()
        if j == 0:
            up += eps
            um -= eps
        else:
            vp += eps
            vm -= eps
        lp = cumulative_log_loss_rows(two_gap_buyer_posterior(up, vp), arm)
        lm = cumulative_log_loss_rows(two_gap_buyer_posterior(um, vm), arm)
        numerical[:, j] = (lp - lm) / (2 * eps)
    assert_allclose(analytic, numerical, rtol=2e-5, atol=2e-6)


def test_threshold_replication_retains_row_identity():
    X = np.arange(12, dtype=float).reshape(6, 2)
    arm = np.array([0, 1, 2, 0, 1, 2])
    rep = make_all_threshold_replication(X, arm, DEFAULT_PI)
    assert rep.X.shape == (12, 3)
    assert_allclose(rep.target.reshape(6, 2), cumulative_targets(arm))
    assert_allclose(rep.original_index, np.repeat(np.arange(6), 2))
    assert_allclose(rep.threshold, np.tile([0, 1], 6))


def test_ipw_all_threshold_random_forest_api():
    # Deterministic software smoke test only; not evidence about insurance data.
    X = np.array([[i, i % 3] for i in range(45)], dtype=float)
    arm = np.tile(np.array([0, 1, 2]), 15)
    model = IPWAllThresholdClassifier(
        RandomForestClassifier(
            n_estimators=40,
            max_depth=3,
            min_samples_leaf=3,
            random_state=7,
            n_jobs=1,
        )
    )
    model.fit(X, arm, pi=DEFAULT_PI)
    posterior = model.predict_buyer_posterior(X[:5], pi=DEFAULT_PI)
    assert posterior.shape == (5, 3)
    assert_allclose(posterior.sum(axis=1), 1.0, atol=1e-10)
