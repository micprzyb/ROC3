# Bundle contents

```text
00_start_here/
  START_HERE.md
  BUNDLE_CONTENTS.md
  AGENT_HANDOFF_MANIFEST.md

01_agent_prompt/
  LLM_AGENT_PROMPT_ELASTICITY_PRESERVATION_FIRST_V4.md

02_migration_templates/
  DATA_CONTRACT.md
  PRESERVATION_FIRST_EXECUTION_CHECKLIST.md
  REAL_DATA_ADAPTER_PRESERVATION_TEMPLATE.md
  ARTIFACT_LINEAGE_TEMPLATE.csv
  MIGRATION_MAP_TEMPLATE.md
  REFERENCE_CODE_MAPPING_TEMPLATE.csv
  MODEL_ARTIFACT_METADATA_TEMPLATE.json

03_reference_implementation_v0.6.0/
  installable and tested Python reference package

03_theory_and_design/
  FULL_TUTORIAL_PRE_SHARED_UPDATE.md
  TWO_GAP_MODEL_EXPLANATION.md
  SHARED_INFORMATION_RESEARCH_NOTE.md
  TREE_MULTIOUTPUT_AND_PAIRWISE_NOTE.md
  MODEL_API_AND_PREDICTION_CONTRACT.md
  INTEGRATION_GUIDE.md
  DELTA_FROM_V0.5.0.md

04_legacy_reference_packages/
  exact historical Python ZIP packages
  LEGACY_PACKAGE_INDEX.md

05_verification/
  bundle and package verification records

06_archived_prompts/
  superseded V2 and V3 prompts, for provenance only
```
