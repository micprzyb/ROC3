# Start here: complete handoff for the elasticity-modeling agent

This bundle is designed to be supplied as **one extracted directory** to the
LLM coding agent that already worked on the real insurance repository.

## Active instruction

Use only:

```text
01_agent_prompt/LLM_AGENT_PROMPT_ELASTICITY_PRESERVATION_FIRST_V4.md
```

as the active agent prompt.  Prompts under `06_archived_prompts/` are retained
for provenance and must not override V4.

## What to give the agent

Give the agent:

1. this entire extracted bundle;
2. access to the current evolved repository;
3. the existing artifact locations, Optuna storage, model registry, and fold
   registry;
4. access to the real randomized experiment through the existing approved data
   adapter;
5. the resolved values requested in Section 0 of the V4 prompt.

Do not give the agent a new copy of raw data outside the approved security
boundary.  The bundle contains no real insurance records.

## Why both new and old Python packages are included

`03_reference_implementation_v0.6.0/` is the latest reference implementation.
It contains the previous models and all post-prompt additions.

`04_legacy_reference_packages/` contains exact historical packages.  The agent
may have adapted one of them during earlier work.  They allow the agent to
identify what was originally supplied and distinguish upstream reference code
from its own later changes.

The agent must not install or copy any package over the current repository
before preservation and capability mapping.

## Recommended execution order

1. Read the V4 prompt completely.
2. Run a read-only preflight on the current repository.
3. Preserve uncommitted work, data adapters, folds, studies, models, and
   predictions.
4. Run the v0.6.0 reference tests in an isolated environment.
5. Create `REFERENCE_CODE_MAPPING.md` and `MIGRATION_MAP.md`.
6. Freeze data and baseline prediction fingerprints.
7. Port only missing capabilities behind new versioned interfaces.
8. Run parity and rollback tests.
9. Run new models in shadow mode on the preserved real-data/fold versions.
10. Promote nothing automatically.

## Verification performed before packaging

The v0.6.0 reference implementation passed 51 tests, including native
LightGBM and XGBoost smoke tests.  The package contains no synthetic model
leaderboard.  See `05_verification/` and the package `qa/` directory.
