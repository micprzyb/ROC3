# Agent handoff manifest

## Purpose

Provide one preservation-first, code-complete handoff to an LLM agent that may
have already changed the earlier reference code and adapted real insurance data
to its own framework.

## Active components

- Active prompt: V4.
- Latest reference source: v0.6.0.
- Real-data contract: included under migration templates.
- Historical reference packages: retained read-only for comparison.
- Raw insurance data: deliberately absent.

## Expected host-repository outputs

The agent should create new versioned outputs rather than writing into the
bundle or old run directories.  Expected outputs include:

```text
PRE_UPGRADE_SOURCE_STATE.md
ASSET_INVENTORY.csv
REAL_DATA_ADAPTER_MAP.md
DATA_PARITY_REPORT.md
FOLD_REGISTRY_REPORT.md
BASELINE_REPRODUCTION_REPORT.md
REFERENCE_CODE_MAPPING.md
MIGRATION_MAP.md
REFERENCE_IMPLEMENTATION_DEVIATIONS.md
MODEL_REGISTRY_DELTA.md
RESEARCH_LOG.md
ROLLBACK_TEST_REPORT.md
FINAL_UPGRADE_REPORT.md
```

## Source-of-truth hierarchy

1. preserved current repository and real-data behavior;
2. verified current artifacts and earlier agent work;
3. v0.6.0 reference package;
4. historical packages.

## No automatic promotion

The bundle does not authorize production deployment, price changes, model
registry replacement, or overwriting of prior artifacts.
