# Preservation-first, code-bundle-aware prompt for an LLM coding and research agent
## Extend an evolved real-data motor-insurance price-elasticity system without losing prior code, real-data adaptation, experiments, artifacts, or earlier agent modifications

Use this prompt as the complete instruction for the agent. Replace the placeholders in **Section 0** before execution.

## Bundled reference material and precedence

This prompt is distributed inside a self-contained handoff bundle.  Discover
`BUNDLE_ROOT`, the directory containing this file, and inspect these paths
before changing the host repository:

```text
BUNDLE_ROOT/
  00_start_here/
  01_agent_prompt/
  02_migration_templates/
  03_reference_implementation_v0.6.0/
  03_theory_and_design/
  04_legacy_reference_packages/
  05_verification/
  06_archived_prompts/
```

The bundle contains two different kinds of code assets:

1. `03_reference_implementation_v0.6.0/` is the latest reference extension.
   It includes the original scalar, pairwise, multiclass, exact two-gap,
   calibration, policy, and Optuna code plus newer shared-information,
   all-threshold, hybrid-loss, common-plus-residual, and preservation modules.
2. `04_legacy_reference_packages/` contains exact historical ZIP files that may
   match code supplied during an earlier agent session.  They exist for
   comparison, provenance, and recovery.  They are not instructions to
   downgrade or overwrite the current repository.

Apply this precedence rule:

```text
current evolved repository and its preserved real-data behavior
    > verified current artifacts and prior agent work
    > v0.6.0 reference implementation
    > historical reference ZIP files.
```

The current repository is the source of truth for work already completed.  The
bundled implementation is a specification, test oracle, and source of missing
capabilities.  Never copy its package tree over the repository wholesale.
Never replace a current data adapter, feature pipeline, fold registry, Optuna
study, serialized model, prediction table, or report merely because the bundle
contains a file with a similar name.

Before porting code, create `REFERENCE_CODE_MAPPING.md` with one row per
bundled module and required capability:

```text
bundled capability
bundled file and symbol
current repository equivalent
status: equivalent / partially equivalent / missing / incompatible
preserve action
integration action
compatibility wrapper
parity test
rollback path
```

Run the v0.6.0 reference tests in an isolated copy of the bundle before using
it as an oracle.  Do not install it into the host environment if doing so would
change the host lockfile or package versions.  Prefer a temporary environment
or the already compatible environment.

When porting a missing capability:

1. retain the current repository's public interfaces when practical;
2. add a new versioned module or adapter rather than editing an old artifact in
   place;
3. port the smallest coherent unit, including its mathematical tests;
4. preserve old prediction schemas through compatibility converters;
5. add an explicit model/objective version to artifacts and Optuna studies;
6. prove data, fold, and baseline parity before comparing model quality;
7. keep the legacy implementation available behind a feature flag or registry
   entry until the replacement is validated and promotion is approved.

The active prompt is this V4 file.  Files under `06_archived_prompts/` are
included only for traceability and must not override V4.

---

## 0. Execution inputs

You are working inside an existing Python repository. The repository may have evolved since an earlier implementation, so do not assume exact filenames, class names, function signatures, package versions, or configuration structure.

Set or discover the following values. Do not guess silently. Values may be discovered from the existing repository, current configuration, run manifests, or environment variables.

```text
BUNDLE_ROOT = <path to this extracted handoff bundle>
REPOSITORY_ROOT = <path to the current repository>
REAL_EXPERIMENT_DATA = <path or registered dataset identifier for the real randomized quote table>
EXPERIMENT_CONFIG = <path to the current project configuration, if any>
EXISTING_ARTIFACT_ROOTS = <one or more locations containing prior runs, models, folds, studies, predictions, or reports>
NEW_UPGRADE_ROOT = <brand-new path for preservation records and new upgrade outputs>
PRIMARY_CLUSTER_COLUMN = <customer or household identifier>
TIME_COLUMN = <quote timestamp>
DATA_SECURITY_BOUNDARY = <approved directory or storage boundary within which sensitive data may be read and written>
ALLOW_GIT_BRANCH_OR_COMMITS = <true only when explicitly permitted by the project owner>
REFERENCE_IMPLEMENTATION = BUNDLE_ROOT/03_reference_implementation_v0.6.0
LEGACY_REFERENCE_ROOT = BUNDLE_ROOT/04_legacy_reference_packages
```

`NEW_UPGRADE_ROOT` must not already contain a completed run and must not alias `REPOSITORY_ROOT`, a raw-data directory, an existing model registry, an Optuna database, or a prior run directory. Create a unique run identifier such as:

```text
UTC timestamp + repository commit or source hash + resolved-config hash.
```

Treat every pre-existing object as potentially valuable work, including:

- source code and uncommitted edits;
- notebooks and exploratory scripts;
- real-data loaders, joins, filters, and feature engineering;
- manually curated column mappings and feature-timing decisions;
- cached canonical datasets and model matrices;
- quote inclusion and exclusion decisions;
- customer-group and time-based fold assignments;
- logged-propensity handling;
- fitted preprocessors and category vocabularies;
- Optuna databases, study metadata, and best parameters;
- serialized models and calibrators;
- out-of-fold and holdout predictions;
- reports, research logs, model cards, and negative findings.

The upgrade must preserve these objects or create explicit versioned successors. It must never silently replace them.

The economic price order is

```text
price(H) > price(C) > price(L).
```

To avoid ambiguity:

- `H` means the **high-price** arm;
- `C` means the **control-price** arm;
- `L` means the **low-price** arm;
- for ordinal modeling only, define an ordinal index `K` by `K=1` for `H`, `K=2` for `C`, and `K=3` for `L`. This ordering runs from highest displayed price to lowest displayed price.

---

## 1. Role, mission, and evidence standard

You are an applied machine-learning researcher, causal-inference practitioner, and production Python engineer. Upgrade the current codebase so it can estimate heterogeneous **relative demand and price elasticity** from a real randomized motor-insurance price experiment.

The main business objective is to identify customer and vehicle contexts in which moving from control to a tested higher or lower price improves expected contribution. Absolute base conversion is secondary.

Follow these non-negotiable rules, in the stated order of precedence:

1. **Preserve before modifying.** Do not edit production code, data adapters, configurations, folds, studies, or artifacts until the preservation snapshot and baseline inventory described in Section 2 exist.
2. **Never destroy prior work.** Do not delete, overwrite, reset, clean, truncate, rename in place, or silently supersede pre-existing source files, data products, model artifacts, study databases, predictions, or reports. Mark old work as verified, unverified, deprecated, incompatible, or superseded; keep it available.
3. **Do not rewrite the repository from scratch.** Discover the framework that now exists, preserve its conventions, and add adapters or extensions. Replacement is a last resort and requires parity evidence plus a rollback path.
4. Use only the supplied **real randomized quote data** for empirical model comparison and model selection.
5. Synthetic or hand-constructed arrays may be used only for deterministic unit tests, derivative checks, and algebraic identity tests. Do not create a synthetic model leaderboard.
6. Do not claim that an individual customer’s true elasticity is observed. It is not.
7. Do not report individual elasticity RMSE or correlation on real data.
8. Every model score used for selection must be strictly out of fold or computed on a final untouched chronological holdout. If a supposed holdout was already used in earlier work, label it contaminated and preserve it; create a new versioned holdout rather than pretending it is untouched.
9. All folds must be disjoint by customer or household cluster. Preserve existing fold assignments for like-for-like comparisons unless they are invalid; never overwrite them.
10. Use logged row-level randomization propensities. Do not replace them with estimated propensities unless the experiment audit proves the logs are wrong.
11. Do not use post-treatment features or variables derived from the experimental displayed price unless the analysis is explicitly labeled secondary and causal interpretation is justified.
12. Raw and source real-data files are read-only. Do not mutate them, write derived columns back into them, move them, or include them in code snapshots or report bundles.
13. Do not hide failures. Record positive results, negative results, unstable results, implementation limitations, pre-existing failures, introduced failures, and dead ends in a research log.
14. If required real data or experiment metadata are missing, stop model fitting and produce a missing-data or invalid-experiment report. Never invent replacement data.
15. If preservation cannot be completed safely because of permissions, unknown data boundaries, insufficient disk space, concurrent writers, ambiguous repository state, or missing provenance, stop before code modification and produce `PRESERVATION_BLOCKER_REPORT.md`.
16. The preservation requirement outranks model breadth. A smaller non-destructive upgrade is better than a comprehensive rewrite that risks losing prior real-data work.

### 1.1 Minimum safe completion

If time, compute, package support, or repository complexity prevents completion of every requested model, the minimum acceptable result is:

1. a verified preservation snapshot and restore procedure;
2. a complete map of the current real-data adapter, folds, studies, models, and outputs;
3. a frozen baseline and parity report;
4. a versioned compatibility interface;
5. an evidence-based implementation plan for the remaining models;
6. at least one new model integrated in shadow mode without altering prior behavior.

Do not rush through preservation or break the existing real-data pipeline merely to check every model-family box.

---

## 2. First task: preserve, reproduce, and map the current system before changing it

The repository may have been renamed, reorganized, partially rewritten, or adapted to a different framework. The current implementation may contain valuable real-data work that is not present in the earlier reference package. Treat the current repository and its artifacts as the source of truth about what has already been accomplished.

Do not begin by copying old files over the repository. Do not begin by implementing the new models. Complete the preservation protocol below first.

### 2.1 Stop-the-line conditions

Before any write to the repository, determine whether a safe upgrade is possible. Stop and create `PRESERVATION_BLOCKER_REPORT.md` if any of the following is true:

- `REPOSITORY_ROOT`, `NEW_UPGRADE_ROOT`, or the sensitive-data boundary cannot be identified unambiguously;
- `NEW_UPGRADE_ROOT` overlaps a raw-data location, existing run, model registry, cache, or study database;
- active processes appear to be writing model artifacts, fold files, caches, or Optuna storage that the upgrade would inspect or copy;
- there is insufficient disk space for a code/configuration snapshot and new artifacts;
- the worktree contains valuable uncommitted changes that cannot be snapshotted safely;
- access controls prohibit the required inventory or fingerprinting;
- the current real-data adapter cannot be located and its behavior cannot be reconstructed from outputs;
- secrets or raw personally identifiable information would be copied outside the approved security boundary;
- an operation would require destructive commands such as `git reset --hard`, `git clean`, forced checkout, recursive deletion, or in-place database migration.

Do not work around these conditions by guessing. Preserve what can be observed, explain the blocker, and stop before modification.

### 2.2 Read-only preflight

Perform a read-only inspection and write the findings only under the new upgrade root. Record:

- repository path, current working directory, and resolved symlinks;
- whether the repository uses Git or another version-control system;
- current branch, commit, tags, remotes, submodules, and worktree status;
- tracked modifications, staged modifications, untracked files, ignored files relevant to the project, and local patches;
- Python and package-manager environment;
- disk space and relevant filesystem permissions;
- active training, tuning, notebook, or data-build processes when observable;
- candidate locations for raw data, canonical datasets, caches, folds, studies, models, predictions, and reports;
- current configuration entry points and command-line interfaces;
- CI configuration and test commands.

This preflight must not modify the worktree, install packages, update lockfiles, run formatters, clear caches, resume Optuna studies, or regenerate data.

### 2.3 Create an isolated preservation and upgrade workspace

Create a new directory with `exist_ok=False` semantics. Use a structure similar to:

```text
NEW_UPGRADE_ROOT/
  00_preservation/
  01_inventory/
  02_baseline/
  03_migration_design/
  04_implementation/
  05_validation/
  06_reports/
  checkpoints/
```

Every generated file must be written under this new root or to new versioned source files in the repository. Never write into a previous run directory.

Use atomic writes for manifests, configurations, prediction tables, and reports: write to a temporary path, validate, then rename to a path that does not already exist. A helper such as `safe_write_new(path, content)` should fail when the target already exists unless the target is a temporary file created by the same operation.

### 2.4 Preserve version-control and uncommitted state

If Git is present, record at least:

```text
git rev-parse HEAD
git status --porcelain=v2 --branch
git diff --binary
git diff --cached --binary
git submodule status --recursive
```

Store the textual and binary patches under `00_preservation/`. Create an inventory of untracked files without automatically adding them to Git. Do not use `git stash` as the only backup and do not assume untracked files are disposable.

Create a code-and-configuration snapshot that excludes raw data, secrets, large caches, prior model artifacts, and other sensitive or reproducible bulk files. Prefer a tracked-file archive plus explicitly allowlisted untracked source/configuration files. Generate SHA-256 hashes for snapshot contents.

If the project owner explicitly permits branch creation, create a new upgrade branch or worktree only after the snapshot exists. Do not commit the owner’s pre-existing uncommitted changes as if they were your work. If commits are permitted, use small phase-specific commits and never force-push or rewrite history.

If the repository is not under version control, create a code/configuration-only archive and a full file manifest with paths, sizes, modification times, and hashes. Do not copy raw real data merely to simulate version control.

Create:

```text
PRE_UPGRADE_SOURCE_STATE.md
PRE_UPGRADE_SOURCE_SHA256.txt
RESTORE_INSTRUCTIONS.md
```

`RESTORE_INSTRUCTIONS.md` must explain how to reconstruct the pre-upgrade code and configuration state without touching raw data or prior artifacts.

### 2.5 Sensitive-data protection

The raw experiment data and any directly identifying customer information must remain within `DATA_SECURITY_BOUNDARY`.

- Treat raw input files and source database tables as read-only.
- Do not include real rows, unmasked identifiers, secrets, connection strings, or raw feature values in prompts, source snapshots, reports, ZIP archives, or Git commits.
- Store only approved aggregate statistics, schemas, fingerprints, and secure internal row identifiers in preservation records.
- When a deterministic sample is needed for a regression test, prefer a list of existing secure quote identifiers plus hashes of expected transformed outputs. Do not export the corresponding raw records.
- If full-file hashing is too expensive or prohibited, record file size, modification time, schema, row count, partition metadata, and stable chunk or registered dataset fingerprints. State exactly what was and was not fingerprinted.
- Sanitize stack traces and logs that may contain paths, SQL, or data values.

### 2.6 Build a complete asset inventory

Create `ASSET_INVENTORY.csv` or an equivalent machine-readable table with at least these columns:

```text
asset_id
asset_type
path_or_registry_key
version_or_timestamp
sensitivity_class
source_of_truth
current_status
producer
consumer
configuration_reference
data_fingerprint
fold_version
code_version
hash_or_fingerprint
preservation_action
notes
```

Inventory at least:

- source packages and custom objectives;
- notebooks and analyst scripts;
- environment and lock files;
- raw-data registrations, without copying raw data;
- real-data loaders and SQL or join definitions;
- canonical transformed datasets and caches;
- eligibility, deduplication, outcome-window, and buyer filters;
- feature manifests, category vocabularies, and fitted preprocessors;
- row-level or cluster-level fold definitions;
- holdout definitions and whether each holdout has already been inspected;
- Optuna databases and study names;
- tuned parameter files;
- serialized models and calibrators;
- out-of-fold and holdout predictions;
- metric tables, figures, reports, and research logs;
- manual overrides or undocumented analyst decisions discovered in code or notebooks.

Never delete an asset because it appears obsolete. Assign one of:

```text
verified
unverified
deprecated
superseded
incompatible
corrupted
unknown
```

and preserve its lineage.

### 2.7 Preserve the existing real-data adaptation as a first-class artifact

This is a critical requirement. The current repository may already contain substantial work adapting real insurance data to the earlier models. The upgrade must not discard or silently reimplement it.

Discover the complete transformation path from registered raw inputs to model-ready rows. Create:

```text
REAL_DATA_ADAPTER_MAP.md
CURRENT_DATA_BEHAVIOR_CONTRACT.md
FEATURE_LINEAGE.csv
DATASET_VERSION_REGISTRY.json
```

Document, before changing anything:

- every input source and partition;
- join keys and join cardinality checks;
- quote deduplication and shopping-episode logic;
- eligibility conditions and every exclusion reason;
- purchase definition and attribution window;
- arm-label mapping and price-order mapping;
- logged-propensity columns and normalization rules;
- assigned, intended, displayed, and realized price multipliers;
- control-price construction and log-dose construction;
- customer or household cluster definition;
- timestamp used for chronology;
- pre-treatment feature list and feature-timing evidence;
- categorical casting and vocabulary handling;
- missing-value treatment;
- sample and cluster weights;
- buyer-only, pairwise, and all-quote views;
- contribution or margin construction;
- current fold and holdout assignment logic;
- fitted preprocessing artifacts and expected feature order;
- row identifiers carried through every stage;
- caches, their keys, and invalidation rules.

The new models must consume the existing canonical prepared-data layer through an adapter whenever that layer is valid. Do not make each new model independently reload, rejoin, refilter, or reinterpret the raw insurance data.

Create or adapt a canonical internal object with equivalent behavior to:

```python
@dataclass(frozen=True)
class PreparedElasticityData:
    all_quotes: object
    buyers: object
    quote_id: object
    cluster_id: object
    timestamp: object
    arm: object
    purchase: object
    propensity_matrix: object
    price_dose_matrix: object | None
    feature_matrix_or_view: object
    feature_manifest: object
    fold_registry: object
    contribution_by_arm: object | None
    dataset_fingerprint: str
    data_contract_version: str
```

The precise class is optional. The capabilities and lineage are mandatory.

If the existing framework uses a different object, wrap it rather than replacing it. Model-specific datasets—buyer rows, `H/C` rows, `L/C` rows, cumulative replicated rows, cross-fitting views—must be derived downstream from the preserved canonical object and must retain `quote_id`, cluster, time, arm, propensity, fold, and source-row lineage.

### 2.8 Data-adapter parity gates

Before integrating a new model, run the current real-data adapter unchanged and freeze a parity baseline. Record, where permitted:

- dataset fingerprint and configuration hash;
- eligible quote identifiers or a secure hash set;
- row counts at every transformation stage;
- buyer counts and conversion rates by arm;
- sums and distributions of logged propensities;
- missingness by column;
- feature names, order, dtypes, and category vocabularies;
- distributions or quantiles of price doses;
- cluster counts and repeated-quote distributions;
- fold membership counts and secure hashes;
- holdout membership and contamination status;
- exclusion counts by reason;
- fitted-preprocessor output dimension and feature-name hash.

Create `DATA_PARITY_BASELINE.json` and `DATA_PARITY_REPORT.md`.

After any data-adapter change, compare the new version against the frozen baseline. Shared fields and shared rows must match exactly unless a deliberate, documented correction was approved. Every difference must be classified as:

```text
expected_and_approved
expected_but_unvalidated
unexpected_regression
bug_fix_with_impact_analysis
```

A new model requirement is not sufficient justification for changing the canonical population, outcome, arm mapping, propensity, or fold assignment.

The first comparison of every new model must be **data-frozen**: use the same eligible rows, outcome, arm definitions, propensities, feature manifest, preprocessing semantics, and folds as the preserved baseline. New feature engineering or data-cleaning changes may be evaluated only in a separate versioned ablation after the model-only comparison. Do not attribute a gain to the new loss or architecture when the data preparation also changed.

If a data-adapter correction is necessary:

1. keep the original adapter available as version `v1` or an equivalent immutable reference;
2. implement a versioned successor rather than editing semantics silently;
3. create forward and compatibility adapters where feasible;
4. produce a row-level or aggregate impact analysis inside the security boundary;
5. rerun old baselines under both versions when possible;
6. never overwrite old caches, folds, predictions, or reports;
7. explain whether model comparisons remain like-for-like.

### 2.9 Freeze folds, holdouts, and row lineage

Existing fold assignments are valuable experimental work. Preserve them as immutable, versioned artifacts.

- New model families should use the same valid outer and inner folds as existing models for fair comparison.
- Never regenerate folds merely because a new framework has a convenient splitter.
- Never overwrite an existing `fold_id` column or file.
- If existing folds violate customer separation, chronology, or another non-negotiable requirement, retain them as invalid historical artifacts and create a new fold version with a clear migration report.
- If the prior final holdout has already influenced tuning, documentation, or model selection, mark it `contaminated_for_final_selection`. Preserve its results and create a new chronological holdout version when the data permit.
- Every derived or replicated row must carry its original quote identifier and fold lineage.

Create:

```text
FOLD_REGISTRY.csv
HOLDOUT_STATUS.md
ROW_LINEAGE_SPEC.md
```

### 2.10 Preserve prior experiments, models, and Optuna work

Do not rerun or discard earlier work unnecessarily. Catalog it first.

Create `BASELINE_ARTIFACT_CATALOG.csv` containing every prior candidate that can be found, including:

- model family and version;
- data-contract version;
- dataset fingerprint;
- fold version;
- feature manifest;
- objective and target semantics;
- calibration version;
- Optuna study name and storage;
- best parameters;
- model path;
- prediction path;
- metrics path;
- environment or package versions;
- whether the artifact can still be loaded;
- whether it is comparable to the new evaluation.

Use existing valid out-of-fold predictions as baselines rather than reproducing them blindly. If a model must be rerun for a common fold or metric, keep the original artifact and write the rerun under a new identifier.

Optuna storage is append-sensitive and must be protected:

- never delete, truncate, vacuum destructively, rename in place, or reuse a study name for a changed objective;
- copy a study database only when permitted and record source and destination hashes;
- resume a study only when dataset fingerprint, fold version, objective, search space semantics, and code version are compatible;
- create new versioned studies for new shared, residual, cumulative, or hybrid objectives;
- where parameter semantics are compatible, enqueue previous best parameter sets as warm-start trials rather than pretending old trials optimize the new objective;
- preserve failed and pruned trials;
- create `OPTUNA_LINEAGE.md` explaining reuse, warm starts, and incompatibilities.

Serialized models must not be loaded and re-saved over the original. If package-version migration is necessary, write a new migrated artifact, preserve the original bytes and environment metadata, and verify prediction parity on a secure golden cohort.

### 2.11 Establish a reproducible pre-upgrade baseline

Before changing behavior:

1. run the existing test suite exactly as currently documented;
2. record all passing and failing tests without first fixing them;
3. run the existing data audit on the current real-data configuration when safe;
4. capture or index existing baseline OOF predictions and metrics;
5. run a small deterministic legacy prediction smoke test for each loadable model family;
6. capture the current command, resolved configuration, seeds, environment, and runtime metadata.

Create:

```text
PRE_UPGRADE_TEST_REPORT.md
PRE_EXISTING_FAILURES.md
CURRENT_BEHAVIOR_BASELINE.md
LEGACY_PREDICTION_FINGERPRINTS.json
```

A pre-existing failing test is not an introduced regression. An existing test that begins failing after the change is an introduced regression unless the behavior change is explicitly approved and covered by a versioned compatibility plan.

For sensitive data, a golden cohort may be represented by secure quote identifiers plus hashes of predictions and transformed feature rows. Do not place raw rows in general artifacts.

### 2.12 Required migration map and change plan

Only after Sections 2.1–2.11 are complete, inspect the codebase by behavior rather than old names and create:

```text
MIGRATION_MAP.md
CHANGESET_PLAN.md
```

`MIGRATION_MAP.md` must contain:

```text
Required capability
Current implementation location
Current interface
Data contract and fold version
Preserve / wrap / extend / replace / add
Reason
Dependencies
Tests protecting the change
Rollback method
```

At minimum, map:

- exact Bayes-flip identity;
- risk-ratio reconstruction;
- scalar common-elasticity likelihood;
- exact two-gap likelihood;
- pairwise `H/C` and `L/C` models;
- coherent posterior reconstruction;
- buyer joint log loss;
- pairwise log loss;
- calibration;
- cluster bootstrap;
- nested group cross-validation;
- chronological holdout;
- real-data canonical adapter;
- feature preprocessing;
- fold registry;
- Optuna study persistence;
- LightGBM and XGBoost raw-margin handling;
- Random Forest probability handling;
- model serialization and registry;
- prediction schemas;
- policy evaluation.

`CHANGESET_PLAN.md` must list changes in dependency order, the exact existing components that will be reused, and the regression gate after each change. Do not begin a broad refactor without this plan.

### 2.13 Framework-adaptive change strategy

The current agent or previous engineers may have adapted the original code to another framework. Preserve that work when statistically sound.

- Prefer compatibility adapters, plugin modules, and feature flags over replacement.
- Follow the repository’s current package layout, configuration conventions, logging, dependency injection, serialization, and test framework unless they are unsafe.
- Add a canonical elasticity-model adapter so old and new models produce a common evaluation record without forcing old classes to be rewritten.
- Preserve public APIs where practical. If an interface must change, keep a legacy wrapper and a deprecation note.
- Do not silently change the meaning or units of an existing prediction column. Add a schema version and new column names.
- Keep new models disabled by default until validation gates pass.
- Keep old production or baseline model aliases unchanged. Promotion must be a separate explicit registry action, not a side effect of implementation.
- Do not modify raw-data preparation merely to satisfy a preferred model library. Adapt model inputs downstream.
- Make each new capability independently disableable through configuration so rollback does not require code deletion.

### 2.14 Runtime capability and environment preservation

Record installed versions of:

- Python;
- NumPy;
- SciPy;
- pandas or Polars;
- scikit-learn;
- LightGBM;
- XGBoost;
- Optuna;
- PyTorch, JAX, or TensorFlow if used;
- serialization and data-storage libraries.

Capture the current environment before installing or upgrading anything. Do not update package versions merely to access an optional model. Prefer capability detection and graceful skipping.

Do not assume an experimental XGBoost multi-output feature exists because a documentation page mentions it. Detect support through the installed package and a tiny deterministic smoke test. If an environment change is genuinely required, create a new lock or environment file alongside the old one, document the reason, and rerun legacy serialization and prediction-parity tests.

### 2.15 Preservation gates and rollback checkpoints

The upgrade must pass these gates sequentially:

```text
Gate P0: read-only preflight completed.
Gate P1: code/configuration snapshot and restore instructions completed.
Gate P2: asset inventory and real-data adapter map completed.
Gate P3: pre-upgrade tests and legacy baselines recorded.
Gate P4: data-adapter and fold parity baseline frozen.
Gate M1: migration map and changeset plan approved by evidence.
Gate M2: compatibility layer passes legacy prediction tests.
Gate M3: new mathematical components pass deterministic tests.
Gate M4: new models run in shadow mode on preserved folds.
Gate V1: OOF evaluation and calibration completed.
Gate V2: chronological holdout evaluated only after protocol freeze.
Gate R1: rollback procedure tested in a temporary location.
```

At each gate create a checkpoint record containing source hashes, generated artifacts, tests, unresolved risks, and the next allowed actions.

Do not claim completion until `Gate R1` succeeds: reconstruct or load the pre-upgrade state in a separate temporary path and verify the relevant hashes, configuration, and legacy smoke predictions.

### 2.16 Prohibited preservation shortcuts

Never use any of the following as part of this task:

```text
git reset --hard
git clean -fd or stronger variants
forced checkout that discards changes
rm -rf on repository, artifact, cache, study, or data paths
in-place overwrite of prior model or prediction files
drop or truncate of Optuna tables
unversioned schema migration
in-place edits to raw data
blanket cache invalidation or cache deletion
rebuilding folds under the same fold version
```

Do not use `git stash`, a copied notebook, or an unverified ZIP as the sole preservation mechanism. Preservation requires manifests, hashes or fingerprints, lineage, and a tested restore path.

## 3. Define every statistical object before using it

For one eligible randomized quote, define:

- `X=x`: all customer, vehicle, tariff, channel, and market features known before the experimental price is displayed;
- `T in {H,C,L}`: randomized price arm;
- `Y in {0,1}`: purchase indicator;
- `pi_t(x) = P(T=t | X=x)`: logged randomization probability for arm `t`;
- `q_t(x) = P(Y=1 | T=t, X=x)`: arm-specific conversion risk;
- `r_t(x) = P(T=t | Y=1, X=x)`: buyer-side arm probability.

The exact Bayes-flip identity is

```text
r_t(x) = pi_t(x) q_t(x) / sum_j pi_j(x) q_j(x).
```

Define relative conversion risk to control:

```text
RR_HC(x) = q_H(x) / q_C(x)
RR_LC(x) = q_L(x) / q_C(x)
RR_CC(x) = 1.
```

Bayes’ rule identifies these ratios:

```text
RR_tC(x)
  = [r_t(x) / pi_t(x)] / [r_C(x) / pi_C(x)].
```

For fixed assignment probabilities `pi=(0.1,0.8,0.1)`:

```text
RR_HC(x) = 8 r_H(x) / r_C(x)
RR_LC(x) = 8 r_L(x) / r_C(x).
```

The economically usual monotonicity assumption is

```text
q_H(x) <= q_C(x) <= q_L(x),
```

which is equivalent to

```text
RR_HC(x) <= 1 <= RR_LC(x)
```

and also to

```text
r_H(x)/pi_H(x)
  <= r_C(x)/pi_C(x)
  <= r_L(x)/pi_L(x).
```

Do not assume strict inequalities. Zero effect is a valid boundary case.

---

## 4. Business objective and why base conversion is secondary

Let

```text
g_t(x)
```

be expected contribution conditional on purchase under arm `t`. It must include all business-relevant arm-dependent quantities, for example premium, expected claim cost, commissions, taxes, payment costs, and other variable expenses.

Expected contribution per quote is

```text
V_t(x) = g_t(x) q_t(x)
       = q_C(x) g_t(x) RR_tC(x).
```

For a fixed customer context, `q_C(x)` is a positive common factor across the tested arms. Therefore, the best tested arm is

```text
d*(x) = argmax_t g_t(x) RR_tC(x).
```

The core model-selection task is therefore accurate relative demand, calibration, and randomized policy value. A base-conversion model may be added for:

- total-volume forecasting;
- doubly robust policy evaluation;
- variance reduction;
- absolute expected-value forecasts;
- portfolio constraints stated in absolute units.

It must not dominate the elasticity model objective.

---

## 5. Elasticity reporting conventions

The primary learned objects should remain the risk ratios. Elasticity is a transformation of a risk ratio and a price ratio.

For arm `t` relative to control, define the price ratio

```text
m_t(x) = P_t(x) / P_C(x).
```

### 5.1 Standard finite relative-change elasticity

```text
epsilon_rel_tC(x)
  = [RR_tC(x) - 1] / [m_t(x) - 1].
```

For nominal `+10%` and `-10%` arms:

```text
epsilon_rel_HC = [RR_HC - 1] / 0.10
epsilon_rel_LC = [RR_LC - 1] / (-0.10).
```

### 5.2 Log-change finite elasticity

```text
epsilon_log_tC(x)
  = log RR_tC(x) / log m_t(x).
```

Under decreasing demand, a positive sensitivity magnitude is

```text
beta_log_tC(x) = -epsilon_log_tC(x).
```

Do not silently relabel one convention as the other. Store:

- risk ratio;
- log risk ratio;
- price ratio;
- reference direction;
- signed elasticity;
- optional positive sensitivity magnitude;
- convention name.

---

## 6. The key new statistical insight to preserve

The earlier pairwise models discard `L` buyers when estimating `H/C`, and discard `H` buyers when estimating `L/C`. This looks wasteful, but the correct conclusion is subtle.

Define monotone log-risk gaps:

```text
u(x) = -log RR_HC(x) >= 0
v(x) =  log RR_LC(x) >= 0.
```

Then

```text
r(x)
  = softmax(
      log pi_H(x) - u(x),
      log pi_C(x),
      log pi_L(x) + v(x)
    ).
```

For the exact categorical buyer loss, the direct gradients are

```text
d loss / d u = I(T=H) - r_H
d loss / d v = r_L - I(T=L).
```

A `C` buyer and an `L` buyer have the same direct gradient with respect to `u`. This is not a bug. `u` is the `H/C` ratio, while `v` is an unrestricted nuisance quantity for that contrast.

At a fixed homogeneous `x`, the efficient information for `u` under an unrestricted `v` is

```text
I_eff,u = r_H r_C / (r_H + r_C),
```

which is exactly the information retained by the conditional `H/C` buyer likelihood.

Therefore:

```text
L observations help estimate H/C only through an explicit shared-structure assumption,
shared representation, regularization, or alternative proper score.
```

Do not implement arbitrary larger negative-class weights and call the result `RR_HC`.

If a binary `H`-versus-rest loss uses class-dependent negative weights `w_C` and `w_L`, its population optimum is

```text
p*(x)
  = r_H(x) / [r_H(x) + w_C r_C(x) + w_L r_L(x)].
```

For `w_L != w_C`, this is an artificial weighted posterior. It is not `r_H`, `r_H/r_C`, or `RR_HC`.

Arbitrary `w_L > w_C` is prohibited as a primary probability or elasticity estimator.

---

## 7. Required model set after the upgrade

The upgraded repository must support and compare the following candidates. If a family is impossible in the current framework, document the limitation and implement the nearest statistically valid adapter rather than silently changing the estimand.

### Model A: no-effect buyer posterior

```text
r_t(x) = pi_t(x).
```

This is the mandatory null.

### Model B: global scalar common-elasticity model

Define log-price doses relative to control:

```text
z_H(x) = log[P_H(x)/P_C(x)] > 0
z_C(x) = 0
z_L(x) = log[P_L(x)/P_C(x)] < 0.
```

Let `beta(x)>=0` be a common log-elasticity magnitude. The scalar model is

```text
RR_tC(x) = exp[-beta(x) z_t(x)].
```

For a global scalar anchor, `beta(x)=beta_0` for everyone.

### Model C: global exact two-gap model

Estimate constants

```text
u >= 0
v >= 0
```

by exact buyer categorical likelihood.

### Model D: separate pairwise baseline

Fit:

```text
H versus C
L versus C
```

using exact propensity offsets or a mathematically equivalent inverse-propensity formulation. Reconstruct a coherent three-arm posterior afterward.

This remains a mandatory baseline. It is not presumed wasteful.

### Model E: exact flexible two-gap model

Fit customer-dependent `u(x)` and `v(x)` jointly with the exact categorical buyer loss. Suitable implementations include:

- penalized linear model;
- spline or GAM basis with a general optimizer;
- neural network with automatic differentiation.

### Model F: scalar LightGBM and XGBoost custom-objective models

Fit one common `beta(x)` from all three buyer arms using the exact scalar buyer loss and a positive link such as softplus.

### Model G: common scalar model plus side-specific residual boosters

This is the primary new tree architecture.

1. Fit a common all-arm scalar model `beta_0(x)`.
2. Fit a strongly regularized `H/C` residual model around the common high-side margin.
3. Fit a strongly regularized `L/C` residual model around the common low-side margin.
4. Shrink residuals out of fold.
5. Reconstruct one coherent posterior.

This allows `L` buyers to inform the common sensitivity used for `H`, while retaining side-specific corrections.

### Model H: shared-component, side-specific-head neural model

When a neural framework exists, fit an exact joint model with a shared trunk and two side-specific heads.

### Model I: all-threshold or cumulative buyer model

Use every buyer at both ordered arm thresholds. Implement as:

- a differentiable cumulative model; or
- a replicated-row LightGBM or XGBoost model with a numeric threshold feature and coherent cumulative probabilities.

### Model J: hybrid categorical-plus-cumulative proper loss

Fit

```text
L_total = L_categorical + lambda_ord * L_cumulative,
```

with `lambda_ord>=0`, selected out of fold.

### Model K: built-in multiclass LightGBM and XGBoost challengers

Fit ordinary multiclass softmax models as benchmarks. Do not call them exact two-gap models unless the required offsets and monotone gap parameterization are explicitly implemented.

### Model L: XGBoost vector-leaf challenger

Only if the installed XGBoost version supports it and a smoke test succeeds, test a vector-leaf multi-output tree. Mark it experimental.

### Model M: Random Forest challengers

Support at least:

- inverse-propensity pairwise Random Forest;
- pairwise Random Forest using a cross-fitted common-sensitivity feature;
- optional scalar moment-inversion Random Forest.

Do not claim that standard Random Forest directly optimizes the exact custom buyer likelihood.

### Model N: constrained ensemble

Optionally fit a convex ensemble in log-risk-ratio space after all component predictions are strictly out of fold.

---

## 8. Exact scalar model: definition, learning, and integration

### 8.1 Why the power form is used

The scalar relation

```text
RR_tC(x) = exp[-beta(x) z_t(x)]
```

is the solution of a local constant-point-elasticity assumption:

```text
d log q(p,x) / d log p = -beta(x)
```

across the tested price interval.

It is also the first-order log-price approximation to a smooth positive demand curve. It is a structural restriction, not a consequence of Bernoulli outcomes or Bayes’ rule.

### 8.2 Buyer posterior

For buyer `i`:

```text
r_i,t(beta_i)
  = pi_i,t exp[-beta_i z_i,t]
    / sum_j pi_i,j exp[-beta_i z_i,j].
```

### 8.3 Loss

```text
loss_i(beta_i)
  = -log r_i,T_i(beta_i).
```

The derivative with respect to `beta_i` is

```text
d loss_i / d beta_i
  = z_i,T_i - sum_t r_i,t z_i,t.
```

The second derivative is

```text
Var_r_i(z_i) >= 0.
```

### 8.4 Positive link

For a flexible raw score `f(x)` use

```text
beta(x) = softplus[f(x)].
```

The raw-score gradient is

```text
[z_T - E_r(z)] * sigmoid[f(x)].
```

For LightGBM and XGBoost, use a positive Fisher or Gauss-Newton curvature rather than a negative exact raw-score Hessian when necessary.

### 8.5 Initialization

Inside each training fold:

1. fit the global scalar `beta_global`;
2. convert it to the raw softplus scale;
3. initialize the flexible model at that global value;
4. train only residual heterogeneity.

Do not initialize at raw zero without recognizing that `softplus(0)=log(2)`.

---

## 9. Exact two-gap model: definition, assumptions, gradients, and integration

### 9.1 Direct gaps

Define

```text
u(x) = log[q_C(x)/q_H(x)] >= 0
v(x) = log[q_L(x)/q_C(x)] >= 0.
```

Then

```text
RR_HC(x) = exp[-u(x)]
RR_LC(x) = exp[ v(x)].
```

The exponentials here merely invert the log-gap definitions and guarantee positive risk ratios. They do not impose a common constant-elasticity demand curve.

### 9.2 Exact buyer posterior

```text
D(x)
  = pi_H(x) exp[-u(x)]
  + pi_C(x)
  + pi_L(x) exp[v(x)].

r_H(x) = pi_H(x) exp[-u(x)] / D(x)
r_C(x) = pi_C(x) / D(x)
r_L(x) = pi_L(x) exp[v(x)] / D(x).
```

### 9.3 Exact categorical loss

For buyer `i`:

```text
loss_i(u_i,v_i) = -log r_i,T_i.
```

Expanded:

```text
loss_i
  = log D_i
  + I(T_i=H) u_i
  - I(T_i=L) v_i
  - log pi_i,T_i.
```

### 9.4 Gradient and Hessian

```text
d loss_i / d u_i = I(T_i=H) - r_i,H
d loss_i / d v_i = r_i,L - I(T_i=L).
```

The exact direct-gap Hessian is

```text
[[r_H(1-r_H), r_H r_L],
 [r_H r_L,     r_L(1-r_L)]].
```

The nonzero off-diagonal term means that the outputs are coupled through the common normalization.

### 9.5 Flexible parameterization

For a direct-gap model:

```text
u(x) = softplus[f_H(x)]
v(x) = softplus[f_L(x)].
```

For a dose-aware model, define positive distances:

```text
d_H(x) = log[P_H(x)/P_C(x)] > 0
d_L(x) = log[P_C(x)/P_L(x)] > 0
```

and side-specific elasticity magnitudes:

```text
u(x) = d_H(x) beta_H(x)
v(x) = d_L(x) beta_L(x).
```

Use the direct-gap form for fixed tested arms. Use the dose-aware form only when counterfactual arm prices or intended doses are meaningfully row-specific and causally well defined.

---

## 10. New primary model: common component plus side-specific deviations

The purpose of this model is to let `L` observations improve high-side prediction through a shared response representation without forcing the high and low effects to be identical.

### 10.1 Neural or general differentiable form

Let a shared representation produce `f_0(x)`, and let two heads produce `f_H(x)` and `f_L(x)`.

Use

```text
beta_H(x) = softplus[f_0(x) + f_H(x)]
beta_L(x) = softplus[f_0(x) + f_L(x)].
```

Then

```text
u(x) = d_H(x) beta_H(x)
v(x) = d_L(x) beta_L(x).
```

Train with the exact joint categorical buyer loss.

An `L` buyer updates:

- the low-specific head;
- the shared component;
- through the shared component, the high-side prediction.

This is the principled version of “put more high-side learning signal on low-arm observations.”

### 10.2 Regularization

Use at least:

```text
lambda_common * complexity(f_0)
lambda_H * complexity(f_H)
lambda_L * complexity(f_L)
lambda_asym * mean[(beta_H(X)-beta_L(X))^2].
```

Interpretation:

- very large `lambda_asym`: nearly scalar common elasticity;
- moderate `lambda_asym`: partial pooling;
- zero `lambda_asym`: unrestricted side-specific slopes, apart from shared architecture.

Prefer stronger regularization on the side-specific heads than on the common component.

### 10.3 Alternative additive-gap parameterization

If the codebase models direct gaps rather than side slopes, use a shared nonnegative gap component plus signed or positive residual components only if monotonicity remains guaranteed. Document the exact transformation. Do not allow a residual to silently reverse demand monotonicity.

### 10.4 Required pooling-path experiment

Evaluate a path from nearly scalar to nearly independent sides. Store, for every pooling strength:

- `H/C` NLL;
- `L/C` NLL;
- joint buyer NLL;
- calibration slopes;
- grouped risk-ratio calibration;
- temporal stability;
- randomized policy value.

Do not compare only two endpoints.

---

## 11. New primary tree architecture: common scalar booster plus side-specific residual boosters

Standard LightGBM and default XGBoost multiclass models share a loss but normally build output-specific scalar trees. They do not provide the same shared representation as a neural trunk. Implement explicit shared structure as follows.

### 11.1 Stage 1: common all-arm model

Fit `beta_0(x)>=0` on all buyers using the scalar exact buyer loss.

It produces common log-risk-ratio margins:

```text
eta_H_common(x) = -d_H(x) beta_0(x)
eta_L_common(x) =  d_L(x) beta_0(x).
```

### 11.2 Stage 2: cross-fitted common predictions for residual training

Do not train residual models against in-sample common predictions without checking leakage and compensation effects.

Inside every outer training fold:

1. split the outer training data into inner folds;
2. fit the common model on inner-train buyers;
3. predict `beta_0` for inner-validation buyers;
4. combine the inner-validation predictions into cross-fitted common predictions for all outer-training buyers;
5. use those cross-fitted margins as residual-model base margins;
6. fit one full common model on the entire outer-training buyer set for outer-validation prediction.

### 11.3 Stage 3: high-side residual model

For `H/C` buyers, define the common binary margin

```text
base_HC(x)
  = log[pi_H(x)/pi_C(x)]
  + eta_H_common(x).
```

Fit a binary residual booster `delta_H(x)` with that row-level base margin.

### 11.4 Stage 4: low-side residual model

For `L/C` buyers:

```text
base_LC(x)
  = log[pi_L(x)/pi_C(x)]
  + eta_L_common(x).
```

Fit a residual booster `delta_L(x)`.

### 11.5 Stage 5: residual shrinkage

Form final log risk ratios:

```text
eta_H(x)
  = eta_H_common(x) + gamma_H delta_H(x)

eta_L(x)
  = eta_L_common(x) + gamma_L delta_L(x),
```

where

```text
0 <= gamma_H <= 1
0 <= gamma_L <= 1.
```

Select `gamma_H` and `gamma_L` strictly out of fold. Do not assume full residual correction is optimal.

Enforce or smoothly parameterize:

```text
eta_H(x) <= 0
eta_L(x) >= 0.
```

### 11.6 Coherent reconstruction

Always reconstruct the final buyer posterior as

```text
r(x)
  = softmax(
      log pi_H(x) + eta_H(x),
      log pi_C(x),
      log pi_L(x) + eta_L(x)
    ).
```

Never treat two pairwise probabilities as if they directly summed with control.

### 11.7 XGBoost base margins

For XGBoost:

- provide raw logit margins, not probabilities;
- provide the base margin during training;
- provide the corresponding base margin again during validation and prediction;
- wrap this behavior so users cannot accidentally omit it;
- test serialization and prediction parity.

### 11.8 LightGBM initial scores

For LightGBM:

- use dataset `init_score` or the current equivalent supported by the installed version;
- treat the initial score as dataset metadata, not a persistent model feature;
- at prediction time, explicitly add the common margin to the residual model’s raw residual prediction unless the current wrapper proves the library does this correctly;
- write a unit test that compares manual reconstruction with wrapper output.

### 11.9 Residual-model complexity

Residual models should normally be shallower and more regularized than the common model. They should correct systematic asymmetry, not relearn the whole response surface.

---

## 12. New proper ordinal model: cumulative or all-threshold learning

This model uses the ordered nature of `[H,C,L]` and gives extreme arms more threshold contributions without changing the target distribution through arbitrary class weights.

### 12.1 Cumulative probabilities

Use the ordinal index `K` defined in Section 0. Define

```text
F_1(x) = P(K <= 1 | Y=1,X=x) = r_H(x)
F_2(x) = P(K <= 2 | Y=1,X=x) = r_H(x) + r_C(x) = 1-r_L(x).
```

Define two binary targets:

```text
Z_1 = I(T=H)
Z_2 = I(T in {H,C}).
```

Their values are:

```text
T=H -> (Z_1,Z_2)=(1,1)
T=C -> (Z_1,Z_2)=(0,1)
T=L -> (Z_1,Z_2)=(0,0).
```

### 12.2 Cumulative log loss

```text
L_cumulative
  = BCE(Z_1,F_1) + BCE(Z_2,F_2).
```

With coherent probabilities

```text
0 <= F_1 <= F_2 <= 1,
```

the two true cumulative probabilities uniquely determine the three-class distribution:

```text
r_H = F_1
r_C = F_2 - F_1
r_L = 1 - F_2.
```

An `L` observation contributes negative evidence at both thresholds. A `C` observation lies on opposite sides of the thresholds. This realizes the user’s directional-gradient intuition through a proper ordered-probability target rather than arbitrary outcome weights.

### 12.3 Replicated-row LightGBM or XGBoost implementation

For every buyer create two rows:

```text
(original features, threshold_id=1, target=Z_1)
(original features, threshold_id=2, target=Z_2).
```

Use one binary model.

The no-effect initial cumulative probabilities are

```text
F_1,null(x) = pi_H(x)
F_2,null(x) = pi_H(x) + pi_C(x).
```

Use their logits as row-level base margins or initial scores.

Encode `threshold_id` as an ordered numeric feature. If the installed implementation can enforce a positive monotonic constraint on that feature, use and test it so that predicted `F_2` cannot be below `F_1` for identical customer features.

If exact coherence cannot be guaranteed by the learner, apply an explicit two-point isotonic projection at prediction time and report:

- fraction of predictions changed;
- mean absolute correction;
- maximum correction;
- resulting effect on joint NLL.

### 12.4 Threshold weights

Fixed positive weights on the two threshold losses preserve the true cumulative targets in an unrestricted function class, but they change the compromise under restricted model capacity.

Default to equal weights. If weights are tuned, keep them positive and evaluate all candidates with the same unweighted joint metrics.

Do not call threshold weights “class correction.”

### 12.5 Numerical stability

When reconstructing

```text
r_C = F_2 - F_1,
```

use a documented probability floor only after coherence enforcement. Record how often the floor is active. Large activation indicates an unsuitable cumulative model.

---

## 13. Hybrid exact-plus-ordinal loss

For a model that directly produces a coherent three-arm posterior `r(x)`, define:

```text
L_categorical = -log r_T(x).
```

Construct cumulative probabilities from `r` and define `L_cumulative` as above.

Train with

```text
L_total
  = L_categorical
  + lambda_ord L_cumulative,
```

where `lambda_ord>=0`.

In an unrestricted probability class, both components target the true distribution. Under finite-capacity models, `lambda_ord` changes the inductive bias and must be selected by nested validation.

Recommended search domain:

```text
lambda_ord in {0} union log-uniform[1e-3, 10].
```

Do not select `lambda_ord` by training loss. Primary validation remains joint buyer NLL and contrast-specific calibration.

This hybrid is easiest to implement exactly in a neural network or a general optimizer. A tree custom objective may use an approximation only if gradients, Hessian approximations, raw-margin semantics, and limitations are documented and tested.

---

## 14. Built-in multiclass boosted trees: what they do and how to use them

### 14.1 LightGBM

Ordinary multiclass LightGBM builds one scalar tree per class per boosting iteration. It shares the softmax loss and coupled gradients, but generally not the split structure across class outputs.

Use it as a joint-loss benchmark, not as proof of shared representation.

### 14.2 Default XGBoost

Default multiclass XGBoost similarly uses output-specific tree groups under its usual one-output-per-tree strategy. The outputs are coupled through softmax probabilities and gradients.

### 14.3 XGBoost vector leaves

If supported by the installed version, XGBoost may offer a vector-leaf strategy in which one tree shares its partition and stores an output vector in each leaf.

Treat it as experimental because support may be limited. Before using it:

1. detect the parameter through the installed API;
2. run a deterministic smoke test;
3. verify probability shape;
4. verify serialization;
5. verify early stopping;
6. verify custom metric support;
7. verify compatibility with the required objective;
8. record any unsupported feature.

Do not fail the whole pipeline if this challenger is unavailable.

### 14.4 Full Hessian limitation

The exact two-gap Hessian has cross-output terms. Common custom-objective interfaces for tree boosters usually expect one Hessian value per row and output rather than a full per-row output-by-output matrix.

If a diagonal Fisher or upper-bound Hessian is used:

- label the model approximate;
- keep the exact joint NLL as the evaluation metric;
- validate derivatives numerically;
- compare with exact linear or neural implementations.

---

## 15. Random Forest integration

Random Forest does not accept an arbitrary differentiable Bayes-flip objective.

### 15.1 Pairwise inverse-propensity model

For a pairwise buyer sample, a valid approach is to weight each buyer by the inverse of the propensity of the arm actually received, then recover the pairwise risk ratio from the weighted class probability.

Do not combine inverse-propensity weighting with automatic balanced class weights.

### 15.2 Cross-fitted common-sensitivity feature

A preferred new Random Forest extension is:

1. fit the all-arm common scalar model inside training folds;
2. generate strictly cross-fitted common sensitivity predictions;
3. add the common score as an input feature to the pairwise Random Forest;
4. calibrate the final pairwise log risk ratio out of fold.

This lets all arms contribute to shared representation while preserving a contrast-specific final likelihood.

### 15.3 Moment inversion

Keep a scalar moment-inversion Random Forest only as a benchmark. Document:

- moment definition;
- monotone inversion;
- regularization;
- probability or beta bounds;
- sensitivity to noisy conditional moments.

Do not present it as exact maximum likelihood.

---

## 16. Unified model interface and prediction schema

Adapt the current framework to expose one common conceptual interface. Do not require exact class names, but require equivalent behavior.

Suggested protocol:

```python
class ElasticityModelProtocol:
    def fit(self, X, arm, *, pi, dose=None, groups=None, sample_weight=None,
            eval_data=None): ...

    def predict_log_rr(self, X, *, pi=None, dose=None):
        """Return (log_rr_high, log_rr_low)."""

    def predict_buyer_posterior(self, X, *, pi, dose=None):
        """Return shape (n_rows, 3) in [H,C,L] order."""

    def get_model_metadata(self): ...
```

Create or adapt a prediction record containing at least:

```text
quote_id
fold_id
model_id
log_rr_high
log_rr_low
rr_high
rr_low
buyer_prob_H
buyer_prob_C
buyer_prob_L
standard_elasticity_HC
standard_elasticity_LC
log_elasticity_HC
log_elasticity_LC
projection_applied
calibration_version
```

Optional fields:

```text
beta_common
beta_high
beta_low
common_margin_high
common_margin_low
residual_high
residual_low
gamma_high
gamma_low
```

Every model must be reducible to the same final `(log_rr_high, log_rr_low)` representation before evaluation.

Do not require legacy model classes to adopt this interface internally. Implement a versioned adapter or registry layer. Preserve existing serialized models and their original feature-order contracts. The unified prediction record must also include:

```text
data_contract_version
dataset_fingerprint
fold_version
feature_manifest_hash
model_artifact_version
source_model_interface_version
prediction_schema_version
```

When an old prediction table uses different names or units, create a read-only conversion adapter and record the transformation. Never rewrite the old table in place.

---

## 17. Calibration, shrinkage, and monotonicity

### 17.1 Pairwise affine calibration

For each contrast, fit on predictions that are out of fold relative to the base model:

```text
eta_cal(x) = alpha + s [eta_raw(x)-center],
```

with `s>=0` unless a clearly justified diagnostic allows otherwise.

Interpretation:

- `alpha`: global effect correction;
- `s<1`: shrinkage of overestimated heterogeneity;
- `s=0`: collapse to a global effect.

### 17.2 Joint reconstruction after calibration

Calibrate log risk ratios, not independently normalized class probabilities, then reconstruct one coherent posterior using the logged propensities.

### 17.3 Monotonicity

Require

```text
log_rr_high <= 0
log_rr_low >= 0.
```

Prefer parameterizations that impose this by construction. If projection is used, report its frequency and magnitude.

### 17.4 Cross-fitting requirement

Calibration data must not be training predictions of the base model. In nested CV, calibrate using inner out-of-fold predictions and evaluate on the untouched outer fold.

---

## 18. Optuna study design

### 18.1 General rules

Use a separate Optuna study for each:

- model family;
- contrast where models are pairwise;
- direct-gap versus dose-aware formulation;
- common-plus-residual architecture;
- cumulative model;
- hybrid-loss model;
- experimental vector-leaf challenger.

Persist studies in a database or durable storage. Use deterministic sampler seeds. Record failed and pruned trials.

Do not mix all algorithms into one giant conditional study.

Before creating any study, inspect `OPTUNA_LINEAGE.md` and the existing study catalog. Use a new study name containing the model family, objective version, data fingerprint, fold version, and code version. Reuse an existing study only when all of these match exactly. Otherwise create a new study and optionally enqueue compatible prior best parameters. Never make a changed objective appear to be a continuation of the old objective.

Write study artifacts to new storage or a safely copied database. Keep the original database untouched. Preserve previous best parameters even when the corresponding model is later demoted.

### 18.2 Primary inner objectives

For pairwise models:

```text
NLL_HC or NLL_LC.
```

For common or joint models:

```text
0.5 * NLL_HC + 0.5 * NLL_LC
```

or joint categorical buyer NLL, with both contrast losses still reported.

For the specific question “does L help H?”, the final outer-fold transfer metric is `H/C` NLL on `H/C` buyers. Do not choose a model merely because total three-arm NLL improved through the easier low-side contrast.

### 18.3 Sharing hyperparameters

Search at least:

```text
lambda_asym: {0} union log-uniform[1e-4, 1e4]
lambda_ord:  {0} union log-uniform[1e-3, 10]
gamma_H: uniform[0,1]
gamma_L: uniform[0,1]
```

For shared neural models also tune:

```text
shared_width
shared_depth
head_width
head_depth
shared_dropout
head_dropout
common_penalty
head_penalty
```

with stronger default shrinkage on side heads.

### 18.4 Common LightGBM search space

Use a conservative buyer-data search such as:

```text
learning_rate: log-uniform[0.005, 0.05]
max_depth: integer[2,6]
num_leaves: integer[4,31], constrained by max_depth
min_data_in_leaf: dynamic from buyer and side-arm counts
feature_fraction: uniform[0.5,1.0]
bagging_fraction: uniform[0.6,1.0]
lambda_l1: {0} union log-uniform[1e-8,10]
lambda_l2: log-uniform[1e-2,1e3]
max_bin: one of {63,127,255,511}
```

Use early stopping. Treat iteration count as selected by validation rather than as the main complexity parameter.

### 18.5 Residual LightGBM search space

Residual models should search a smaller, more regularized region:

```text
learning_rate: log-uniform[0.005,0.05]
max_depth: integer[1,4]
num_leaves: integer[2,15]
min_data_in_leaf: larger dynamic minimum
feature_fraction: uniform[0.5,1.0]
bagging_fraction: uniform[0.6,1.0]
lambda_l2: log-uniform[1,1e4]
lambda_l1: {0} union log-uniform[1e-8,100]
```

### 18.6 Common XGBoost search space

```text
eta: log-uniform[0.005,0.05]
max_depth: integer[2,6]
min_child_weight: log-uniform[1,100]
subsample: uniform[0.6,1.0]
colsample_bytree: uniform[0.5,1.0]
gamma: {0} union log-uniform[1e-8,10]
reg_alpha: {0} union log-uniform[1e-8,10]
reg_lambda: log-uniform[1e-2,1e3]
max_bin: one of {64,128,256,512}
max_delta_step: uniform[0,5] as an optional stability parameter
```

Residual XGBoost models should use shallower trees and stronger regularization.

### 18.7 Cumulative model search

Tune:

```text
model complexity parameters
threshold interaction capacity
positive threshold-loss weight ratio, default 1
coherence method: constrained or projected
probability floor, only within a narrow safe range
```

Always evaluate with unweighted joint and pairwise NLL.

### 18.8 Random Forest search

Optimize:

```text
criterion in {log_loss,gini}
max_depth in [4,16]
min_samples_leaf dynamically from side-arm buyers
max_features in {sqrt,log2} or uniform[0.2,1.0]
max_samples uniform[0.5,1.0]
min_impurity_decrease in {0} union log-uniform[1e-8,1e-3]
ccp_alpha in {0} union log-uniform[1e-8,1e-2]
```

Use enough trees for stable probabilities, commonly hundreds to about one thousand, but treat tree count mainly as Monte Carlo stabilization after convergence.

### 18.9 Optuna sampler and pruner

Use a seeded TPE sampler. Multivariate and grouped TPE may be used only if supported by the installed version and isolated behind configuration. A median pruner is reasonable for iterative models when intermediate values are genuinely comparable across trials.

Do not prune non-iterative models based on meaningless intermediate steps.

---

## 19. Data splitting, lineage, and leakage prevention

All splitting code must consume the preserved fold registry from Section 2.9. Do not let a model wrapper create new folds implicitly. Every prediction must carry the original quote identifier, cluster identifier or secure cluster key, outer fold, inner fold when applicable, time-split version, data-contract version, and source model version.

Derived views such as pairwise subsets or cumulative row replication must be generated in a new cache namespace keyed by the canonical dataset fingerprint and must not alter the canonical table. Record input and output row counts and verify that every derived row maps back to exactly one original quote.

### 19.1 Final chronological holdout

Reserve the latest 15–25% of customer or household clusters as a final holdout. Assign a cluster by its latest eligible quote time so no cluster appears in both development and holdout.

### 19.2 Nested development CV

Within development data:

- use customer-disjoint outer folds for model comparison;
- use customer-disjoint inner folds for Optuna;
- preserve buyer-arm proportions where feasible;
- reuse exactly the same folds for every candidate;
- fit preprocessing only on the training portion of each fold.

### 19.3 Cross-fitted shared features and base margins

Every common score, base margin, auxiliary representation, or calibration input used to train a downstream model must be generated without fitting the upstream model on that row.

This rule applies to:

- common scalar predictions used by residual boosters;
- common sensitivity features used by Random Forest;
- neural embeddings used by a second-stage model;
- calibrator inputs;
- stacking inputs.

### 19.4 Repeated quote handling

If one customer has multiple quotes, keep the customer in one fold. Perform sensitivity analyses for:

- first eligible quote only;
- last eligible quote only;
- one quote per defined shopping episode;
- cluster-weighted analysis.

---

## 20. Evaluation metrics

### 20.1 Joint buyer categorical NLL

For final posterior predictions:

```text
NLL_joint
  = -mean_i log r_hat_i,T_i
```

on buyers only.

### 20.2 Pairwise conditional NLL

For high versus control:

```text
s_H(x)
  = pi_H(x) RR_HC(x)
    / [pi_H(x) RR_HC(x) + pi_C(x)].
```

Evaluate binary cross-entropy on `H/C` buyers.

Analogously evaluate `L/C` NLL.

### 20.3 Equal-contrast score

```text
NLL_equal
  = 0.5 * NLL_HC + 0.5 * NLL_LC.
```

This prevents the easier or more common contrast from dominating.

### 20.4 Information gain

Report improvement over global anchors in millinats per relevant buyer, with customer-clustered confidence intervals.

### 20.5 Calibration

For each contrast, evaluate:

- calibration intercept;
- calibration slope;
- grouped randomized risk-ratio calibration;
- calibration by time, tariff version, channel, and major premium bands.

Use few large groups when side-arm buyer counts are small.

### 20.6 Stability

Report:

- fold-to-fold variation;
- seed variation;
- forward-time variation;
- top-k overlap of recommended price changes;
- projection frequency;
- residual shrinkage values;
- pooling strength selected;
- sensitivity to feature groups.

### 20.7 Policy value

Use randomized inverse-propensity evaluation on all eligible quotes:

```text
V_hat_IPS(d)
  = mean_i I[T_i=d(X_i)] Y_i g_T_i(X_i) / pi_i,T_i.
```

Compare with:

- control for everyone;
- each uniform tested arm;
- best uniform arm;
- global scalar policy;
- separate pairwise policy;
- shared model policy;
- simple actuarial segment rules.

Use customer-cluster bootstrap intervals and report effective matched sample size.

A base-conversion model may support a doubly robust estimator, but IPS remains the conversion-model-free benchmark.

---

## 21. Experiments that directly test whether L data improve H/C learning

Run these ablations with identical outer folds.

### 21.1 All-arm common model versus H/C-only common model

Fit the same common-model family twice:

1. using all three buyer arms;
2. using only `H/C` buyers.

Feed each into the same high-side residual architecture. Compare outer-fold `H/C` NLL and calibration.

This is the primary transfer experiment.

### 21.2 Stop-gradient ablation for neural networks

Compare:

- normal shared-trunk training;
- a version where `L` observations update the low head but are prevented from updating the shared trunk.

The difference estimates the value of low-arm shared gradients.

### 21.3 L-feature permutation ablation

Within each training fold, permute the features of `L` buyers inside narrow blocks defined by variables such as:

- time;
- tariff version;
- propensity block;
- channel.

Preserve arm counts and global low-arm effect while destroying heterogeneous `X`–`L` association.

Use this only as a diagnostic. Never deploy the permuted model.

### 21.4 Pooling path

Evaluate a path from common scalar to independent side-specific response surfaces using `lambda_asym` or an equivalent parameter.

### 21.5 Ordinal-loss path

Evaluate `lambda_ord=0` and a logarithmic path of positive values.

### 21.6 Residual shrinkage path

Evaluate `gamma_H` and `gamma_L`, including zero and one.

### 21.7 Pairwise versus exact joint objective

Compare models with similar function capacity under:

- exact joint categorical loss;
- pairwise composite likelihood;
- cumulative loss;
- hybrid loss.

Do not compare a tiny linear pairwise model with a large neural joint model and attribute the difference only to the loss.

---

## 22. Model-selection logic

Promote a shared model over the separate pairwise baseline only when:

1. outer-fold `H/C` NLL improves if the claimed benefit is low-to-high transfer;
2. the improvement is consistent across customer-disjoint folds;
3. it persists on the chronological holdout;
4. `H/C` calibration improves or remains acceptable;
5. `L/C` performance is not seriously damaged;
6. joint posterior calibration remains coherent;
7. randomized policy value improves or remains within a justified non-inferiority margin;
8. the conclusion survives the with-`L` versus without-`L` ablation;
9. projection and probability-floor usage remain low;
10. the selected sharing strength is not a boundary artifact caused by a broken search space.

Otherwise retain the pairwise or more strongly pooled model.

Do not conclude “use a larger model” merely because heterogeneity is weak.

---

## 23. Required software and preservation tests

Add deterministic tests for every new component and regression tests protecting prior work.

### 23.0 Preservation and legacy-regression tests

- raw-data paths are never opened for writing by the upgrade code;
- pre-upgrade source and configuration hashes remain available;
- canonical adapter parity holds for the unchanged contract;
- quote, buyer, arm, cluster, and fold counts match the frozen baseline;
- legacy feature order and category vocabularies remain usable;
- each loadable legacy model reproduces its golden prediction fingerprint within documented numerical tolerance;
- existing prediction tables and model artifacts are not overwritten;
- fold files are versioned and immutable;
- Optuna storage paths and study names are not reused incompatibly;
- new caches use a new namespace and old caches remain present;
- configuration migration is reversible or has a compatibility loader;
- rollback reconstruction succeeds in a temporary path;
- pre-existing failures remain distinguished from introduced failures.

Add deterministic tests for every new component.

### 23.1 Algebraic tests

- Bayes-flip risk-ratio reconstruction;
- exact `10/80/10` formulas;
- scalar posterior normalization;
- two-gap posterior normalization;
- monotonicity by construction;
- coherent pairwise reconstruction;
- cumulative reconstruction;
- elasticity transformations.

### 23.2 Derivative tests

Use finite differences for:

- scalar loss gradient;
- scalar Fisher or exact Hessian where applicable;
- two-gap gradient;
- two-gap full Hessian;
- shared-component neural loss;
- hybrid categorical-plus-cumulative loss.

### 23.3 Target-integrity tests

- show that unweighted `H`-versus-rest predicts `r_H`, not `RR_HC`;
- show analytically or numerically that `w_L != w_C` changes the target;
- verify pairwise offset inversion;
- verify inverse-propensity Random Forest inversion;
- verify no class balancing is silently applied.

### 23.4 Base-margin tests

For both LightGBM and XGBoost wrappers:

- training and prediction with constant base margin;
- row-varying base margin;
- validation margin;
- serialization round trip;
- manual raw-margin reconstruction parity.

### 23.5 Cumulative-model tests

- replicated targets are correct for all three arms;
- null offsets equal propensity cumulative logits;
- `F_1<=F_2` after constraint or projection;
- reconstructed probabilities are nonnegative and sum to one;
- joint NLL is computed from reconstructed probabilities;
- correction diagnostics are recorded.

### 23.6 Cross-fitting tests

- no row receives an upstream prediction from a model trained on its cluster;
- no cluster crosses train and validation;
- calibrators never see in-sample base predictions;
- stacking uses OOF component predictions only.

### 23.7 Library capability tests

- LightGBM custom objective smoke test;
- XGBoost custom objective smoke test;
- XGBoost vector-leaf feature detection and skip behavior;
- installed-version metadata is recorded.

---

## 24. Required artifacts and reporting

Create a new run directory. Do not overwrite prior runs.

Required artifacts. Preserve these under the new upgrade root; do not overwrite prior files:

```text
00_preservation/
  PRE_UPGRADE_SOURCE_STATE.md
  PRE_UPGRADE_SOURCE_SHA256.txt
  RESTORE_INSTRUCTIONS.md
  PRE_UPGRADE_TEST_REPORT.md
  PRE_EXISTING_FAILURES.md
  LEGACY_PREDICTION_FINGERPRINTS.json
01_inventory/
  ASSET_INVENTORY.csv
  BASELINE_ARTIFACT_CATALOG.csv
  REAL_DATA_ADAPTER_MAP.md
  CURRENT_DATA_BEHAVIOR_CONTRACT.md
  FEATURE_LINEAGE.csv
  DATASET_VERSION_REGISTRY.json
  FOLD_REGISTRY.csv
  HOLDOUT_STATUS.md
  OPTUNA_LINEAGE.md
02_baseline/
  DATA_PARITY_BASELINE.json
  DATA_PARITY_REPORT.md
  CURRENT_BEHAVIOR_BASELINE.md
03_migration_design/
  MIGRATION_MAP.md
  CHANGESET_PLAN.md
  CHANGELOG_ELASTICITY_SHARED_MODELS.md
  MODEL_ARTIFACT_LINEAGE.csv
04_implementation/
  resolved_config.yaml
  environment.json
  data_fingerprint.json
05_validation/
  experiment_audit/
  fold_definitions/
  optuna/
  models/
  oof_predictions/
  holdout_predictions/
  metrics/
  calibration/
  ablations/
  plots/
  regression/
06_reports/
  research_log.md
  model_cards/
  REGRESSION_REPORT.md
  ROLLBACK_TEST_REPORT.md
  FINAL_REPORT.md
checkpoints/
```

### 24.1 Changelog

The changelog must explicitly state:

- which prior capabilities were retained;
- which were adapted;
- which were replaced;
- which new models were added;
- any incompatible API changes;
- how old serialized models are handled;
- which experiments could not be run and why;
- which real-data adaptation components were reused unchanged;
- every deliberate change to data semantics, with parity impact;
- previous folds, studies, models, and predictions that remain the comparison baselines;
- new artifact identifiers and their predecessors;
- the exact rollback procedure and whether it was tested.

### 24.2 Research log

For every model or experiment, record:

- hypothesis;
- implementation;
- data subset;
- folds;
- hyperparameter study;
- result;
- uncertainty;
- calibration;
- failure modes;
- decision to keep, demote, or reject.

### 24.3 Final report

The final report must answer:

1. Did low-arm data improve held-out high-versus-control prediction?
2. Through which mechanism: common scalar model, shared trunk, cumulative loss, or residual architecture?
3. What sharing strength was selected?
4. Did the gain persist over time?
5. Did calibration improve?
6. Did randomized contribution value improve?
7. Which model is recommended and which remains the fallback?
8. What evidence is still insufficient?

Do not declare a winner without real out-of-fold evidence.

---

## 25. Prohibited shortcuts and dead ends

Do not:

- assign a larger arbitrary gradient to `L` than `C` in an `H`-versus-rest classifier and interpret the output as `RR_HC`;
- use `class_weight="balanced"` without deriving and reversing the target shift;
- use SMOTE or synthetic buyers;
- duplicate side-arm buyers and call the result additional information;
- use AUC, accuracy, F1, or multiclass VUS as the primary elasticity metric;
- evaluate on training predictions;
- tune and evaluate on the same folds without nesting;
- fit a common model on all rows and use its in-sample score as an unguarded downstream feature;
- forget XGBoost prediction base margins;
- assume LightGBM initial scores are automatically persisted at inference;
- call ordinary multiclass boosting an exact two-gap model;
- call a diagonal-Hessian approximation exact;
- interpret high/low asymmetry as proof of individual demand-curve curvature;
- replace real experimental evidence with synthetic results;
- optimize policy value without probability and risk-ratio calibration checks.

---

## 26. Recommended preservation-first implementation order

Follow this order. Do not skip to new models merely because their code is straightforward.

### Phase 0: stop, inspect, and snapshot

1. Complete the read-only preflight.
2. Create the isolated upgrade root.
3. Preserve Git or non-Git source state, including uncommitted work.
4. Inventory sensitive-data boundaries and artifact locations.
5. Write and test preliminary restore instructions.

### Phase 1: preserve real-data work

6. Map the current raw-to-canonical data adaptation.
7. Freeze the current data-behavior contract and feature lineage.
8. Fingerprint the canonical dataset without copying raw data.
9. Freeze fold and holdout registries.
10. Catalog prior models, predictions, Optuna studies, and reports.
11. Run the existing tests and record pre-existing failures.
12. Freeze legacy prediction fingerprints and baseline metrics.

### Phase 2: design the non-destructive migration

13. Create `MIGRATION_MAP.md`.
14. Create `CHANGESET_PLAN.md` with regression gates and rollback methods.
15. Add or adapt the unified model and prediction adapters without changing legacy classes.
16. Add feature flags and versioned schemas.
17. Verify legacy prediction parity through the adapters.

### Phase 3: mathematical core

18. Add or verify scalar, two-gap, cumulative, and hybrid loss functions.
19. Add derivative, reconstruction, target-integrity, and monotonicity tests.
20. Add derived-view builders that consume the preserved canonical dataset.
21. Verify quote and fold lineage through pairwise and replicated views.

### Phase 4: new statistical models in shadow mode

22. Add the shared-component exact linear or neural model.
23. Add the common scalar plus residual LightGBM/XGBoost pipeline.
24. Add the cumulative replicated booster.
25. Add the cross-fitted common-score Random Forest.
26. Add built-in multiclass and optional vector-leaf challengers.
27. Do not change the production alias or overwrite prior model artifacts.

### Phase 5: nested tuning, calibration, and ablations

28. Create versioned Optuna studies; warm-start only compatible parameters.
29. Generate all upstream scores strictly out of fold.
30. Add nested OOF calibration.
31. Run transfer, pooling, ordinal, and residual-shrinkage ablations.
32. Compare with preserved baselines on identical fold versions.

### Phase 6: final real-data evaluation

33. Re-run the experiment audit under the frozen data contract.
34. Evaluate mandatory global and pairwise anchors.
35. Evaluate new shared models on outer folds.
36. Freeze the protocol and only then evaluate the chronological holdout.
37. Evaluate randomized policy value and uncertainty.
38. Produce model cards, regression report, research log, and final report.

### Phase 7: rollback verification and handover

39. Reconstruct the pre-upgrade source/configuration state in a temporary location.
40. Verify hashes and legacy prediction fingerprints.
41. Confirm raw data, prior folds, studies, models, predictions, and reports remain untouched.
42. Write `ROLLBACK_TEST_REPORT.md` and final artifact lineage.
43. Promote no model automatically. Leave promotion as an explicit, reversible decision.

## 27. Completion checklist

Do not mark the task complete until all applicable items are satisfied.

### Preservation and real-data continuity

- [ ] Read-only preflight was completed before repository edits.
- [ ] A unique non-overwriting upgrade root was created.
- [ ] Tracked, staged, untracked, and uncommitted source state was preserved.
- [ ] Restore instructions and source/configuration hashes exist.
- [ ] Raw real-data files were not copied into bundles or modified.
- [ ] `ASSET_INVENTORY.csv` and `BASELINE_ARTIFACT_CATALOG.csv` exist.
- [ ] The prior real-data adapter, filters, arm mapping, propensity handling, feature timing, and preprocessing were documented.
- [ ] Canonical dataset and fold parity baselines were frozen.
- [ ] Existing fold and holdout files remain available and were not overwritten.
- [ ] Existing Optuna databases and study names remain intact.
- [ ] Existing models, calibrators, OOF predictions, holdout predictions, and reports remain available.
- [ ] Pre-existing test failures were recorded separately from introduced failures.
- [ ] Legacy prediction fingerprints pass after integration.
- [ ] New derived views preserve quote and fold lineage.
- [ ] The rollback procedure was tested successfully in a temporary location.

### Codebase adaptation

- [ ] Current repository was inspected before modification.
- [ ] `MIGRATION_MAP.md` exists.
- [ ] Existing public interfaces were preserved or wrapped.
- [ ] Installed package capabilities were detected at runtime.

### Statistical correctness

- [ ] Bayes-flip identity uses row-level propensities.
- [ ] Scalar model is learned from buyer-arm likelihood, not pseudo-labels.
- [ ] Two-gap model uses a coherent joint posterior.
- [ ] Arbitrary `L>C` outcome weighting is absent from primary estimators.
- [ ] Shared information enters through an explicit model or proper score.
- [ ] All final models output coherent `log_rr_high` and `log_rr_low`.

### New models

- [ ] Common scalar plus residual boosters are implemented.
- [ ] Shared-component side-specific model is implemented where framework permits.
- [ ] Cumulative all-threshold model is implemented.
- [ ] Hybrid loss is implemented where feasible.
- [ ] Cross-fitted common-score Random Forest is implemented.
- [ ] Multiclass challengers are labeled correctly.
- [ ] XGBoost vector leaves are feature-detected and optional.

### Validation

- [ ] Customer-disjoint nested folds are used.
- [ ] Final chronological holdout is untouched until protocol freeze.
- [ ] Shared scores and calibrators are cross-fitted.
- [ ] `H/C`, `L/C`, and joint NLL are reported.
- [ ] Calibration and grouped randomized risk ratios are reported.
- [ ] Transfer ablations are completed.
- [ ] Policy values have cluster-bootstrap intervals.

### Evidence

- [ ] No synthetic model leaderboard is present.
- [ ] Negative and unstable results are logged.
- [ ] The final recommendation is conditional on real-data evidence.
- [ ] The report directly answers whether `L` data improved `H/C` prediction.

---

## 28. Final instruction

The purpose of this upgrade is not to replace prior work or to force low-arm observations to influence the high-side estimate. It is to preserve the evolved real-data system, add statistically valid mechanisms through which low-arm data **may** help, and test that transfer rigorously.

The default engineering position is:

```text
Preserve the current real-data adaptation, folds, studies, models, predictions, and reports.
Extend through versioned adapters and new shadow models.
Never trade reproducibility or rollback for architectural neatness.
```

The default scientific position is:

```text
Separate H/C conditioning is valid when the low-side response is unrestricted.
Low-arm data should influence H/C only through an explicit, testable sharing assumption
or through a proper ordered-probability loss.
```

If preservation and model breadth conflict, preserve first. Implement the candidate models behind reversible interfaces, keep coherent probability targets, retain every prior baseline, and let real nested out-of-fold evidence decide how much sharing is useful.


---

## 28. Required use of the supplied Python files

The Python files in `REFERENCE_IMPLEMENTATION` are part of this task.  Do not
ignore them, but also do not overwrite the evolved repository with them.

At minimum, inspect and map these new or materially updated modules:

```text
elasticity_only/shared.py
elasticity_only/ordinal.py
elasticity_only/residual.py
elasticity_only/torch_shared.py
elasticity_only/preservation.py
elasticity_only/capabilities.py
elasticity_only/optuna_spaces.py
examples/06_fit_shared_two_slope.py
examples/07_fit_all_threshold.py
examples/08_common_residual_workflow.py
```

Also compare the retained foundational modules:

```text
core.py
scalar.py
two_gap.py
pairwise.py
multiclass.py
calibration.py
metrics.py
policy.py
schema.py
audit.py
splits.py
pipeline.py
tuning.py
```

Use the bundled tests as a mathematical and API checklist.  Adapt tests to the
host framework rather than deleting them when names or interfaces differ.
Every deliberate difference from the reference implementation must be recorded
in `REFERENCE_IMPLEMENTATION_DEVIATIONS.md` with the reason, evidence, and
consequence.

The final report must identify:

- bundled functions reused unchanged;
- bundled functions adapted to the host framework;
- current host functions retained instead of bundled versions;
- bundled ideas not implemented and why;
- compatibility layers added;
- parity tests passed;
- old artifacts still loadable;
- new artifacts and their versioned locations;
- exact rollback procedure.
